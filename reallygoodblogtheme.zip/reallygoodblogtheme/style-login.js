jQuery(function($) {

	// $("#loginform label[for='user_login']").html('some text');


});