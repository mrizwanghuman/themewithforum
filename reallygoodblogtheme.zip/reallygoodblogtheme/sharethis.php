
<?php 
//If the form is submitted
if(isset($_POST['submitted'])) {

  //Check to see if the honeypot captcha field was filled in
  if(trim($_POST['checking']) !== '') {
    $captchaError = true;
  } else {
  
    //Check to make sure that the name field is not empty
    if(trim($_POST['contactName']) === '') {
      $nameError = 'You forgot to enter your name.';
      $hasError = true;
    } else {
      $name = trim($_POST['contactName']);
    }
      //Check to make sure sure that a valid email address is submitted
    if(trim($_POST['email']) === '')  {
      $emailError = 'You forgot to enter your email address.';
      $hasError = true;
    } else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
      $emailError = 'You entered an invalid email address.';
      $hasError = true;
    } else {
      $email = trim($_POST['email']);
    }
      
    //Check to make sure comments were entered  
    if(trim($_POST['comments']) === '') {
      $commentError = 'You forgot to enter your comments.';
      $hasError = true;
    } else {
      if(function_exists('stripslashes')) {
        $comments = stripslashes(trim($_POST['comments']));
      } else {
        $comments = trim($_POST['comments']);
      }
    }
      
    //If there is no error, send the email
    if(!isset($hasError)) {

      $emailTo = $friendemail;
      $subject = 'Contact Form Submission from '.$name;
      $sendCopy = trim($_POST['sendCopy']);
      $body = "Name: $name \n\nEmail: $email \n\nComments: $comments";
     
      $headers = 'From: My Site <'.$emailTo.'>' . "\r\n" . 'Reply-To: ' . $email;
 
      $headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
      wp_mail($emailTo, $subject, $body, $headers);

      if($sendCopy == true) {
        $subject = 'You emailed Your Name';
        $headers = 'From: Your Name <noreply@somedomain.com>';
        $wp_mail($email, $subject, $body, $headers);
        
      }

      $emailSent = true;

    }
  }
} ?>

<?php if(isset($emailSent) && $emailSent == true) { ?>
    <div class="thanks">
    <h1>Thanks, <?=$name;?></h1>
    <p>Your email was successfully sent. </p>
  </div>
 <?php } else { ?>
<?php global $current_user;
      get_currentuserinfo();

      // echo 'Username: ' . $current_user->user_login . "\n";
      // echo 'User email: ' . $current_user->user_email . "\n";
      // echo 'User level: ' . $current_user->user_level . "\n";
      // echo 'User first name: ' . $current_user->user_firstname . "\n";
      // echo 'User last name: ' . $current_user->user_lastname . "\n";
      // echo 'User display name: ' . $current_user->display_name . "\n";
      // echo 'User ID: ' . $current_user->ID . "\n";
?>
 <form action="<?php the_permalink(); ?>" id="contactForm" method="post" class="form-horizontal col-sm-12  ">
   <div class="form-group displaynon">
    <label for="contactName" class="col-sm-2 control-label">Name</label>
    <div class="col-sm-10">
       <input type="text" name="contactName" id="contactName" value="<?php if(isset($_POST['contactName'])) echo $_POST['contactName']; ?><?php echo $current_user->user_firstname?>" class="form-control" />
    </div>
  </div>
    <div class="form-group ">
    <label for="friendemail" class="col-sm-2 control-label">Email</label>
    <div class="col-sm-10">
      <input type="text" name="friendemail" id="friendemail" value="" class="form-control email" />
      <?php
   $friendemail = $_Get["friendemail"];
?>
      <?php if($emailError != '') { ?>
            <span class="error"><?=$emailError;?></span>
          <?php } ?>
    </div>
  </div> 
      
       <div class="form-group displaynon">
    <label for="email" class="col-sm-2 control-label">Your Email</label>
    <div class="col-sm-6">
      <input type="text" name="email" id="email" value="<?php if(isset($_POST['email']))  echo $_POST['email'];?><?php echo $current_user->user_email ?>" class="form-control email" />
      <?php if($emailError != '') { ?>
            <span class="error"><?=$emailError;?></span>
          <?php } ?>
    </div>
  </div> 

       <div class="form-group displaynon">
   
    <div class="col-sm-6">
  
      <textarea  type="text" name="comments" id="commentsText"  class="form-control email "><?php if(isset($_POST['comments'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['comments']); } else { echo $_POST['comments']; } } ?>
        <?php echo $current_user->user_firstname . "\n";?>
        said Check this out 
        <a  href="<?php bbp_topic_permalink(  ); ?>"><?php bbp_topic_title(  ); ?></a>
        Team 
        Really Good Teachers
      </textarea>
      <?php if($commentError != '') { ?>
            <span class="error"><?=$commentError;?></span> 
          <?php } ?>
    </div>
  </div>
         
              <div class="form-group displaynon">
                <label for="checking" class="screenReader">If you want to submit this form, do not enter anything in this field</label>
                <input type="hidden" name="checking" id="checking" class="screenReader" value="<?php if(isset($_POST['checking']))  echo $_POST['checking'];?>" /></div>
        <div class="buttons "><input type="hidden" name="submitted" id="submitted" value="true" />
          <button type="submit" class="btn sellallartbtn pull-right">Send</button></div>
      
    </form>
    <?php } ?>
