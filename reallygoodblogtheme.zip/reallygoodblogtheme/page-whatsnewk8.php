<?php 
/**
 * Template Name: Whats New K-8
 * 
 */

get_header(); ?>


<div class="col-sm-12 col-xs-12 whatsnewparenttitle">
<h1><?php echo get_cat_name(  1044) ?></h1>
</div>
<?php
$wahtsnewk8args = array(
	'cat' => 1044,
'date_query' => array(
        array(
            'column' => 'post_date_gmt',
            'after'  => '200 days ago',
        )
),
	);
?>

<?php 
// the query
$wahtsnewk8query = new WP_Query( $wahtsnewk8args ); ?>

<?php if ( $wahtsnewk8query->have_posts() ) : ?>

	<!-- pagination here -->

	<!-- the loop -->
	<?php while ( $wahtsnewk8query->have_posts() ) : $wahtsnewk8query->the_post(); ?>
	<div class="col-xs-12 col-sm-12 lastqueryclass ">
<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">

<a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('homepagerecentpost');
} 
?></a>
</div>
<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 recenpostcatheading slidertextview">
<div class="thirdloopcat recentpostheading "><?php the_category( " "); ?><span class="glyphicon glyphicon-triangle-right"></span></div>

  <div class="rgsposttitle slidertextview circleimage1"><a  href="<?php the_permalink(); ?>" ><?php the_title();?></a></div>
  <div class=" catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php the_time('F j, Y'); ?></div>
<p><?php echo substr(get_the_excerpt(), 0,170); ?><span class="rgsreadmore"> . . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></span></p>

</div>
</div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>

<?php get_footer(); ?>