jQuery(function($) {
    var count = 1;
    var total = <?php echo $wp_query->max_num_pages; ?>';
    $(window).scroll(function(){
            if  ($(window).scrollTop() == $(document).height() - $(window).height()){
               if (count > total){
                    return false;
               }else{
                    loadArticle(count);
               }
               count++;
            }
    }); 

    function loadArticle(){    
            $('a#inifiniteLoader').show('fast');
            $.ajax({
                url: "<?php bloginfo('wpurl') ?>/wp-admin/admin-ajax.php",
                type:'POST',
                data: "action=infinite_scroll&loop_file=loop", 
                success: function(html){
                    $('a#inifiniteLoader').hide('1000');
                    $("#content").append(html);    // This will be the div where our content will be loaded
                }
            });
        return false;
    }
});