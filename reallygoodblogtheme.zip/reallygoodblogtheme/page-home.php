<?php 

/**
 * Template Name: Home
 * 
 */

get_header(); ?>
<?php $do_not_duplicate = array(); ?>

<div class="row marginbottom">

<div id="carousel-home" class="carousel slide borderclass col-sm-12 col-xs-12" data-ride="carousel" data-interval="5000">
   
 
 <div class="carousel-inner">

  <?php 

  

   
   $the_query1 = new WP_Query(array(
   
    'posts_per_page' => 1 ,
     'post__not_in' => get_option( 'sticky_posts' )
    )); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>
   <div class="item active">
    <div class="row">
      <?php $postdatenew = get_the_time('F j, Y'); ?>
       <?php
 $d=strtotime("-3 Months");
$pasthethreemontdate = date("m-d-y", $d);

if ($postdatenew > $pasthethreemontdate){?>

 <div class="newimage "><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/circleimage.png"></div>
<?php }?>


      <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8  thumbnailslider">
        
    <?php the_post_thumbnail('homepagesize');?>
  
</div>

<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 slidertextview">
 <div class="row"> 
 <h2 class="col-xs-12 col-sm-12 col-md-12  "><a class="rgstitlesliderheading " href="<?php the_permalink(); ?>" ><?php the_title();?></a></h2>
 <div class="col-xs-12 catedatfont"><?php
 foreach((get_the_category()) as $childcat) {
   $parentcat = $childcat->category_parent;
   echo get_cat_name($parentcat);
 }
 ?> | <?php echo  $postdatenew ?>
 
 </div>
  <div class="col-xs-12 col-sm-12 col-md-12 "><?php the_excerpt(); ?></div>
  </div>


</div>
   
</div>

   </div><!-- item active -->
  <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
  <?php 
  if ( function_exists( 'ot_get_option' ) ) {
  $numberofslideoption = ot_get_option( 'rgs_slides_homepage' );
}
   $the_query2 = new WP_Query(array(
    
    'posts_per_page' => $numberofslideoption,
    
     'post__not_in' => array_merge($do_not_duplicate, get_option( 'sticky_posts' )),
    )); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();
$do_not_duplicate[] = $post->ID;
  ?>

   <div class="item">
      <div class="row">
<?php $postdatenew = get_the_time('F j, Y'); ?>
       <?php
 $d=strtotime("-3 Months");
$pasthethreemontdate = date("m-d-y", $d);

if ($postdatenew > $pasthethreemontdate){?>

 <div class="newimage "><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/newBadgeupdated.png"></div>
<?php }?>
      <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 thumbnailslider">
        <div class="newimage"></div>
    <?php the_post_thumbnail('sixtwentybythreefifty');?>

</div>

<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 slidertextview">
<div class="row">  
<h2 class="col-xs-12"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h2>
<div class="col-xs-12 catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php echo get_the_time('F j, Y'); ?></div>
 <div class="col-xs-12 "><?php the_excerpt();?></div>
</div>
</div>
   
</div>
   </div><!-- item -->
  <?php 
   endwhile; 
   wp_reset_postdata();
  ?>
 </div><!-- carousel-inner -->
 <!-- Controls -->
   <div class="hiddencontroll"><a class="left carousel-control" href="#carousel-home" role="button" data-slide="prev">
      <span class="rgsleftarrow"  aria-hidden="true">
        <img src="<?php bloginfo('template_url'); ?>/images/leftarrow.png"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#carousel-home" role="button" data-slide="next">
      <span class="rgsrightarrow" aria-hidden="true"><img src="<?php bloginfo('template_url'); ?>/images/rightarrow.png"></span>
      <span class="sr-only">Next</span>
    </a></div>
</div><!-- #myCarousel -->

</div>
<!-- row for carousal ends -->

<div class="row ">
<div class=" stickypostarea">
   <ul class="col-xs-12 col-sm-12  ">
<?php 
// the query


$args = array(
  'post_type' => 'post',
  'post__in'  => get_option('sticky_posts'),
 'posts_per_page'      => '4',
   
  'meta_query' => array( 
        array(
            'key' => '_thumbnail_id'
        ) 
    )
  
  
);
$rgsstickyposts = new WP_Query( $args ); ?>

<?php if ( $rgsstickyposts->have_posts() ) : ?>

  
  <!-- the loop -->
  <?php while ( $rgsstickyposts->have_posts() ) : $rgsstickyposts->the_post(); ?>

  
<li class="col-xs-6 col-sm-6 col-md-3 col-lg-3 slidertextview circleimage1">
   
<div class="circleimage col-xs-12 col-sm-12 col-md-12 col-md-12"><a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('circleimage');
} 
?></a></div>
  <h3 class="col-xs-12 col-sm-12 col-md-12 col-md-12 text-center"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h3>
  <div class="col-xs-12 col-sm-12 col-md-12 col-md-12 catedatfont text-center"><?php $categories = get_the_category();
 
if ( ! empty( $categories ) ) {
    echo esc_html( $categories[0]->name );   
} ?></div>

 </li>

    
    <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>


<?php endif; ?>
<div class="clearfix"></div>
</ul>

    </div>

  
</div>
  <!-- Sticky post row -->

 <!--  <div class="row marginbottom">
<div class="col-xs-12 col-sm-12 starline">
<img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
</div>

  </div> -->
  <!-- Star with line row ends -->

   <!-- <div class="row marginbottom">

<?php // if ( is_active_sidebar( 'home_right_1' ) ) : ?>
  <div class="col-xs-12 col-sm-12 recentforumHomeActivity marginbottom" role="complementary">
    <?php //dynamic_sidebar( 'home_right_1' ); ?>
  </div>
<?php // endif; ?>

    </div> -->

 <div class="row marginbottom">
<div class="col-xs-12 col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>

 <div class="row marginbottom">
<div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>

  </div>

 <div class="row marginbottom">

  <div class="recentpostsection col-xs-12 col-sm-12">Recent Posts
  </div>
<div>
<?php 
if ( function_exists( 'ot_get_option' ) ) {
  $featurecatposts = ot_get_option( 'rgs_feature_cat_homepage' );
}
if ( function_exists( 'ot_get_option' ) ) {
  $featurecatposts2 = ot_get_option( 'rgs_feature_cat_homepageone2' );
}
if ( function_exists( 'ot_get_option' ) ) {
  $featurecatposts3 = ot_get_option( 'rgs_feature_cat_homepageone3' );
}
if ( function_exists( 'ot_get_option' ) ) {
  $featurecatposts4 = ot_get_option( 'rgs_feature_cat_homepageone4' );
}
$listofcat = array($featurecatposts, $featurecatposts2, $featurecatposts3,  $featurecatposts4);
foreach ($listofcat as $cat):
$args = array(
  'post__not_in' => array_merge($do_not_duplicate, get_option( 'sticky_posts' )),
'posts_per_page' => 1, // max number of post per category
'category__in' => array($cat)
);
$listquery = new WP_Query($args);
?>
<?php if ( $listquery ->have_posts() ) : ?>

  
  <!-- the loop -->
  <?php while ( $listquery ->have_posts() ) : $listquery ->the_post(); 

  ?>
<div class="col-xs-12 col-sm-12 lastqueryclass ">
<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">

<a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('homepagerecentpost');
} 
?></a>
</div>
<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 recenpostcatheading slidertextview">
<div class="thirdloopcat recentpostheading "><?php the_category( " "); ?><span class="glyphicon glyphicon-triangle-right"></span></div>

  <div class="rgsposttitle slidertextview circleimage1"><a  href="<?php the_permalink(); ?>" ><?php the_title();?></a></div>
  <div class=" catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php the_time('F j, Y'); ?></div>
<p><?php echo substr(get_the_excerpt(), 0,170); ?><span class="rgsreadmore"> . . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></span></p>

</div>
</div>

  <?php endwhile; ?>
    <?php wp_reset_postdata(); ?>


<?php endif; ?>

<?php endforeach; ?>

</div>
   
<!-- last row for ad -->
   <div class="row marginbottom">
<div class="col-xs-12 col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1,
  'offset' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>
</div>



</div>

<?php get_footer(); ?>