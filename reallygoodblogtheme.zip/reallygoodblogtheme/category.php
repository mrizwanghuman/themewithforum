<?php get_header(); ?>


<div class="row marginbottom">

<div class="col-xs-12 col-sm-12 col-md-12 rgsgatewaypage rgscategorypage">
<div class="row ">
  <div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 categorypagetitle">
<h1 ><?php  single_cat_title(); ?></h1>
</div>
<?php $category_id = get_query_var('cat');
$parent = $wpdb->get_var("SELECT parent FROM ".$wpdb->prefix."term_taxonomy WHERE term_id = $category_id"); ?>
<div class="col-md-2 col-lg-2 gatewaykidheading hidden-xs hidden-sm">
 
  <?php if($parent==1044) {
    ?>
<img src="<?php echo get_template_directory_uri(); ?>/images/K8Kids_Gateway.png" />

<?php }elseif ($parent==1043) {?>
  <img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/gatewayimagekid.png" />
<?php } 
  ?>
 
</div>



<div class=" col-xs-12 col-sm-12 col-md-3 col-lg-3 rgscategorypageh2 rgscateparent">
<?php 

echo get_cat_name( $parent );
?>
</div>

</div>

</div>

</div>

  <?php 
// the query
  $args = array('posts_per_page' => 1,
      'cat' => $cat);
$the_query = new WP_Query( $args ); ?>

<?php 

$do_not_duplicate = array();
if ( $the_query->have_posts() ) : ?>

  <!-- pagination here -->

  <!-- the loop -->
  <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
$do_not_duplicate[] = $post->ID;

  ?>
    
  
<div class="row marginbottom">
  <div class="col-xs-12 col-sm-12 borderclass getwaypageborderclass">
<div class="row no-pad">
      <?php $postdatenew = get_the_time('F j, Y'); ?>
       <?php
 $d=strtotime("-3 Months");
$pasthethreemontdate = date("m-d-y", $d);

if ($postdatenew > $pasthethreemontdate){?>

 <div class="newimage "><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/newBadgeupdated.png"></div>
<?php }?>


      <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8 getwaythumnailsize ">
        
   <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail('homepagesize');?></a>
  
</div>

<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4 gatewayheadingclass">
<h2 class="col-xs-12"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h2>
<div class="col-xs-12 catedatfont">
 
 <?php echo  $postdatenew ?>

</div>
 <div class="col-xs-12 "><?php the_excerpt(); ?></div>
 


</div>
   
</div>


</div>
</div>
<?php endwhile; wp_reset_postdata();?>

<?php endif; ?>


<div class="row ">

<?php 
// the query
$args2 = array('posts_per_page' => 2,
        'post__not_in' => $do_not_duplicate,
        'cat' => $cat);
$the_query = new WP_Query( $args2 ); ?>

<?php if ( $the_query->have_posts() ) : 
?>

  <!-- pagination here -->

  <!-- the loop -->
  <?php while ( $the_query->have_posts() ) : $the_query->the_post(); 
$do_not_duplicate[] = $post->ID;
  ?>
  
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 marginbottom">
<div class="row">
 
<div class="col-xs-6 col-sm-6 thumbnailslider2 borderclass">
<?php the_post_thumbnail( 'circleimage', array( 'title' => get_the_title() ) ); ?>
</div>

<div class="col-xs-6 col-sm-6 slidertextview">
<h3><a href="<?php the_permalink(); ?>"><?php the_title( ); ?></a></h3>
<div class="catedatfont"><?php echo get_the_time('F j, Y'); ?></div>

<p class="font16px hidden-sm hidden-xs"><?php echo substr(get_the_excerpt(), 0,80); ?> <div class="rgsreadmore smallerreadmore hidden-sm hidden-xs">. . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></div></p>

</div>
<div class="col-sm-12 col-xs-12 padding5px visible-sm visible-xs Rgscatpagexcerpt">
<p class="font16px "><?php echo substr(get_the_excerpt(), 0,80); ?> <div class="rgsreadmore smallerreadmore">. . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></div></p>
</div>

</div>
</div>

<?php  endwhile; ?>
<?php  wp_reset_postdata(); ?>


<?php endif; ?>

</div>

    <div class="row marginbottom panelareaforgateway">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 


  'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
<?php wp_reset_postdata(); ?>
 <?php
endwhile;
?>

</div>
  </div>


<div class="row borderclass marginbottom" id="ajax-posts">
<div class="col-xs-12 col-sm-12 marginbottom catepagestarone"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_TopStar.png"></div>

<h3 class="col-xs-12 col-sm-12 catedatfontsingelcat font-size26px">Recent Articles</h3>
<div class="col-sm-12">
  <div class="row ">
<?php 

$singlecate_args2 = array(
'posts_per_page'  =>8,
'post__not_in' => $do_not_duplicate,
'cat'             => $category_id
  );
$singcate_query2 = new WP_Query($singlecate_args2)?>
<?php while ( $singcate_query2->have_posts() ) : $singcate_query2->the_post(); 
$do_not_duplicate[] = $post->ID;

?>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 marginbottom">
<div class="row">
<div class="col-xs-5 col-sm-5 rgscatpagefeatureimg padding5px">

  <?php the_post_thumbnail( 'homepagesize', array( 'title' => get_the_title() ) ); ?>
</div>
<div class="col-xs-7 col-sm-7 slidertextview padding5px">
<h4><a class="recentarticletitles" href="<?php the_permalink(); ?>"><?php the_title( ); ?></a></h4>
<div class="catedatfont"><?php echo get_the_time('F j, Y'); ?></div>
</div>

</div>

  </div>

<?php endwhile; ?>
</div>
</div>

<div class=" col-sm-12 hiddenclassonclick">
  <div class="row">
<?php 

$singlecate_args = array(

'post__not_in' => $do_not_duplicate,
'cat'             => $category_id
  );
$singcate_query = new WP_Query($singlecate_args)?>
<?php while ( $singcate_query->have_posts() ) : $singcate_query->the_post(); 
$do_not_duplicate[] = $post->ID;

?>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 marginbottom">
<div class="row">
<div class="col-xs-4 col-sm-5 rgscatpagefeatureimg">

  <?php the_post_thumbnail( 'homepagesize', array( 'title' => get_the_title() ) ); ?>
</div>
<div class="col-xs-8 col-sm-7 slidertextview">
<h3><a href="<?php the_permalink(); ?>"><?php the_title( ); ?></a></h3>
<div class="catedatfont"><?php echo get_the_time('F j, Y'); ?></div>
</div>

</div>

  </div>

<?php endwhile; ?>
</div>
</div>

<div class="col-sm-12 marginbottom">
  <button class="buttonclick center-block sellallartbtn btn">See All Articles<span class="glyphicon glyphicon-triangle-bottom"></span></button>
</div>

<div class="col-xs-12 col-sm-12 marginbottom catepagestaronebottom"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_BottomStar-1.png">
</div>

</div>

<div class="row marginbottom">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>
<div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>


<div class="row hidden-sm hidden-xs multiimageslider ajax-posts">

<h3 class="col-xs-12 col-sm-12 trending catedatfontsingelcat">
<?php echo "Trending In ".get_cat_name( $parent ); ?>
  </h3>
  
<div  id="myCarousel" class="carousel slide col-sm-12 col-xs-12" data-ride="carousel"  >
   
 
 <div class="carousel-inner">

<!-- slide one -->
<div class="item active">
<ul>

<?php 

  

   
   $the_query1 = new WP_Query(array('posts_per_page' =>4,
        'post__not_in' => $do_not_duplicate,

        'cat' => $parent)); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();

  ?>

<li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>
</li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
<!-- slide two -->
<div class="item">

<ul>
<?php 
  

   $the_query2 = new WP_Query(array('posts_per_page' =>4,
        'post__not_in' => $do_not_duplicate,
        'offset'        => 4,
        'cat' => $parent)); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();

  ?>


  <li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>

<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>

  </li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

</ul>

</div>
<!-- slide three -->
<div class="item">

<ul>
<?php 
  

   $the_query2 = new WP_Query(array('posts_per_page' =>4,
        'post__not_in' => $do_not_duplicate,
        'offset'        => 8,
        'cat' => $parent)); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();

  ?>


  <li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>

<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>

  </li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

</ul>

</div>

 

 </div>
   <div class="hiddencontroll">
  <a class="left carousel-control" href="#myCarousel" role="button" data-slide="prev">
    <span class="rgsleftarrow"  aria-hidden="true"><img src="<?php bloginfo('template_url'); ?>/images/leftarrow.png"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarousel" role="button" data-slide="next">
    <span class="rgsrightarrow" aria-hidden="true"><img src="<?php bloginfo('template_url'); ?>/images/rightarrow.png"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

</div><!--  -->




</div>

<div class="row visible-sm visible-xs multiimageslider">
<h3 class="col-xs-12 col-sm-12 trending catedatfontsingelcat font-size26px">
<?php echo "Trending In ".get_cat_name( $parent ); ?>
  </h3>
 <!--  <div class="col-sm-1 col-xs-1 "> </div> -->
<div  id="myCarouselmobilecat" class="carousel slide col-sm-12 col-xs-12" data-ride="carousel"  >
   
 
 <div class="carousel-inner">


<div class="item active">
<ul>

<?php 
 
   $the_query1 = new WP_Query(array('posts_per_page' =>2,
        'post__not_in' => $do_not_duplicate,
        'cat' => $parent)); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2 paddingzero"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12 paddingzero">
 <div class="col-xs-12 recentpostheading paddingzero text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<h4 class="col-xs-12 catedatfontsingelcat paddingzero text-center trendingtitleslider"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4>
</div>
</li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>

<div class="item">

<ul>
<?php 
  

   $the_query2 = new WP_Query(array('posts_per_page' =>2,
        'post__not_in' => $do_not_duplicate,
        'cat' => $parent)); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();
$do_not_duplicate[] = $post->ID;
  ?>


  <li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2 paddingzero"><?php the_post_thumbnail('circleimage');?></div>

<div class="col-sm-12 paddingzero">
 <div class="col-xs-12 recentpostheading paddingzero text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<h4 class="col-xs-12 catedatfontsingelcat paddingzero trendingtitleslider text-center"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4>
</div>

  </li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

</ul>

</div>

<div class="item">

<ul>
<?php 
  

   $the_query3 = new WP_Query(array('posts_per_page' =>2,
        'post__not_in' => $do_not_duplicate,
        'cat' => $parent)); 
   while ( $the_query3->have_posts() ) : 
   $the_query3->the_post();
$do_not_duplicate[] = $post->ID;
  ?>


  <li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2 paddingzero"><?php the_post_thumbnail('circleimage');?></div>

<div class="col-sm-12 paddingzero">
 <div class="col-xs-12 recentpostheading paddingzero text-center">
  <?php
the_category(' ' );
 ?> 
 
 </div>
<h4 class="col-xs-12 catedatfontsingelcat paddingzero trendingtitleslider text-center"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4>
</div>

  </li>

<?php 
   endwhile; 
   wp_reset_postdata();
  ?>

</ul>

</div>


  

 </div>
 <div class="hiddencontroll">
  <a class="left carousel-control" href="#myCarouselmobilecat" role="button" data-slide="prev">
    <span class="rgsleftarrow"  aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rightarrow.png"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarouselmobilecat" role="button" data-slide="next">
    <span class="rgsrightarrow" aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/leftarrow.png"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div><!--  -->
<!-- <div class="col-sm-1 col-xs-1 rightimagecontrol"> </div> -->


</div>

 <div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>

<div class="row marginbottom">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>
<?php get_footer(); ?>