<?php 
/**
 * Template Name: register-confirmation
 * 
 */

?>



<?php get_header(); ?>

	  <div style= "padding: 25px 140px 250px 140px; ">
                          <p class="text-center" style="font-size: 19px;"><b><?php _e( 'Thank you for registering for Really Good Teachers&trade;!
To complete your registration, please follow the link in your email.', 'buddypress' ); ?></b></p>
                          </div>

<?php get_footer(); ?>