<?php 
/**
 * Template Name: forumrssfeed
 * 
 */

?>




  
    
<style>

img
{
  margin-top: 0px;
  
}

.rssincl-entry
{
  border-bottom: 1px solid gray;	
	
}


a.blog_read_more:link, a.blog_read_more:visited, a.blog_read_more:hover
{
  font-family: arial;	
  color: #4d9dd5;
 
  font-size: 13px;
  text-decoration: underline;
  line-height: 19px;

}

 a.blog_post_title:link, a.blog_post_title:visited
{
  font-family: arial;	
  color: #fe3f00;
  font-weight: bold;
  font-size: 19px;
  text-decoration: underline;
}




.blog_item_description
{
  font-family: arial;
  font-size: 16px;
  line-height: 19px;
  
	
}






.blog_item_date
{
   font-family: arial;
  font-size: 19px;
  color: #979797;
	
}

hr
{
  width: 100%;
  color: 1px solid gray;
  
}


.half {
	width: 50%;
	float: left;
}

.ng-row {
	clear: both;
}


</style>



<p>K8 Teacher Lounge Feed</p>








<?php
$catquery = new WP_Query( 'cat=1047&posts_per_page=2' );
while($catquery->have_posts()) : $catquery->the_post();
?>


 <table width="500">
  <tr>
    <td  valign="top" colspan="3">

      <span class="blog_item_title"><a href="<?php the_permalink() ?>" class="blog_post_title"><?php the_title(); ?></a></span>
    </td>
  </tr>
  <tr><td colspan="3" valign="top"><span class="blog_item_date"> <?php the_date() ?></span></td></tr>
  <tr>
    <td valign="top">
      <?php if ( has_post_thumbnail() ) : ?>
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
        <?php the_post_thumbnail('gateway');?>
        </a>
     <?php endif; ?>

    </td>
    <td style="width: 1px;"> &nbsp;</td>
    <td valign="top">
      <span class="blog_item_description"><?php rm_excerpt(27,''); ?></span><br>
       <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="blog_read_more" >Read More</a>


    </td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  </table>






<?php endwhile; ?>


<?php
$catquery = new WP_Query( 'cat=1048&posts_per_page=2' );
while($catquery->have_posts()) : $catquery->the_post();
?>


 <table width="500">
  <tr>
    <td  valign="top" colspan="3">

      <span class="blog_item_title"><a href="<?php the_permalink() ?>" class="blog_post_title"><?php the_title(); ?></a></span>
    </td>
  </tr>
  <tr><td colspan="3" valign="top"><span class="blog_item_date"> <?php the_date() ?></span></td></tr>
  <tr>
    <td valign="top">
      <?php if ( has_post_thumbnail() ) : ?>
        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
        <?php the_post_thumbnail('gateway');?>
        </a>
     <?php endif; ?>

    </td>
    <td style="width: 1px;"> &nbsp;</td>
    <td valign="top">
      <span class="blog_item_description"><?php rm_excerpt(27,''); ?></span><br>
       <a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>" class="blog_read_more" >Read More</a>


    </td>
  </tr>
  <tr><td>&nbsp;</td></tr>
  </table>


<?php endwhile; ?>














<div class="row forumMainPage" id="archiceforum">
	<div class="col-xs-12 col-sm-12 welcomeforumClass">
<h1>Welcome to the NEW Teacher Forum</h1>

	</div>

	<div class="col-sm-12 marginbottom">
<?php include('forumnavigation.php'); ?>
 
	</div>

	<div class="row marginbottom">
<?php 
// the query
$args =array(
	'post_type' => 'forum',
	'cat'		=>'announcements');
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	<!-- pagination here -->

	<!-- the loop -->
	<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
		<h2 ><?php the_title(); ?></h2>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php else : ?>
	<p><?php _e( 'Sorry, no posts matched your criteria.' ); ?></p>
<?php endif; ?>
</div>

</div>



