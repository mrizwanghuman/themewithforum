jQuery(function($) {

//*******************************Jquery Functions for forum listrak registration ********************************
//***************************************************************************************************************
//Function to center modal
$(function() {
  function reposition() 
  {
     var modal = $(this),
     dialog = modal.find('.modal-dialog');
     modal.css('display', 'block');
     
     // Dividing by two centers the modal exactly, but dividing by three 
     // or four works better for larger screens.
     dialog.css("margin-top", Math.max(0, ($(window).height() - dialog.height()) / 2));
  }
  // Reposition when a modal is shown
  $('.modal').on('show.bs.modal', reposition);
  // Reposition when the window is resized
  $(window).on('resize', function() {
       $('.modal:visible').each(reposition);
  });
});


$( document ).ready(function() {
    var registration_signup = getUrlParameter('reg_signup');
       
   if(registration_signup == "1")
   {  
     document.getElementById("lbl_email_blog_footer").style.display = "block";
     document.getElementById("email_address_promotional_footer").style.display = "block";
     $('#modal-blog-digest-footer').modal('show');
   }
    
});


//Required field validation for role dropdown list
//$("#field_258").change(function () {
   
  // var element_role = document.getElementById('field_258');
  // $( "#req_field_258" ).remove();
 
  // if( element_role.value == "")
  // {
  //    $("<div id='req_field_258' class='rgsErrorRegMsg' for='field_258'  >This field is required.</div>").insertBefore("#field_258");          
  // }
  // else
  // {
  //    $( "#req_field_258" ).remove();
  // }

//});

//Required field validation for grade dropdown list
//$("#field_274").change(function () {
   
  // var element_grade = document.getElementById('field_274');
  // $( "#req_field_274" ).remove();
   
  // if( element_grade.value == "")
  // {
  //    $("<div id='req_field_274' class='rgsErrorRegMsg' for='field_274'  >This field is required.</div>").insertBefore("#field_274");          
  // }
  // else
  // {
  //    $( "#req_field_274" ).remove();
  // }

//});

//On button click check if role or grade drop down is empty, show required field message
//$( "#signup_submit" ).click(function() {
  
//  var element_role = document.getElementById('field_258');
//  var element_grade = document.getElementById('field_274');
  
//  $( "#req_field_258" ).remove();
//  $( "#req_field_274" ).remove();
   
//  if( element_role.value == "")
//  {
//      $("<div id='req_field_258' class='rgsErrorRegMsg' for='field_258'  >This field is required.</div>").insertBefore("#field_258");   
//  }
  
//   if( element_grade.value == "")
//  {
//      $("<div id='req_field_274' class='rgsErrorRegMsg' for='field_274'  >This field is required.</div>").insertBefore("#field_274");         
//  }

//});




//******************** End forum registration Listrak functions*************************************************************
//**************************************************************************************************************************



//********************Jquery functions for footer and modal signup form*****************************************************
//**************************************************************************************************************************


//Get url parameter
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};



//Reset validation for footer email sign up
$('#email_address_blog_digest_footer').focus(function(){
    document.getElementById('email_address_blog_digest_footer').style.backgroundColor="white";   
    document.getElementById('email_address_blog_digest_footer').style.borderColor ="#70b80e"; 
    document.getElementById("email_address_validation_footer").innerHTML=""; 

});



//Reset modal registration form
function resetModalForm()
{
    $("#modal_signup_header").show(); 
    $("#modal_signup_body").show(); 
    $("#modal_signup_header_thank_you").hide();
    $("#modal_signup_body_thank_you").hide();
}

//Clear data for blog and promo registration form
function clearData()
{
   $("#form_blog_digest_footer").trigger('reset');
   $("#form_promotional_signup_footer").trigger('reset');
   document.getElementById("modal_form_validate_footer").innerHTML="";
   document.getElementById("email_address_validation_footer").innerHTML="";
}

//On modal close clear modal form data
$(window).on('hidden.bs.modal', function() { 
    $('#modal-blog-digest-footer').modal('hide');
    
          document.getElementById("modal_form_validate_footer").innerHTML="";
          document.getElementById("email_address_validation_footer").innerHTML="";
          resetModalForm();
          clearData();    
});



//************************End Jquery Functions for footer and modal signup form******************************
//***********************************************************************************************************

});



//***********************Javascript functions for footer and modal signup form*******************************
//***********************************************************************************************************

//Function to scroll top of page on modal show
function scrollTopModal()
{
  scroll(0,0);
}

//Get operating system
function getMobileOperatingSystem() 
{
  var userAgent = navigator.userAgent || navigator.vendor || window.opera;
  
  if( userAgent.match( /iPad/i ) || userAgent.match( /iPhone/i ) || userAgent.match( /iPod/i ) )
  {
    return 'iOS';

  }
  else if( userAgent.match( /Android/i ) )
  {
    return 'Android';
  }
  else
  {
    return 'unknown';
  }
}


//Detect if internet exployer
function detectExployer() {
    var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older => return version number
        return true;
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11 => return version number
        return true;
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
       // Edge (IE 12+) => return version number
       return true;
    }

    // other browser
    return false;
}

//Detect if Safari
function detectSafari(){

   if (navigator.userAgent.search("Safari") >= 0 && navigator.userAgent.search("Chrome") < 0) {
               
       return true                

   }
 }



//Function to determine which role check box is checked
function validate_role()
{
  var role_1 = document.getElementById("role_1").checked;
  var role_2 = document.getElementById("role_2").checked;
  var role_3 = document.getElementById("role_3").checked; 
  var role_4 = document.getElementById("role_4").checked;
 
  if(role_1 == true || role_2 == true || role_3 == true || role_4 == true)
  {
     return true;
  }
  else
  {
     return false;
  }
}



//Form validation and submition for footer signup form
function validate_blog_digest_email() 
{
   
   var email = document.getElementById('email_address_blog_digest_footer');
 
   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;


  
   if (!filter.test(email.value)) 
    {

       email.focus;
       document.getElementById('email_address_blog_digest_footer').style.backgroundColor="#ffe5e6";   
       document.getElementById('email_address_blog_digest_footer').style.borderColor ="red";     
       document.getElementById("email_address_validation_footer").innerHTML="Please enter a valid email address";
       return false;
   }
   else
   {
 
       //Redirect to http://rgsdevtest.staging.wpengine.com/email-validate/
       if(getMobileOperatingSystem() == "iOS" || detectSafari() == true)
       {
         
          document.getElementById("form_blog_digest_footer").action = "http://enews.reallygoodstuff.com/q/556-6s65gL6_ipeu0mDth_lCum6JKCEfav";
          document.getElementById("form_blog_digest_label").value="rkp8bhybRiwRe8daXfnhxfMZVDf8Urm23L_IHGLUTn-inhZwliXBY7yB1SBcWSkQ_TGtzlPKBP-ZEDCEAMknXYkenNgbrzLdVBgkJna8gW72WjYLTuldiFY2bIWjId9EfsbgdAYyzuZ9-p_ogHNOdQ"
          jQuery('#modal-blog-digest-footer').modal('show');
       }
       //Redirect to http://rgsdevtest.staging.wpengine.com/?reg_signup=1
       else if(detectExployer() == true)
       {
          
          
          document.getElementById("form_blog_digest_footer").action = "http://enews.reallygoodstuff.com/q/FSxv3bx8fKxPlUg6y-WwFPzE6-3JKEZ6hq";
          document.getElementById("form_blog_digest_label").value="9lJQ_cMaS624-lbyn3U4HTxj6c_xAtXZ5L0tszd6Tkwo83Z9J462VSMMja5Ciixy8oTASTlKt1qk41n2OJupSsWNuE9pKPTs7KQAXC9OuRvuz6cqsOz9XlMQI_IxXnZSwKEhxDaY1gnsOJ50dZgChA"

       }
       else
       {
          document.getElementById("form_blog_digest_footer").action = "http://enews.reallygoodstuff.com/q/ffWRDQWm2XWAreoBzSisVAcjBSD1KjwWPN";
          document.getElementById('form_blog_digest_label').value="rkp8bhybRiwRe8daXfnhxfMZVDf8Urm23L_IHGLUTn_FehOhqXYF-9xZSK51YJi18q-UlMVLCN3HOmY5Jgm8rw";
          document.getElementById('modal-blog-digest-footer').className = "modal fade";
          jQuery('#modal-blog-digest-footer').modal('show');
       }
       
       scrollTopModal();
       document.getElementById('email_address_blog_digest_footer').style.backgroundColor="white";   
       document.getElementById('email_address_blog_digest_footer').style.borderColor ="#70b80e"; 
       document.getElementById("email_address_validation_footer").innerHTML="";
       document.getElementById("email_address_promotional_footer").value = email.value;
       
   }
      
}






//Form validation and submition for modal email signup form
function validate_promotional_email()
{
   var promotional_subscribe = document.getElementById("promotional_subscribe").checked;
   var role_check = validate_role();

   var promotional_email = document.getElementById('email_address_promotional_footer');
   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

   if (!filter.test(promotional_email.value)) 
   {
       promotional_email.focus;
       document.getElementById("modal_form_validate_footer").innerHTML="*Please enter a valid email address<br>";
       return false;
   }
   else
   {
      document.getElementById("modal_form_validate_footer").innerHTML="";
      if(promotional_subscribe == false && role_check == false)
      {
        document.getElementById("modal_form_validate_footer").innerHTML="Please make a selection<br>";
        return false;
      }
      else if(promotional_subscribe == false && role_check == true)
      {
        document.getElementById("modal_form_validate_footer").innerHTML="Please check opt in box<br>";
        return false;
      }
      else if(role_check == false)
      {
        document.getElementById("modal_form_validate_footer").innerHTML="Please select a role<br>";
        return false;
      }
      else
      {
        
       //Redirect to http://rgsdevtest.staging.wpengine.com/email-validate/
       if(getMobileOperatingSystem() == "iOS" || detectSafari() == true)
       {
         
          document.getElementById("form_promotional_signup_footer").action = "http://enews.reallygoodstuff.com/q/0g7NZG7R_R7WEq3OzyebgWQ1OyZoK1VR1B";
          document.getElementById("lbl_promotional_signup_footer").value="vRfybwZRWW3Mgrz6L6_xYS8E4a8wbI5u2LUArJEgaMw3HZHqHzn4wzgPiyMr4-zvcwroJ_8qga_IhI37MDZEzhN78CPIvj-JyAJEMIBxEs-TbjIzPv42jZR24OiO2nIyfojPV8V447MSTI6mxTQgqA"
       }
        //Redirect to http://rgsdevtest.staging.wpengine.com/email-validate/?reg_signup=finish
        else if(detectExployer() == true)
       {

          document.getElementById("form_promotional_signup_footer").action = "http://enews.reallygoodstuff.com/q/ZMZ5tYZFLoZyA0KNIjgV9yR7NjtJK7tviG";
          document.getElementById('lbl_promotional_signup_footer').value="hvUX1T5BryDDckhbXvOTL3CScvKA4vNQiWypIeH_No1JktMfgrJRly-YGKq25k3hj_Fg-bdqnpmjj-RRKeaJw19DwWhu6ZIviHdJmtw6zFK8gAIzX7XixMkNycnEWwpKPEOEbr48EI-wgcit9H8UtQ";


       }
       else
       {
          document.getElementById("form_promotional_signup_footer").action = "http://enews.reallygoodstuff.com/q/LdMSkQMjsAMODN0cfmvN6O2ycmk-Kyn6KL";
          document.getElementById('lbl_promotional_signup_footer').value="oBHD5hWxO85QUFZRu6orlnMrckeuFJOKiXo6WbSH7A1I6CQ-2hyS7V0-UfbZtqyUFjlkESlg4K1adeHGVFjg5w";
       }


        scrollTopModal();
        document.getElementById("modal_form_validate_footer").innerHTML="";
        jQuery("#modal_signup_header").hide(); 
        jQuery("#modal_signup_body").hide(); 
        jQuery("#modal_signup_header_thank_you").show();
        jQuery("#modal_signup_body_thank_you").show();
        return true;
      }
   }
}

//**********************End javascript functions for footer and modal signup form**************************
//*********************************************************************************************************





//********************javascript functions for forum Listrak registration form****************************
//********************************************************************************************************



//Reset role checkboxes
function reset_role_data_forum()
{
   document.getElementById("ltk_role_forum_temp_1").checked = false;
   document.getElementById("ltk_role_forum_temp_2").checked = false;
   document.getElementById("ltk_role_forum_temp_3").checked = false;
   document.getElementById("ltk_role_forum_temp_4").checked = false;

}

//Function to determine role by grade dropdown
function calculate_role_by_grade_forum()
{
   
    var gradecheck = document.getElementById("field_274");
    
    if(gradecheck.value == "")
    {

    }
    else if(gradecheck.value == "Early Childhood")
    {
        document.getElementById("ltk_role_forum_temp_3").checked = true;
    }
    else if(gradecheck.value == "Preschool")
    {
      
        document.getElementById("ltk_role_forum_temp_3").checked = true;
    }
    else
    {
        document.getElementById("ltk_role_forum_temp_1").checked = true;
    }
  
}
   

//Function to determing role by role dropdown
function calculate_role_by_position_forum()
{
  // var element = document.getElementById('field_258');
     
     var rolcheck = document.getElementById("field_258");
     reset_role_data_forum();

     if(rolcheck.value == "")
     {
       //do nothing
     }
     else if(rolcheck.value == "Administrator")
     {
       document.getElementById("ltk_role_forum_temp_2").checked = true;
     }
     else if(rolcheck.value == "Childcare Professional")
     { 
       document.getElementById("ltk_role_forum_temp_3").checked = true;
     }
     else if(rolcheck.value == "Parent")
     {
       document.getElementById("ltk_role_forum_temp_4").checked = true;
     }
     else if(rolcheck.value == "Classroom Teacher")
     {    
       calculate_role_by_grade_forum();
     }
     else if (rolcheck.value == "Student Teacher")
     {      
       calculate_role_by_grade_forum();
     } 
     else if (rolcheck.value == "Substitute Teacher")
     {
       calculate_role_by_grade_forum();
     }
     else
     {
       document.getElementById("ltk_role_forum_temp_1").checked = true;
     }
}



//Submit the forum registration for Listrak signup
function submit_listrak_registration_forum()
{
    document.getElementById('signup_submit').style.display = 'none';
    document.getElementById('blog_promo_signup_box').style.display = 'none';
    
    //document.getElementById("signup_form").style.display="block";
    if(document.getElementById('forum_blog_signup_chkbox').checked == true && document.getElementById('forum_promotional_signup_chkbox').checked == false ) 
    {
       var requestDelay = 1000;
       
       setTimeout(function() {
       document.getElementById("form_blog_digest_forum").submit();
       }, requestDelay);
    }
    else if(document.getElementById('forum_promotional_signup_chkbox').checked == true && document.getElementById('forum_blog_signup_chkbox').checked == false )
    {
       var requestDelay = 1000;
       
       setTimeout(function() {
       document.getElementById("form_promotional_forum").submit();
       }, requestDelay);
    }
    else if(document.getElementById('forum_blog_signup_chkbox').checked && document.getElementById('forum_promotional_signup_chkbox').checked)
    {
       var requestDelayBlog = 1000;
       var requestDelayPromo = 1400;         
 
       setTimeout(function() {
       document.getElementById("form_blog_digest_forum").submit();
       }, requestDelayBlog);

       setTimeout(function() {
       document.getElementById("form_promotional_forum").submit();
       }, requestDelayPromo);
    }
}








