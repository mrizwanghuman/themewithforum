
jQuery(function($) {


// <!-- auto-generate carousel indicator html -->
var myCarousel = $("#carousel-home");
myCarousel.append("<ol class='carousel-indicators'></ol>");
var indicators = $(".carousel-indicators"); 
myCarousel.find(".carousel-inner").children(".item").each(function(index) {
    (index === 0) ? 
    indicators.append("<li data-target='#myCarousel' data-slide-to='"+index+"' class='active'></li>") : 
    indicators.append("<li data-target='#myCarousel' data-slide-to='"+index+"'></li>");
});     

// <!-- then call carousel -->
$('.carousel').carousel();

    $('.menu-item-has-children').each(function(i, e){
    $(this).append("<span class='rgsmenuarrow dropdown-toggle' ></span>");
    $(this).find(".rgsmenuarrow").attr("id", "rgsmenuarrow_" + i);
}); 




$(".rgsmenuarrow, .rgsmenuarrowafter").click(function(event) {
     //Act on the event 
   
    $(this).toggleClass('rgsmenuarrow rgsmenuarrowafter');
   
    event.stopPropagation();
});

$("#rgsmenuarrow_0").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $("#menu-item-12542 .dropdown-menu").toggle();
});
$("#rgsmenuarrow_1").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $("#menu-item-12552 .dropdown-menu").toggle();
});

$("#rgscategorieslist li").addClass('col-xs-12 col-sm-6 col-md-4');



if ($(".rgsteacherlogincol").children().hasClass("rgsteacherlogin2")){
   $('.hoverTeacherlogin').hide();

$('#welcomeuserli').click(function(){
  // $('#welcomeuserli li span').remove();

  $('#welcomeuserli li span').toggleClass('glyphicon-triangle-top');

$('.hoverTeacherlogin').toggle();

  });

}



$( document ).on( 'click', '.love-button', function(event) {
  event.preventDefault();
  var post_id = $(this).data('id');
 $.ajax({
    url : postlove.ajax_url,
    type : 'post',
    data : {
      action : 'post_love_add_love',
      post_id : post_id
    },
    success : function( response ) {
      $('#love-count').html( response );
    }
  });
});





  // Get the #comments div
  var commentsDiv = $('#comments');

  // Only do this work if that div isn't empty
  if (commentsDiv.length) {

    // Hide the comments div by default
    $(commentsDiv).hide();

    // Append a link to show/hide
    $('<a/>')
      .attr('class', 'toggle-comments')
      .attr('href', '#')
      .text('Show Comments')
      .insertBefore(commentsDiv);

    // when show/hide is clicked
    $('.toggle-comments').on('click', function(e) {
      e.preventDefault();

      // show/hide the div using jquery's toggle()
      $(commentsDiv).toggle('slow', function() {
        // change the text of the anchor
        var anchor = $('.toggle-comments');
        var anchorText = anchor.text() == 'Show Comments' ? 'Hide Comments' : 'Show Comments';
        $(anchor).text(anchorText);
      });
    });

  } // End if commentsDiv.length


$('.replyclass').click(function(event) {
  /* Act on the event */
  
  event.preventDefault();
var showidcomment = $(this).next('div').attr('id');

 $('#' +showidcomment).toggle();
$(this).parent().prev('.commentTextId p').css({
  background: 'blue',
  
});
});

       
      /* Act on the event */
       
   

$("#postAnewReply").click(function(event) {
  /* Act on the event */
  event.preventDefault();
  $(this).hide();
  $("#rgshiddenReplypost").slideToggle( "slow");
});
$(".buttonclick").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $(".hiddenclassonclick").show();
});
$("#rgs_user_loginform input[type=text], #rgs_user_loginform input[type=password]").addClass('form-control');
$("#rgs_user_loginform input[type=submit]").addClass('btn sellallartbtn center-block');

$(".nextotembox").appendTo('.termandcondition');

$.validator.addMethod("pwcheck", function(value) {
   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
       && /[a-z]/.test(value) // has a lowercase letter
       && /\d/.test(value) // has a digit
});

$("#signup_form").each(function() {  // attach to all form elements on page
        $(this).validate({       // initialize plugin on each form
            // global options for plugin
            errorClass: 'rgsErrorRegMsg',
   errorElement: 'div',
   errorPlacement: function(error, element) {
    error.insertBefore(element.closest('div.form-group'))
  },
rules: {
signup_username: {
  required: true,
  minlength: 2

},
signup_email: {
  required: true,
  email: true,
},
signup_password: {
  required: true,
  minlength: 8,
  pwcheck: true,
},
signup_password_confirm: {
  required: true,
  equalTo:"#signup_password",
},
field_1: {
  required:true,
},
field_29: {
  required:true,
},
field_12: {
  required:true,
},
field_46: {
  required: true,
},
field_77: {
  required: true,
},
"field_113[]": {
  required: true,
},
field_228: {
  required: true,
},
field_146: {
  required: true,
},
field_257: {
  required: true,
},
field_258: {
  required: true,
},
field_274: {
  required: true,
},
field_288: {
  required: false,
  number:true,
  minlength: 4,
  maxlength:4,
}

},
messages: { 

        "field_113[]": "This checkbox is required.",
        signup_password: "Minimum of 8 characters including 1 number.",
        
            
            
        },
 

        });
    });

$("#forgot_password").validate({
  errorClass: 'rgsErrorRegMsglogin',
   errorElement: 'div',
   errorPlacement: function(error, element) {
        error.insertBefore(element)
      },
     rules: {
            user_login: {
                required: true,
                
            }, 
          }
});
$.validator.messages.equalTo = 'Passwords do not match';
$("#login").validate({
errorClass: 'rgsErrorRegMsglogin',
   errorElement: 'div',
   errorPlacement: function(error, element) {
        error.insertBefore(element)
  },
});



$('#commentform').validate({ // initialize the plugin
  errorClass: 'rgsErrorRegMsg',
   errorElement: 'div',
   errorPlacement: function(error, element) {
    error.insertBefore(element)
  },
        rules: {
            comment: {
                required: true,
                
            },
            
        }
    });
$('.search-submit ').attr('disabled',true);
    $('.search-field').keyup(function(){
        if($(this).val().length !=0)
            $('.search-submit').attr('disabled', false);            
        else
            $('.search-submit').attr('disabled',true);
    });


$("#rgshiddenThreadpost #tinymce p").text('some text');

$("#new-post").validate({
  
  errorClass: 'rgsErrorRegMsg',
   errorElement: 'div',
   errorPlacement: function(error, element) {
    error.insertBefore(element)
  },
    rules: {
            bbp_topic_title: {
                required: true,
                
            },
            bbp_topic_content: {
              required: true,
            },
           
            
        }
});

// Javascript to enable link to tab
var hash = document.location.hash;
var prefix = "tab_";
if (hash) {
    $('.nav-tabs a[href='+hash.replace(prefix,"")+']').tab('show');
} 

// Change hash for page-reload
$('.nav-tabs a').on('shown', function (e) {
    window.location.hash = e.target.hash.replace("#", "#" + prefix);
});

// $(".wpfp-span").on('click', function(event) {
//   event.preventDefault();
//   /* Act on the event */
//   if($('.wpfp-span').next().find('#addedtextfav ')){
// $('#texttosave').text('Saved');
// }
// });
// $(".wpfp-span").on('click', function(event) {
//   event.preventDefault();
//   /* Act on the event */

//  if($('.wpfp-span').next().find('.removedtext  ')){
// $('#texttosave').text('Removed');
// }
// });


// $('#clicktoscrol').on('click',  function(event) {
//   event.preventDefault();
//   /* Act on the event */
//   $('body').scrollTo('.rgscommentscountheading ', {duration:'slow'})
// });


// $(document).on( 'click', '.nav-links a', function( event ) {
//    event.preventDefault();
//   $.ajax({
//     url: rgsajaxcall.ajaxurl,
//     type: 'post',
//     data: {
//       action: 'rgsmainjsfile'
//     },
//     beforeSend: function() {
            
//              $("#appendto").addClass('loading');
//         },
//     success: function( result ) {
//        $("#appendto").removeClass('loading');
//       $("#appendto").append(result);
      
//     }
//   });
//   });

$(".postreplyformtitle, #rgshiddenReplypost form legend").append("<div class='color898989 pull-right closethisbtn'>X</div>");

$(".closethisbtn").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $("#rgshiddenThreadpost, #rgshiddenReplypost, #prePostterms").hide('slow');
  $("#postAnewThread, #postAnewReply").show('slow');
});
$("#postAnewThread").click(function(event) {
  /* Act on the event */
  event.preventDefault();
  $("#prePostterms, #rgshiddenReplypost").slideToggle( "slow");
  $(this).hide('slow');
});
$('.rgspostTopicagree').on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $("#prePostterms").hide();
  $("#rgshiddenThreadpost").show();

});
//     $("#searchsubmit").click(function(e){
//         e.preventDefault();
//         var search_val=$("#s").val(); 
//         $.ajax({
//             type:"POST",
//             url: "./wp-admin/admin-ajax.php",
//             data: {
//                 action:'wpa56343_search', 
//                 search_string:search_val
//             },
//             success:function(data){
//                 $('#results').append(response);
//             }
//     });   
// });
$("#postAnewReplytwo").on('click', function(event) {
  event.preventDefault();
  /* Act on the event */
  $(this).hide();
  $("#rgshiddenReplyposttwo").show();
});

$("#field_288").closest(".col-sm-4").next().html('<span>Optional</span>');

$(".emaillink").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
 
$('#commentsText').html($("#rgshiddensharedlink").html());

});


});


function activateTab(pageId) {
          var tabCtrl = document.getElementById('tabCtrl');
          var pageToActivate = document.getElementById(pageId);
          for (var i = 0; i < tabCtrl.childNodes.length; i++) {
              var node = tabCtrl.childNodes[i];
              if (node.nodeType == 1) { /* Element */
                  node.style.display = (node == pageToActivate) ? 'block' : 'none';
              }
          }
      }
var data = {
    action: 'is_user_logged_in'
};

jQuery.post(ajaxurl, data, function(response) {
    if(response == 'yes') {
        // user is logged in, do your stuff here
        $("#rgssaveit").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $(".showsaved").show('slow', function() {
    $(".showsaved").delay(5000).fadeOut("slow");
  });


});

$("#showunsaved").on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  $(".showunsaved").show('slow', function() {
    $(".showunsaved").delay(5000).fadeOut("slow");
  });


});
    } else {
        // user is not logged in, show login form here
    }
});

jQuery('#showmorepostsbutton').on('click',  function(event) {
  event.preventDefault();
  /* Act on the event */
  jQuery(".displaynon").slideDown();
});


jQuery.validator = function( options, form ) {
    this.settings = $.extend( true, {}, $.validator.defaults, options );
    this.currentForm = form;
    this.init();
};


jQuery("#rgspencillink").on('click', function(event) {
  event.preventDefault();
  /* Act on the event */

  jQuery(".rgsublinkpf").toggle("slow");
});



    if (window.location.href.indexOf("settings") != -1) {
        jQuery("#hidepublicpf").hide();
        jQuery(".rgsprofilenav #settings-personal-li").hide();
    }
jQuery(".bbp-breadcrumb ").find('a.bbp-breadcrumb-forum:first').css({
  color: '#898989'}).removeAttr('href');
jQuery(".rgsshareviaemail").hide();
jQuery(".emaillink").on('click',  function(event) {
  event.preventDefault();
  jQuery(".rgsshareviaemail").slideToggle("slow");
  /* Act on the event */
});
jQuery(".removeachortag a").removeAttr('href');
jQuery("#bbp_topic_subscription").parent().css({
  marginTop: '10px',
  
});
