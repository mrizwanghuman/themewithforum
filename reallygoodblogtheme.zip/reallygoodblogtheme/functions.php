<?php

/**
 * Required: set 'ot_theme_mode' filter to true.
 */
add_filter( 'ot_theme_mode', '__return_true' );

/**
 * Required: include OptionTree.
 */
require( trailingslashit( get_template_directory() ) . 'option-tree/ot-loader.php' );
/**
 * Theme Options
 */
require( trailingslashit( get_template_directory() ) . 'inc/theme-options.php' );

/* ----------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------
                                Theme style and Javascript
    ----------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------
*/
// styles registration with theme
add_action("wp_enqueue_scripts", "rgs_styles_register");

// scripts registration with theme
add_action("wp_enqueue_scripts", "rgs_scripts_register");


// style sheet registration function

function rgs_styles_register() {



        wp_enqueue_style("bootsrapcss", get_template_directory_uri()."/css/bootstrap.min.css" );

        wp_enqueue_style("font-awesome", "https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css" );
wp_enqueue_style("modal-form-elements", get_template_directory_uri()."/css/email/modal-form-elements.css" );

wp_enqueue_style("modal-style", get_template_directory_uri()."/css/email/modal-style.css" );


wp_enqueue_style("mainstylesheet", get_template_directory_uri()."/style.css" );


wp_enqueue_style("googlefontssatisfy", 'https://fonts.googleapis.com/css?family=Poppins:400,700|Satisfy|Hind:400,700 ' );

wp_enqueue_style("bootsrapcustomizcss", get_template_directory_uri()."/css/boottrapcustomization.css" );

wp_enqueue_style("rgsforum", get_template_directory_uri()."/css/rgsforum.css" );
wp_enqueue_style("rgsloginajax", get_template_directory_uri()."/css/ajax-auth-style.css" );


}
// scripts sheet registration function
function rgs_scripts_register(){
    

        wp_enqueue_script( "bootsrapscripts", get_template_directory_uri()."/js/bootstrap.min.js" , array( 'jquery' ), " ", true );
    
    wp_enqueue_script( "rgsmainjsfile", get_template_directory_uri()."/js/rgsmainjs.js" , 
                        array( 'jquery' ), " ", true );
    

       wp_enqueue_script( "formregistration", get_template_directory_uri()."/js/form-registration.js" , 
                        array( 'jquery' ), " ", false );

       wp_localize_script( 'rgsmainjsfile', 'rgsajaxcall', array(
    'ajaxurl' => admin_url( 'admin-ajax.php' ),
    'query_vars' => json_encode( $wp_query->query )
));
  wp_enqueue_script( "validationjquery", get_template_directory_uri()."/js/jquery-validate.js" , 
                        array( 'jquery' ), " ", true );
      
  
  
  }
require_once('wp_bootstrap_navwalker.php');
/* ----------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------
                                Theme Support 
    ----------------------------------------------------------------------------------
    ---------------------------------------------------------------------------------
*/

    function rgscustom_theme_setup() {
    // thumbnail theme support 
add_theme_support("post-thumbnails" );
// header theme support
$defaults = array(
    'default-image'          => '',
    'random-default'         => false,
    'width'                  => 0,
    'height'                 => 0,
    'flex-height'            => false,
    'flex-width'             => false,
    'default-text-color'     => '',
    'header-text'            => true,
    'uploads'                => true,
    'wp-head-callback'       => '',
    'admin-head-callback'    => '',
    'admin-preview-callback' => '',
);
add_theme_support( 'custom-header', $defaults );
// title tag theme support
add_theme_support( 'title-tag' );
add_theme_support("custom-background" );

add_theme_support( 'automatic-feed-links' );

// html5 theme support
add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' ) );
}

add_action( 'after_setup_theme', 'rgscustom_theme_setup' );



/**
 * Register our sidebars and widgetized areas.
 *
 */

/* Theme setup */
add_action( 'after_setup_theme', 'rgs_setup' );
    if ( ! function_exists( 'rgs_setup' ) ):
        function rgs_setup() {  
            register_nav_menu( 'primary', __( 'Primary navigation', 'reallygoodstufftheme' ) );
            register_nav_menu( 'footer', __( 'Footer Menu', 'reallygoodstufftheme' ) );

             register_nav_menu( 'userloginmenu', __( 'User Menu', 'reallygoodstufftheme' ) );
             register_nav_menu( 'rgsforummenu', __( 'Forum Menu', 'reallygoodstufftheme' ) );
        } endif;




add_image_size( 'homepagesize', 620, 350, true); // Hard crop  
add_image_size( 'gateway', 274, 274, true ); // Hard crop 
add_image_size( 'email', 168, 168, true); // Hard crop
add_image_size( 'circleimage', 210, 210, true );

function new_excerpt_more($more) {
       global $post;
    return '<span class="rgsreadmore"> . . . <a href="'. get_permalink($post->ID) . '">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></span>';
}

add_filter('excerpt_more', 'new_excerpt_more');

function custom_excerpt_length( $length ) {
  return 30;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );


// Register a top alert message


function RGS_alert_message() {
    $args = array(
      'public' => true,
      'label'  => 'Alert Message'
    );
    register_post_type( 'topmain_alert', $args );
}
add_action( 'init', 'RGS_alert_message' );

function RGS_homepage_adzone() {
    $args = array(
      'public' => true,
      'label'  => 'Home Page Adzone1'
    );
    register_post_type( 'rgs-homepage-adzon1', $args );
}
add_action( 'init', 'RGS_homepage_adzone' );


add_filter( 'the_author', 'guest_author_name' );
add_filter( 'get_the_author_display_name', 'guest_author_name' );

function guest_author_name( $name ) {
global $post;

$author = get_post_meta( $post->ID, 'guest-author', true );

if ( $author )
$name = $author;

return $name;
}
add_action( 'init', 'blockusers_init' );
function blockusers_init() {
if ( is_admin() && ! current_user_can( 'administrator' ) &&
! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
wp_redirect( home_url() );
exit;
}
}


 add_filter('register','register_text_change');
function register_text_change($text) {

    $register_text_before = 'Site Admin';
    $current_user = wp_get_current_user();
    $firstname = $current_user->user_firstname ; 
    
    $text = str_replace($register_text_before, $firstname ,$text);

    return $text;
}

add_filter('previous_posts_link_attributes', 'posts_link_attributes');

function manage_my_category_columns($columns)
{
 // add 'My Column'
 $columns['catids'] = 'ID';

 return $columns;
}
add_filter('manage_edit-category_columns','manage_my_category_columns');

function manage_category_custom_fields($deprecated,$column_name,$term_id)
{
 if ($column_name == 'catids') {
   echo $term_id;
 }
}
add_filter ('manage_category_custom_column', 'manage_category_custom_fields', 10,3);




/**
 * Register our sidebars and widgetized areas.
 *
 */
  
function home_page_bbpress_widgets_init() {

    register_sidebar( array(
        'name'          => 'Home Page Forum Recent Activities',
        'id'            => 'home_right_1',
        'before_widget' => '<div>',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="recentpost">',
        'after_title'   => '</h2>',
    ) );

}
add_action( 'widgets_init', 'home_page_bbpress_widgets_init' );


add_action('wp_ajax_infinite_scroll', 'wp_infinitepaginate');           // for logged in user
add_action('wp_ajax_nopriv_infinite_scroll', 'wp_infinitepaginate');    // if user not logged in

function wp_infinitepaginate(){
    $loopFile        = $_POST['loop_file'];
    get_template_part( $loopFile );
    exit;
}

function social_media() {
 
if (is_single()) {
    global $post;
        echo '<div class="social-post">
        <div class="counter-twitter"><a data-related="DIY_WP_Blog" href="http://twitter.com/share" class="twitter-share-button" data-text="' . get_the_title($post->ID) . ' —" data-url="' . get_permalink($post->ID) . '" data-count="vertical">Tweet</a></div>' . "\n";
?>
        <div class="counter-fb-like">
        <div id="fb-root"></div><fb:like layout="box_count" href="<?php the_permalink(); ?>" send="false" width="50" show_faces="false"></fb:like>
        </div>
        <div class="counter-google-one"><g:plusone size="tall" href="<?php the_permalink(); ?>"></g:plusone></div>
</div>
        <?php }
}
 
function java_to_bottom() {
    if (is_single(array())) { // Change the name to match the name(s) of the pages using the form ?>
<script>(function(d, s) {
  var js, fjs = d.getElementsByTagName(s)[0], load = function(url, id) {
    if (d.getElementById(id)) {return;}
    js = d.createElement(s); js.src = url; js.id = id;
    fjs.parentNode.insertBefore(js, fjs);
  };
  load('//connect.facebook.net/en_US/all.js#xfbml=1', 'fbjssdk');
  load('https://apis.google.com/js/plusone.js', 'gplus1js');
  load('//platform.twitter.com/widgets.js', 'tweetjs');
}(document, 'script'));</script>
 
        <?php } }
add_action('wp_footer', 'java_to_bottom');


function wpb_set_post_views($postID) {
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    }else{
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
//To keep the count accurate, lets get rid of prefetching
remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);

function wpb_track_post_views ($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;    
    }
    wpb_set_post_views($post_id);
}
add_action( 'wp_head', 'wpb_track_post_views');

function wpb_get_post_views($postID){
    $count_key = 'wpb_post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count==''){
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
        return "0 View";
    }
    return $count;
}


function featuredtoRSS($content) {
global $post;
if ( has_post_thumbnail( $post->ID ) ){
$content = '<div>' . get_the_post_thumbnail( $post->ID, 'large', array( 'style' => 'margin-bottom: 15px;' ) ) . '</div>' . $content;
}
return $content;
}
 
add_filter('the_excerpt_rss', 'featuredtoRSS');
add_filter('the_content_feed', 'featuredtoRSS');




add_filter('show_admin_bar', '__return_false');

//Add custom excerpt functionality
function rm_excerpt($limit = null, $separator = null) {

    // Set standard words limit
    if (is_null($limit)){
        $excerpt = explode(' ', get_the_excerpt(), '15');
    } else {
        $excerpt = explode(' ', get_the_excerpt(), $limit);
    }

    // Set standard separator
    if (is_null($separator)){
        $separator = '...';
    }

    // Excerpt Generator
    if (count($excerpt)>=$limit) {
        array_pop($excerpt);
        $excerpt = implode(" ",$excerpt).$separator;
    } else {
        $excerpt = implode(" ",$excerpt);
    }   
    $excerpt = preg_replace('`\[[^\]]*\]`','',$excerpt);
    echo $excerpt;
}


function hide_before ($args = array() ) {
$args['before'] = '';
return $args;
}
add_filter ('bbp_before_get_forum_subscribe_link_parse_args','hide_before') ;
 
function rk_sticky_topics() {
  
   if ( bbp_is_topic_sticky() && !bbp_is_topic_closed() )
      echo '<span class="rgsstickytopic col-sm-2 paddingzero">Sticky</span>';
}
  
add_action( 'bbp_theme_before_topic_title', 'rk_sticky_topics' );

function bbp_enable_visual_editor( $args = array() ) {
    $args['tinymce'] = true;
     $args['quicktags'] = false;
     $args['teeny'] = false;
    return $args;
}
add_filter( 'bbp_after_get_the_content_parse_args', 'bbp_enable_visual_editor' );
function bbp_tinymce_paste_plain_text( $plugins = array() ) {
    $plugins[] = 'paste';
    return $plugins;
}
add_filter( 'bbp_get_tiny_mce_plugins', 'bbp_tinymce_paste_plain_text' );



 

require_once( get_template_directory() . '/inc/custom-ajax-auth.php' );

function custom_bp_datebox($html, $type, $day, $month, $year, $field_id, $date) {       
    if($type == 'year'){
   
        $html = '<option value=""' . selected( $year, '', false ) . '>----</option>';

        for ( $i = 2016; $i > 1944; $i-- ) {
                $html .= '<option value="' . $i .'"' . selected( $year, $i, false ) . '>' . $i . '</option>';
        }
    }
    return $html;
}
add_filter( 'bp_get_the_profile_field_datebox', 'custom_bp_datebox',10,7);

/**
 * Include bbPress 'topic' custom post type in WordPress' search results */

function ntwb_bbp_topic_cpt_search( $topic_search ) {
    $topic_search['exclude_from_search'] = false;
    return $topic_search;
}
add_filter( 'bbp_register_topic_post_type', 'ntwb_bbp_topic_cpt_search' );

// function searchfilter($query) {
//     if ($query->is_search && !is_admin() ) {
//         if(isset($_GET['post_type'])) {
//             $type = $_GET['post_type'];
//                 if($type == 'post') {
//                     $query->set('post_type',array('post'));
//                 }
//         }       
//     }
// return $query;
// }
// add_filter('pre_get_posts','searchfilter');
if (!is_admin())    {

add_filter('posts_orderby', 'group_by_post_type', 10, 2);
function group_by_post_type($orderby, $query) {
global $wpdb;
if ($query->is_search) {
    return $wpdb->posts . '.post_type DESC';
}
// provide a default fallback return if the above condition is not true
return $orderby;
}
}
function __search_by_title_only( $search, &$wp_query )
{
    global $wpdb;
    if(empty($search)) {
        return $search; // skip processing - no search term in query
    }
    $q = $wp_query->query_vars;
    $n = !empty($q['exact']) ? '' : '%';
    $search =
    $searchand = '';
    foreach ((array)$q['search_terms'] as $term) {
        $term = esc_sql($wpdb->esc_like($term));
        $search .= "{$searchand}($wpdb->posts.post_title LIKE '{$n}{$term}{$n}')";
        $searchand = ' AND ';
    }
    if (!empty($search)) {
        $search = " AND ({$search}) ";
        if (!is_user_logged_in())
            $search .= " AND ($wpdb->posts.post_password = '') ";
    }
    return $search;
}
add_filter('posts_search', '__search_by_title_only', 500, 2);

add_filter('posts_orderby','my_sort_custom',10,2);
function my_sort_custom( $orderby, $query ){
    global $wpdb;

    if(!is_admin() && is_search()) 
        $orderby =  $wpdb->prefix."posts.post_type ASC, {$wpdb->prefix}posts.post_date DESC";

    return  $orderby;
}

function hide_before2 ($args = array() ) {
$args['before'] = '';
$args['subscribe'] = 'Follow';  
$args['unsubscribe'] = 'Unfollow'; // or whatever
 
 return $args;
} 

add_filter('bbp_before_get_user_subscribe_link_parse_args', 'hide_before2');

/*
 * Search only a specific forum
 */
function my_bbp_filter_search_results( $r ){
 
    //Get the submitted forum ID (from the hidden field added in step 2)
    $forum_id = sanitize_title_for_query( $_GET['bbp_search_forum_id'] );
 
    //If the forum ID exits, filter the query
    if( $forum_id && is_numeric( $forum_id ) ){
 
        $r['meta_query'] = array(
            array(
                'key' => '_bbp_forum_id',
                'value' => $forum_id,
                'compare' => '=',
            )
        );
         
    }
 
    return $r;
}
add_filter( 'bbp_after_has_search_results_parse_args' , 'my_bbp_filter_search_results' );
function rgs_loginpage_stylesheet() {
    wp_enqueue_style( 'rgs-login-custom-login', get_template_directory_uri() . '/style-login.css' );
    wp_enqueue_script( 'rgs-login-custom-login', get_template_directory_uri() . '/style-login.js' );
}
add_action( 'login_enqueue_scripts', 'rgs_loginpage_stylesheet' );
// DISABLE default WordPress change password notifications


if ($pagenow=='wp-login.php') { 
  add_filter( 'gettext', 'user_email_login_text', 20, 3 );
  function user_email_login_text( $translated_text, $text, $domain ) {
    if ($translated_text == 'Username or Email') {
    $translated_text = 'Display Name';
    }

    return $translated_text;
  }
}

add_filter( 'login_errors', function( $error ) {
    global $errors;
    $err_codes = $errors->get_error_codes();

    // Invalid username.
    // Default: '<strong>ERROR</strong>: Invalid username. <a href="%s">Lost your password</a>?'
    if ( in_array( 'invalid_username', $err_codes ) ) {
        $error = '<strong>ERROR</strong>: Incorrect Display Name.';
    }

    // Incorrect password.
    // Default: '<strong>ERROR</strong>: The password you entered for the username <strong>%1$s</strong> is incorrect. <a href="%2$s">Lost your password</a>?'
    if ( in_array( 'incorrect_password', $err_codes ) ) {
        $error = '<strong>ERROR</strong>: The password you entered is incorrect.';
    }

    return $error;
} );

function my_login_logo_url() {
    return home_url();
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function replace_bbpress_replies_username_filter($author_name,$reply_id ){
$author_id = bbp_get_reply_author_id($reply_id);
$author_object = get_userdata( $author_id );
$author_name  = $author_object->user_login;
return $author_name;
}
add_filter( 'bbp_get_reply_author_display_name','replace_bbpress_replies_username_filter',10, 2);