<?php

/**
 * Single Topic Content Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>
<div class="row">
<div class="col-sm-12 marginbottom">
<?php include(get_template_directory().'/inc/forumnavigation.php') ?>
</div>

</div>

<div class="borderclass row">
<div class="col-sm-3">

	<div class="center-avatar col-sm-12"><?php echo bbp_get_topic_author_link( array( 'type' => 'avatar', 'size' => 120) ); ?></div>
			
</div>
<!-- user avatar column ends -->

<div class="col-sm-9 rgsthreadpageuserinfo">
<div class="row marginbottom">
<h1 class="rgsgreentitle singlethreadpage col-sm-12 paddingzero">
		<?php bbp_topic_title();?>
	</h1>
	<div class="cols-m-12">	
		<?php bbp_breadcrumb(); ?>
	</div>
		<div class="col-sm-12 statusupdatemarg">
<div class="row">		
<span class="color898989">Posted by</span> 

<span class="rgsusernicename"><a href="<?php echo bbp_topic_author_url() ?>"><?php $user = get_user_by( 'id',bbp_get_topic_author_id() ); echo $user->user_login ; ?></a></span>
<span class=" color898989">Updated <?php bbp_topic_freshness_link( ); ?> by </span>
	<span class=" rgsusernicename">
		<?php bbp_author_link( array( 'post_id' => get_post_meta( get_the_ID(), '_bbp_last_active_id', true ), 'type' => 'name', ) ); ?></span>
</div>
	</div>

	<div class="col-sm-3 col-lg-3 paddingzero">

	<ul class=" rgsfollowul threadpagefollow">
<li class="color898989">Follow:</li>
<li class="rgshearticon"><a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
<span class="glyphicon glyphicon-heart"></span><span class="caret"></span> </a>
  <ul class="dropdown-menu">
   <li><?php bbp_topic_subscription_link(); ?></li><li><?php bbp_topic_favorite_link(); ?></i></li><li><a href="<?php echo get_edit_user_link(); ?>#settings">Notification Preference</a></li>
    </ul>
  </li>
 
</ul>
	


</div>
<!-- follow ul ends -->


<div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 socialdiv marginbottom rgsgorumsocialdiv">

       <ul >
<span class="color898989">Share This Article:</span>
        <li class="emaillink" ><a href=""><i class="fa fa-envelope"></i></a>

</li>
<li class="twitter">
    <a  href="http://twitter.com/home?status=Reading: <?php the_permalink(); ?>" title="Share this post on Twitter!" target="_blank"><i class="fa fa-twitter "></i></a>    
</li>
<li class="facebook">
 <a  href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="Share this post on Facebook!" onclick="window.open(this.href); return false;"><i class="fa fa-facebook"></i></a>
</li>
 </ul>

 </div>
 <div class="col-sm-6 rgsshareviaemail" >
<?php if (is_user_logged_in()){
	?>
	
  <?php get_template_part('/sharethis' ); ?>
 
<?php }else {
echo 'login damn it';
}?>
</div>



</div>

</div>
<!-- Thread heading row -->
</div> 


<!-- thread info row ends -->

    

		<?php if ( bbp_has_replies() ) : ?>

			
        <?php bbp_get_template_part( 'loop',       'replies' ); ?>
     
			
		<?php endif; ?>

	

	<?php do_action( 'bbp_template_after_single_topic' ); ?>

</div>
