<?php

/**
 * Search Content Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="row marginbottom">




<div class=" col-sm-12 rgsfooter borderclass ">    

  <div class="col-sm-6"><div class="forumMainPageh2">Threads Found</div></div>
  

<div class="col-sm-3">
<div class="forumMainPageh2 bdmfontfamily  text-center">Activity</div>
</div>

<div class="col-sm-2">
  <div class="forumMainPageh2 bdmfontfamily text-center">Last Post</div>
</div>

</div>

	<?php if ( bbp_has_search_results() ) : ?>

		

		 <?php bbp_get_template_part( 'loop',       'search' ); ?>

		

	<?php elseif ( bbp_get_search_terms() ) : ?>

		 <?php bbp_get_template_part( 'feedback',   'no-search' ); ?>

	<?php else : ?>

		<?php bbp_get_template_part( 'form', 'search' ); ?>

	<?php endif; ?>

	

</div>

