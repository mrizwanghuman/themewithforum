<?php

/**
 * Archive Forum Content Part
 *
 * @package bbPress
 * @subpackage reallygoodstufftheme
 */

?>

<div class="row forumMainPage ">
	<div class="col-xs-12 col-sm-12 welcomeforumClass">
<h1>Welcome to the NEW Teacher Forum</h1>

	</div>
</div>
<div class="row">
<div class="col-sm-12 marginbottom">
<?php include(get_template_directory().'/inc/forumnavigation.php') ?>
</div>

</div>
<div class=" marginbottom">
<?php 
// the query
$args = array(
'post_type' => bbp_get_forum_post_type(),
'posts_per_page' => 1,

	);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<div class=" row rgsfooter borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title($forum_id = 12668); ?></h2></div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<?php wp_reset_postdata(); ?>

<?php endif; ?>

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  ">Activity</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily">Last Post</h2>
</div>

</div>

<div class="row forumrowborder borderclass">
<?php	
$argstopic = array(  
	'order' => 'DESC', 
	'post_parent' => 12668, 
	'post_type' => bbp_get_topic_post_type(),

	'posts_per_page' => 3 );

$anntopicthe_query = new WP_Query( $argstopic ); ?>

<?php if ( $anntopicthe_query->have_posts() ) : ?>



<?php while ( $anntopicthe_query->have_posts() ) : $anntopicthe_query->the_post(); 
$topic_id    = bbp_get_topic_id( $anntopicthe_query->post->ID );
$author_link = '';
?>	
<ul class="mainpageforumlist col-sm-12 ">
	
	<li class="col-sm-7">
		<div class="col-sm-12 rgsgreentitle">
			<a  href="<?php bbp_topic_permalink( $topic_id ); ?>"><?php bbp_topic_title( $topic_id ); ?></a>
	
		</div>
		<div class="col-sm-12 ">
<span class="color898989">Started by:</span> <span class="rgsusernicename "><?php bbp_author_link( array( 'post_id' => get_the_ID(), 'type' => 'name', 'size'=>32 ) ); ?></span>
		</div>
	</li><li class="col-sm-2 e5ffc6background text-center color898989">
	<div class="col-sm-12">

Replies: <?php bbp_topic_reply_count($topic_id) ?>
	</div>
	<div class="col-sm-12 wpviews">Views: <?php echo wpb_get_post_views(get_the_ID()); ?></div>

</li><li class=" col-sm-3">
	<?php do_action( 'bbp_theme_before_reply_author_details' ); ?>

	<span class="col-sm-12 rgsusernicename">
		<?php bbp_author_link( array( 'post_id' => get_post_meta( get_the_ID(), '_bbp_last_active_id', true ), 'type' => 'name', ) ); ?></span>
		

		<div class="col-sm-12 color898989 removeachortag"><?php bbp_forum_freshness_link($topic_id ); ?></div>

		

		
	</li>


</ul>

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>
</div>		
</div>

<div class=" marginbottom">
<?php 
// the query
$args = array(
'post_type' => bbp_get_forum_post_type(),
'posts_per_page' => 1,

	);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<div class=" row rgsfooter borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title($forum_id = 12686); ?></h2></div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<?php wp_reset_postdata(); ?>

<?php endif; ?>

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  ">Threads</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily">Last Post</h2>
</div>

</div>

<div class="row forumrowborder borderclass">
<?php	
$argsforum = array(  
	 
	'post_parent' => 12686, 
	'post_type' => 'forum',

	);

$genforumthe_query = new WP_Query( $argsforum ); ?>

<?php if ( $genforumthe_query->have_posts() ) : ?>


<?php while ( $genforumthe_query->have_posts() ) : $genforumthe_query->the_post(); 
$topic_id2    = bbp_get_forum_id( $genforumthe_query->post->ID );
?>	
<ul class=" k8forumhomepage col-sm-12 ">
	
	<li class="col-sm-7  forumhomepagepaddingtop">
		<div class="col-sm-12 rgsforumtitle ">
			<a  href="<?php bbp_forum_permalink(  ); ?>"><?php bbp_forum_title(  ); ?></a>
	
		</div>
		
	</li><li class="col-sm-2 ffe9bebackground text-center  forumhomepagepaddingtop color898989">
	<div class="col-sm-12">
<?php bbp_forum_topic_count($topic_id2); ?>

	</div>
	

</li><li class=" col-sm-3">
	<?php do_action( 'bbp_theme_before_reply_author_details' ); ?>

	<span class="col-sm-12 rgsusernicename">
		<?php bbp_author_link( array( 'post_id' => get_post_meta( get_the_ID(), '_bbp_last_active_id', true ), 'type' => 'name', ) ); ?></span>
		

		<div class="col-sm-12 color898989 removeachortag"><?php bbp_forum_freshness_link( $topic_id2); ?></div>
	
	</li>

</ul>

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>
</div>		
</div>

<div class=" marginbottom ">
<?php 
// the query
$args = array(
'post_type' => bbp_get_forum_post_type(),
'posts_per_page' => 1,

	);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<div class=" row rgsfooter borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title($forum_id = 12523); ?></h2></div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<?php wp_reset_postdata(); ?>

<?php endif; ?>

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  ">Threads</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily">Last Post</h2>
</div>

</div>

<div class="row forumrowborder borderclass">
<?php	
$argsforum = array(  
	 
	'post_parent' => 12523, 
	'post_type' => 'forum',

	);

$k8forumthe_query = new WP_Query( $argsforum ); ?>

<?php if ( $k8forumthe_query->have_posts() ) : ?>



<?php while ( $k8forumthe_query->have_posts() ) : $k8forumthe_query->the_post(); 
$topic_id3    = bbp_get_forum_id( $k8forumthe_query->post->ID );
?>	
<ul class=" k8forumhomepage col-sm-12 ">
	
	<li class="col-sm-7 forumhomepagepaddingtop">
		<div class="col-sm-12 rgsforumtitle ">
			<a  href="<?php bbp_forum_permalink(  ); ?>"><?php bbp_forum_title(  ); ?></a>
	
		</div>
		
	</li><li class="col-sm-2 ffe9bebackground text-center forumhomepagepaddingtop color898989">
	<div class="col-sm-12">
<?php bbp_forum_topic_count($topic_id3); ?>

	</div>
	

</li><li class=" col-sm-3">
	<?php do_action( 'bbp_theme_before_reply_author_details' ); ?>

	<span class="col-sm-12 rgsusernicename">
		<?php bbp_author_link( array( 'post_id' => get_post_meta( get_the_ID(), '_bbp_last_active_id', true ), 'type' => 'name', ) ); ?></span>
		

		<div class="col-sm-12 color898989 removeachortag"><?php bbp_forum_freshness_link( $topic_id3); ?></div>

				
	</li>


</ul>

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>
</div>		
</div>

<div class=" marginbottom">
<?php 
// the query
$args = array(
'post_type' => bbp_get_forum_post_type(),
'posts_per_page' => 1,

	);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<div class=" row rgsfooter borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title($forum_id = 12524); ?></h2></div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<?php wp_reset_postdata(); ?>

<?php endif; ?>

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  ">Threads</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily">Last Post</h2>
</div>

</div>

<div class="row forumrowborder borderclass rgsforummarginbottom">
<?php	
$argsforum = array(  
	 
	'post_parent' => 12524, 
	'post_type' => 'forum',

	);

$ecforumthe_query = new WP_Query( $argsforum ); ?>

<?php if ( $ecforumthe_query->have_posts() ) : ?>



<?php while ( $ecforumthe_query->have_posts() ) : $ecforumthe_query->the_post(); 
$topic_id4    = bbp_get_forum_id( $ecforumthe_query->post->ID );
?>	
<ul class=" k8forumhomepage col-sm-12 ">
	
	<li class="col-sm-7 forumhomepagepaddingtop">
		<div class="col-sm-12 rgsforumtitle ">
			<a  href="<?php bbp_forum_permalink(  ); ?>"><?php bbp_forum_title(  ); ?></a>
	
		</div>
		
	</li><li class="col-sm-2 ffe9bebackground text-center forumhomepagepaddingtop color898989">
	<div class="col-sm-12">
<?php bbp_forum_topic_count($topic_id4 ); ?>

	</div>
	

</li><li class=" col-sm-3">
	<?php do_action( 'bbp_theme_before_reply_author_details' ); ?>

	<span class="col-sm-12 rgsusernicename">
		<?php bbp_author_link( array( 'post_id' => get_post_meta( get_the_ID(), '_bbp_last_active_id', true ), 'type' => 'name', ) ); ?></span>
		

		<div class="col-sm-12 color898989 removeachortag"><?php bbp_forum_freshness_link( $topic_id4 ); ?></div>

		
	</li>


</ul>

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>
</div>		
</div>


		
