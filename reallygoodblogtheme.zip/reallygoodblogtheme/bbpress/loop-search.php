<?php

/**
 * Search Loop
 *
 * @package bbPress
 * @subpackage Theme
*/

?>
<div class="row">
<?php do_action( 'bbp_template_before_search_results_loop' ); ?>


		<?php while ( bbp_search_results() ) : bbp_the_search_result(); ?>

			<div class="col-sm-12">


<ul   class="mainpageforumlist  ">

  <li class="bbp-topic-title col-sm-7">

    
    <?php do_action( 'bbp_theme_before_topic_title' ); ?>

    <div class="col-sm-10 rgsgreentitle paddingzero"><a class="bbp-topic-permalink" href="<?php bbp_topic_permalink(); ?>"><?php bbp_topic_title(); ?></a></div>

    <?php do_action( 'bbp_theme_after_topic_title' ); ?>

    <?php bbp_topic_pagination(); ?>

    <?php do_action( 'bbp_theme_before_topic_meta' ); ?>

    <p class="bbp-topic-meta">

      <?php do_action( 'bbp_theme_before_topic_started_by' ); ?>

      <div class="col-sm-12 ">Started by:
        <span class="rgsusernicename ">
        <?php 

 $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
    $user_data = get_userdata( $reply_author_id );
    $user_email = $user_data->user_email;
    $username =$user_data->user_login;
    echo $username  ?></span></div>

      <?php do_action( 'bbp_theme_after_topic_started_by' ); ?>

    <div><?php bbp_topic_excerpt(); ?></div>

    </p>

    <?php do_action( 'bbp_theme_after_topic_meta' ); ?>

    <?php bbp_topic_row_actions(); ?>

  </li>

  <li class="col-sm-2 e5ffc6background text-center color898989"><div class="col-sm-12">

Replies: <?php bbp_topic_reply_count($topic_id) ?>
  </div>
  <div class="col-sm-12 wpviews">Views: <?php echo wpb_get_post_views(get_the_ID()); ?></div></li>



  <li class=" col-sm-3">

    <?php do_action( 'bbp_theme_before_topic_freshness_link' ); ?>

    

    <?php do_action( 'bbp_theme_after_topic_freshness_link' ); ?>

    <div class="rgsusernicename col-sm-12">

      <?php do_action( 'bbp_theme_before_topic_freshness_author' ); ?>

      <span class="bbp-topic-freshness-author"><?php $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
    $user_data = get_userdata( $reply_author_id );
    $user_email = $user_data->user_email;
    $username =$user_data->user_login;
    echo $username ?></span>

      <?php do_action( 'bbp_theme_after_topic_freshness_author' ); ?>

    </div>
    <div class="col-sm-12 color898989">
    <?php bbp_topic_freshness_link(); ?>
  </div>
  </li>

</ul>

  </div>

		<?php endwhile; ?>


<?php do_action( 'bbp_template_after_search_results_loop' ); ?>
</div>