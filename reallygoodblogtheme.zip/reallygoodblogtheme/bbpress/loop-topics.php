<?php

/**
 * Topics Loop
 *
 * @package bbPress
 * @subpackage Theme
 */

?>

<div class="marginbottom">

<div class=" row rgsfooter borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title() ?></h2></div>
	

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  text-center">Activity</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily text-center">Last Post</h2>
</div>

</div>

<div class="row forumrowborder borderclass">
<?php do_action( 'bbp_template_before_topics_loop' ); ?>

	
		<?php while ( bbp_topics() ) : bbp_the_topic(); ?>

			<?php bbp_get_template_part( 'loop', 'single-topic' ); ?>

		<?php endwhile; ?>

	<!-- #bbp-forum-<?php bbp_forum_id(); ?> -->
<?php do_action( 'bbp_template_after_topics_loop' ); ?>
</div>




</div>





