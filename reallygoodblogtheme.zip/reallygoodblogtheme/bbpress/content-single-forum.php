<?php

/**
 * Single Forum Content Part
 *
 * @package bbPress
 * @subpackage Theme
 */

?>
<?php do_action( 'bbp_template_before_single_forum' ); ?>

	<?php if ( post_password_required() ) : ?>

		<?php bbp_get_template_part( 'form', 'protected' ); ?>

	<?php else : ?>
<div class="row forumMainPage">
	<div class="col-xs-12 col-sm-12 welcomeforumClass">
<h1><?php echo get_the_title($post->post_parent); ?>: <?php bbp_forum_title(); ?></h1>

	</div>
</div>
<div class="row">
<div class="col-sm-12 marginbottom">
<?php include(get_template_directory().'/inc/forumnavigation.php') ?>
</div>

</div>

<div class="row marginbottom">
<div class="bbp-search-form col-sm-5 rgssubsform">

			<?php bbp_get_template_part( 'form', 'search' ); ?>

		</div>
		<div class="col-sm-4"></div>
		<div class="col-sm-3 "><button class="btn btn-default sellallartbtn pull-right" id="postAnewThread">Post A New Thread</button></div>
</div>
<div class="row marginbottom" id="prePostterms">
<div class="col-sm-12 borderclass">
	<div class='color898989 pull-right closethisbtn'>X</div>
	<div class="col-sm-12 titlecreatedirection" >Create a new thread in "<?php bbp_forum_title(); ?>"</div>
<div class="col-sm-12 titlecreatedirectionsec">
	Please read these guidelines before posting:</div>
<div class="col-sm-12">
	<ul class="rgsdiscstyle col-sm-12 marginbottom">
<li>If you have a question, try searching first to make sure your question hasn't been answered already.</li>
<li>
Do not post spam or advertising. It will be removed and your account will be banned.
</li>
<li>
Do not post the same message to more than one category.
</li>
<li>
Please write a clear title for your thread (Clear: "How are you using technology in the Classroom?"; Unclear: "Email!!?!?!")
</li>
<li>
	Do not attack other members. Disagreement about ideas is natural, stimulates intelligent discussion, and is encouraged. But 			   personal attacks and insults will be not be tolerated.
</li>
<li>
Pornographic, racist, or obscene material is not allowed. Moderator discretion applies.
</li>
<li>
Please don't TYPE IN ALL CAPS, use wEiRd pUnCtUaTiOn, or use confusing acronyms or slang.
</li>
	</ul>

<button class="center-block btn sellallartbtn rgspostTopicagree">I Read and Agree to the Guidleines</button>
</div>
</div>
</div>
<div class="row">
	<div class="col-sm-12" id="rgshiddenThreadpost">
<?php bbp_get_template_part( 'form',       'topic'     ); ?>
</div>
</div>

<div class="row marginbottom">
	<div class="col-sm-12">
			
	
			<?php if ( bbp_has_forums() ) : ?>
	
				<?php bbp_get_template_part( 'loop', 'forums' ); ?>
	
			<?php endif; ?>
	
			<?php if ( !bbp_is_forum_category() && bbp_has_topics() ) : ?>
	
				
	
				<?php bbp_get_template_part( 'loop',       'topics'    ); ?>
		
			<?php endif; ?>
	
		<?php endif; ?>
	
		<?php do_action( 'bbp_template_after_single_forum' ); ?>
	</div>
</div>

