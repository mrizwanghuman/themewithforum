<?php
/**
 * Search
 *
 * @package bbPress
 * @subpackage Theme
 */
$forum_id = bbp_get_forum_id();
?>
 
<form role="search" method="get" id="bbp-search-form" action="<?php bbp_search_url(); ?>" class="col-sm-12 paddingzero">
    <div>
    	 <div class="form-group col-sm-10 paddingzero">
       
       <div class="col-sm-12 paddingzero"> <input placeholder="Search <?php the_title(); ?> Threads" tabindex="<?php bbp_tab_index(); ?>" type="text" value="<?php echo esc_attr( bbp_get_search_terms() ); ?>" name="bbp_search" id="bbp_search" class="form-control "/>
               <?php if( $forum_id ): ?></div>
        <input class="button" type="hidden" name="bbp_search_forum_id" value="<?php echo $forum_id; ?>" />
        <?php endif; ?>
         </div>

       <div class="col-sm-2 paddingzero"> <input tabindex="<?php bbp_tab_index(); ?>" class="btn search-submit-forum " type="submit" id="bbp_search_submit" value="&#xf002;" /></div>
    </div>
</form>