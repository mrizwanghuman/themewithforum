<?php

/**
 * Replies Loop
 *
 * @package bbPress
 * @subpackage Theme
 */

?>


<?php
	

$argstopic = array(  
	 
	'post_parent'    => bbp_is_forum_archive() ? 0 : bbp_get_forum_id() ,

	'post_type' => bbp_get_topic_post_type(),

	'posts_per_page' => 1 );

$anntopicthe_query = new WP_Query( $argstopic ); ?>

<?php if ( $anntopicthe_query->have_posts() ) : ?>


<?php while ( $anntopicthe_query->have_posts() ) : $anntopicthe_query->the_post(); 
$topic_id    = bbp_get_topic_id( $anntopicthe_query->post->ID );

$author_link = '';
?>	
<div class="row  marginbottom">
	<ul class="mainpageforumlist bgffdf99">
<li class="col-sm-3 talkbubble">
		<div class="rgsmsalleravatstyle"><?php echo bbp_get_topic_author_link( array( 'type' => 'avatar') ); ?></div>	
	<span class="col-sm-12 rgsusernicename"><a href="<?php echo bbp_topic_author_url() ?>"><?php $user = get_user_by( 'id',bbp_get_topic_author_id() ); echo $user->user_login ; ?></a></span>

		<div class="color898989 col-sm-12">
		<div><?php  $user_role = bp_profile_field_data( array('field' => 258, 'user_id' => bbp_get_topic_author_id() ) );
		    echo $user_role; ?></div>
<div> <?php $user_grade = bp_profile_field_data( array('field' => 274, 'user_id' => bbp_get_topic_author_id() ) );
 ?></div>
<div>Teaching since: <?php $user_year = bp_profile_field_data( array('field' => 288, 'user_id' => bbp_get_topic_author_id() ) );
 ?></div>
<div>
<?php  $rgsuser_location = bp_profile_field_data( array('field' => 146, 'user_id' => bbp_get_topic_author_id() ) );
     ?>

</div>
</div>
	
		</li>

		<li class="col-sm-7 bgffdf99"> <div class="col-sm-12 color898989 rgsthreaddate"><?php bbp_reply_post_date(); ?></div><div class="col-sm-12"><?php bbp_topic_content(); ?></div></li>

	</ul>						
</div>

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>

	 <div class="row marginbottom"> 
      <button class="btn  sellallartbtn pull-right" id="postAnewReply" >Post a Reply</button> 
    <div  id="rgshiddenReplypost"><?php bbp_get_template_part( 'form', 'reply' ); ?></div>
  </div>

<?php
	

$argstopic = array(  
	 
	'post_parent'    => bbp_is_topic_archive() ? 0 : bbp_get_topic_id() ,

	'post_type' => bbp_get_reply_post_type(),

	'posts_per_page' => 10, 
	'order'   => 'ASC');

$anntopicthe_query = new WP_Query( $argstopic ); ?>

<?php if ( $anntopicthe_query->have_posts() ) : ?>


<?php while ( $anntopicthe_query->have_posts() ) : $anntopicthe_query->the_post(); 
$topic_id    = bbp_get_topic_id( $anntopicthe_query->post->ID );
$count = $anntopicthe_query->post_count;
$author_link = '';
 $user_info = get_userdata($author_link);
      echo 'Username: ' . $user_info->username . "\n";
      
      echo 'User ID: ' . $user_info->ID . "\n";

?>	

<div class="row  marginbottom">
	<ul class="mainpageforumlist ">
<li class="col-sm-3 talkbubble">
	

	<div class="rgsmsalleravatstyle"><?php bbp_author_link( array( 'post_id' => $topic_id, 'type' => 'avatar' ) ); ?></div>
<span class="col-sm-12 rgsusernicename"><?php $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
		$user_data = get_userdata( $reply_author_id );
		$user_email = $user_data->user_email;
		$username =$user_data->user_login;
		echo $username ?></span>
	<div class="color898989 col-sm-12">
		<div><?php  $user_role = bp_profile_field_data( array('field' => 258, 'user_id' => bbp_get_reply_author_id() ) );
		    echo $user_role; ?></div>
<div> <?php $user_grade = bp_profile_field_data( array('field' => 274, 'user_id' => bbp_get_reply_author_id() ) );
 ?></div>
<div>Teaching since: <?php $user_year = bp_profile_field_data( array('field' => 288, 'user_id' => bbp_get_reply_author_id() ) );
 ?></div>
<div>
<?php  $rgsuser_location = bp_profile_field_data( array('field' => 146, 'user_id' => bbp_get_reply_author_id() ) );
     ?>

</div>
</div>

		</li>

		<li class="col-sm-9 "> 
			<div class="col-sm-12"><div class="col-sm-12 color898989 rgsthreaddate paddingzero"><?php bbp_reply_post_date(); ?></div><?php the_content(); ?></div>
<div class="col-sm-12 marginbottom">
	<?php for ($index=0; $index <= $count; $index++) { 
		# code...
	} ?>
 <button class="btn  pull-right" id="rgshiddenReplypost<?php echo $index ?>">Post a Reply</button> 
    <div class="col-sm-12" id="rgshiddenReplyposttwo"><?php bbp_get_template_part( 'form', 'reply' ); ?></div>
</div>
		</li>

	</ul>						
</div>
								 
     
 

<?php endwhile; ?>

<?php wp_reset_postdata(); ?>

<?php endif; ?>


