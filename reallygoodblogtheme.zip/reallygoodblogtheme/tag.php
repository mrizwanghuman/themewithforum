<?php get_header(); ?>

<section class="row rgssearchpagebordercalss marginbottom rgsmargintop">
    <div class="col-xs-12 col-sm-12 marginbottom catepagestarone"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_TopStar.png"></div>

<p>Tag: <?php single_tag_title(); ?></p>


<?php 

$posts = new WP_Query("post_type=post&order=DESC");
if ( $posts->have_posts() ) :
    while ( $posts->have_posts() ) : $posts->the_post();?>


 
     <div class="col-xs-12 col-sm-12 lastqueryclass mobilemarginbottom">

<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">

<a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('homepagerecentpost');
} 
?></a>
</div>

<div class="rgsposttitle slidertextview circleimage1"><a  href="<?php the_permalink(); ?>" ><?php the_title();?></a></div>
 <div class=" catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php the_time('F j, Y'); ?></div>

<div>
<?php the_excerpt();?>

</div>

</div>
<?php endwhile;
    wp_reset_postdata();
endif;
?>

    <div class="col-xs-12 col-sm-12 marginbottom catepagestaronebottom"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_BottomStar-1.png">
</div>


</div>


</section>

<?php get_footer(); ?>