<?php get_header(); ?>

<div class="row" <?php post_class(); ?>>
        <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); 
$thePostID = $post->ID;
        ?>
<div class="row ">
<div class="col-xs-12 col-sm-12 text-center rgssinglepage catedatfont catedatfontsingelcat">
<?php $category = get_the_category();
$catParID = $category[0]->category_parent;
$catParent = get_cat_name ($catParID);
?>
<?php echo $catParent ?> | <?php the_time('F j, Y'); ?>
</div>

</div>


<div class="row">
      <div class="col-xs-12 col-sm-12  slidertextview singlepagetitle">

 <h1 class=" text-center"><?php the_title();?></h1>
 
  
</div>

</div>



<div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>


  <div class="row marginbottom">
<div class="col-xs-12 col-sm-12 mobilecentertext">
<div class="rgspull-left catedatfont catedatfontsingelcat"> Written By: <?php the_author(); ?> </div>
<div class="rgspull-right catedatfont catedatfontsingelcat">Category: <?php the_category( ' ' ); ?></div>
</div>

</div>

<div class="row marginbottom">
<div class="col-sm-1">

<div class="rgssinglepagesocial hidden-xs hidden-sm">
       <ul >
        <li id="clicktoscrol">
        <?php
   if (get_comments_number()==0) { ?>
 <a class="rgszerocomments"><i class="fa fa-comments fa-lg"></i></a>

<?php } else {  ?>
  <a class="commentscount"><i class="fa fa-comments "></i><div class="commentscountnumber"><?php comments_number( " ", " 1", " %" ); ?></div></a>
<?php } ?>     
  </li>
        <li>
<a class="pinterest" target="_blank" href="https://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>"><i class="fa fa-pinterest-p fa-lg"></i></a>
</li>
<li>
    <a class="twitter" href="http://twitter.com/home?status=Reading: <?php the_permalink(); ?>" title="Share this post on Twitter!" target="_blank"><i class="fa fa-twitter fa-lg"></i></a>    
</li>
<li>
 <a class="facebook" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="Share this post on Facebook!" onclick="window.open(this.href); return false;"><i class="fa fa-facebook fa-lg"></i></a>
</li>


       </ul>
</div>
</div>
<div class=" col-xs-12 col-sm-12 col-md-8 col-lg-8">
  
<div class="rgsarticles col-sm-12 col-xs-12 getwaythumnailsize"><?php the_content( ); ?></div>

<div class="row rgstags marginbottom ">
  <div class="col-xs-12 col-sm-12"> <?php the_tags( 'Tags: ', ', '  ); ?>
</div>
</div>

<div class="row no-pad marginbottom">
<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 socialdiv marginbottom">

       <ul >
<span class="catedatfont catedatfontsingelcat">Share:</span>
        <li class="pinterest" >
<a target="_blank" href="https://pinterest.com/pin/share?url=<?php the_permalink(); ?>"><i class="fa fa-pinterest-p "></i></a>
</li>
<li class="twitter">
    <a  href="http://twitter.com/home?status=Reading: <?php the_permalink(); ?>" title="Share this post on Twitter!" target="_blank"><i class="fa fa-twitter "></i></a>    
</li>
<li class="facebook">
 <a  href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="Share this post on Facebook!" onclick="window.open(this.href); return false;"><i class="fa fa-facebook"></i></a>
</li>
 </ul>
 </div>

<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 commentsul ">
 <div class="favritelink">
<span class="catedatfont catedatfontsingelcat" id="texttosave">Save:</span>
<span ><?php wpfp_link() ?></span>
 <!-- <span class="favritelinkbck"><span class="glyphicon glyphicon-heart" id="rgssaveit"></span></span> -->
 <!--
<span class="favritelinkbckred"><span class="glyphicon glyphicon-heart" id="rgssaveit"></span></span> -->
<span class="showsaved">Saved</span>
<span class="showunsaved">Unsaved</span>
</div>     

</div>
</div>

<!-- <div class="col-sm-12 wpviews"><?php // echo wpb_get_post_views(get_the_ID()); ?></div> -->


<div class="row marginbottom ">

<div class="col-xs-12 col-sm-12 col-md-12 rgscommentscountheading paddingzero">
  <div class="rgsfooter  col-sm-12 paddingzero">
<div class="commentscount "> <a ><i class="fa fa-comments "></i>
 </a> 
  <span class="rgsgccommentscount"><?php comments_number( 'Make A Comment ', '1 Comment', '% Comments' ); ?>.</span>
 
</div>


</div>

<div class="col-sm-12">
  <?php 
if ( is_user_logged_in() ) {
?>
<div class="col-sm-12 bethefirstcomment">

 <?php
if (get_comments_number()==0) {
  echo "Be the first to make a comment. ";
} 
?>
</div>
<ul >


  <li class=" col-sm-12"> <?php 

    $comments_args = array(
        // change the title of send button 
        'label_submit'=>'Comment',
         'class_form'      => 'col-sm-12 paddingzero',
        'class_submit' => 'btn sellallartbtn pull-right rgspadding2per',
        // change the title of the reply section
        'title_reply'=>' ',
          'must_log_in' => '<p class="commentsSectionJoin">' .
    sprintf(
      __( 'You must be <a href="%s">logged in</a> to post a comment.' ),
      wp_login_url( apply_filters( 'the_permalink', get_permalink() ) )
    ) . '</p>',
        'logged_in_as' => ' ',
        // remove "Text or HTML to be displayed after the set of comment fields"
       'comment_field' => '<textarea id="comment" name="comment" class="col-sm-12 paddingzero form-control rgscommentform " rows="5" aria-required="true"></textarea>',
);

comment_form($comments_args); ?></li>

</ul>
<?php }else { ?>
  <div class="commentsnotsignin"> 
    <span class="col-sm-12 bethefirstcomment">

 <?php
if (get_comments_number()==0) {
  ?>
  Be the first to make a comment. <a class="login_button" id="show_login" href="">Join or Log In</a>
  <?php } else { ?>

 <a class="login_button" id="show_login" href="">Join or Log In</a> to make a comment
 <?php } ?>
</span>

  
 

 </div>


<?php }
  ?>

 
</div>

  </div>


  </div>
<div class="row marginbottom">
<div class="col-sm-12"><?php comments_template(); ?> 
 
</div>
</div>



</div>



<div class="col-xs-12 col-sm-12 col-md-3 col-lg-3 singepagesidebar borderclass  ">

  <div class="singlepagesidebarheading"><div class="catedatfont catedatfontsingelcat">More From:</div> <div class="recentpostheading "><?php the_category( ' ' ); ?></div></div>

  <div class="panel-body hidden-xs hidden-sm">
   
<?php
if ( is_single() ) {
  $cats = wp_get_post_categories($post->ID);
    if ($cats) {
    $first_cat = $cats[0];
    $args=array(
      'cat' => $first_cat, //cat__not_in wouldn't work
      'post__not_in' => array($post->ID),
      'showposts'=>5,
      
    );
    $my_query = new WP_Query($args);
    if( $my_query->have_posts() ) {
     
      while ($my_query->have_posts()) : $my_query->the_post(); ?>
<div class="marginbottom">
<div class="thumbnailslider"><a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><?php the_post_thumbnail('homepagesize' ); ?> </a></div>
    <div class="headingtextcolor">  <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><h3><?php the_title(); ?></h3></a></div>
    <div class="catedatfont catedatfontsingelcat"><?php the_time('F j, Y' ); ?></div>
    </div>
       <?php
      endwhile;
    } //if ($my_query)
  } //if ($cats)
  wp_reset_query();  // Restore global post data stomped by the_post().
} //if (is_single())
?>
  

  </div>

  <!-- Mobile slider for sidebar -->
<div class="row marginbottom multiimageslider ajax-posts visible-sm visible-xs">
 
<div id="sidbarslidersinglepage" class="carousel slide col-sm-12 col-xs-12" data-ride="carousel">
  <div class="col-sm-2 col-xs-2 rightimagecontrol"> </div>
  <div class="carousel-inner">


    <div class="item active">   
<ul>
  <?php 
$cats = wp_get_post_categories($post->ID);
   
    $first_cat = $cats[0];
    $args=array(
      'cat' => $first_cat, //cat__not_in wouldn't work
      'post__not_in' => array($post->ID),
      'showposts'=>2,
      
    );
    $query_mobile_slider = new WP_Query($args);
   while ( $query_mobile_slider->have_posts() ) : 
   $query_mobile_slider->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">

 <div class="headingtextcolor">  <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><h3><?php the_title(); ?></h3></a></div>
    <div class="catedatfont catedatfontsingelcat"><?php the_time('F j, Y' ); ?></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
<div class="item ">   
<ul>
  <?php 
 $cats = wp_get_post_categories($post->ID);
   
    $first_cat = $cats[0];
    $argsmobile2=array(
      'cat' => $first_cat, //cat__not_in wouldn't work
      'post__not_in' => $do_not_duplicate,
      'offset'        => 2,
      'showposts'=>2,
      
    );
    $query_mobile_slider2 = new WP_Query($argsmobile2);
   while ( $query_mobile_slider2->have_posts() ) : 
   $query_mobile_slider2->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="headingtextcolor">  <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><h3><?php the_title(); ?></h3></a></div>
    <div class="catedatfont catedatfontsingelcat"><?php the_time('F j, Y' ); ?></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>

  <div class="item ">   
<ul>
  <?php 
$cats = wp_get_post_categories($post->ID);
   
    $first_cat = $cats[0];
    $argsmobile3=array(
      'cat' => $first_cat, //cat__not_in wouldn't work
      'post__not_in' => $do_not_duplicate,
      'offset'        => 4,
      'showposts'=>2,
      
    );
    $query_mobile_slider3 = new WP_Query($argsmobile3);
   while ( $query_mobile_slider3->have_posts() ) : 
   $query_mobile_slider3->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
  <div class="headingtextcolor">  <a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title_attribute(); ?>"><h3><?php the_title(); ?></h3></a></div>
    <div class="catedatfont catedatfontsingelcat"><?php the_time('F j, Y' ); ?></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
  
  
  </div>

  <!-- Controls -->
 <div class="hiddencontroll">
  <a class="left carousel-control" href="#sidbarslidersinglepage" role="button" data-slide="prev">
    <span class="rgsleftarrow"  aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rightarrow.png"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#sidbarslidersinglepage" role="button" data-slide="next">
    <span class="rgsrightarrow" aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/leftarrow.png"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

</div>



</div>



</div>


<?php endwhile; else : ?>
        
<?php endif; ?>
</div>

 <div class="row marginbottom">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>

  <div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>
<!-- dekstop slider for related posts -->
<div class="row marginbottom multiimageslider ajax-posts hidden-sm hidden-xs">
  <h3 class="col-xs-12 col-sm-12 trending catedatfontsingelcat">
    Related Posts

  </h3>
<div id="myCarouselSingle" class="carousel slide col-sm-12 col-xs-12" data-ride="carousel">
  <div class="col-sm-2 col-xs-2 rightimagecontrol"> </div>
  <div class="carousel-inner">


    <div class="item active">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args1=array(
'tag__in' => $tag_ids,
'post__not_in' => array($thePostID, $do_not_duplicate),
'offset'        => 4,
'showposts'=>4,  // Number of related posts that will be shown.

);
   $the_query1 = new WP_Query($args1); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
<div class="item ">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args2=array(
'tag__in' => $tag_ids,
'offset'        =>8,
'post__not_in' => array( $do_not_duplicate),
'showposts'=>4,  // Number of related posts that will be shown.

);
   $the_query2 = new WP_Query($args2); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>

  <div class="item ">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args3=array(
'tag__in' => $tag_ids,
'offset'        => 12,
'post__not_in' => array($thePostID),
'showposts'=>4,  // Number of related posts that will be shown.

);
   $the_query1 = new WP_Query($args3); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-3 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><div class="col-xs-12 text-center"><a href="<?php the_permalink(); ?>" class="catepageslidertitle"><?php the_title();?></a></div></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
  
  
  </div>

  <!-- Controls -->
 <div class="hiddencontroll">
  <a class="left carousel-control" href="#myCarouselSingle" role="button" data-slide="prev">
    <span class="rgsleftarrow"  aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rightarrow.png"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarouselSingle" role="button" data-slide="next">
    <span class="rgsrightarrow" aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/leftarrow.png"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

</div>



<!-- mobile slider for related posts -->

<div class="row marginbottom multiimageslider ajax-posts visible-sm visible-xs">
  <h3 class="col-xs-12 col-sm-12 trending catedatfontsingelcat">
    Related Posts

  </h3>
<div id="myCarouselSinglemobile" class="carousel slide col-sm-12 col-xs-12" data-ride="carousel">
  <div class="col-sm-2 col-xs-2 rightimagecontrol"> </div>
  <div class="carousel-inner">


    <div class="item active">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args1=array(
'tag__in' => $tag_ids,
'post__not_in' => array($thePostID, $do_not_duplicate),
'offset'        => 2,
'showposts'=>2,  // Number of related posts that will be shown.

);
   $the_query1 = new WP_Query($args1); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><h4 class="col-xs-12 catedatfontsingelcat"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
<div class="item ">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args2=array(
'tag__in' => $tag_ids,
'offset'        =>4,
'post__not_in' => array( $do_not_duplicate),
'showposts'=>2,  // Number of related posts that will be shown.

);
   $the_query2 = new WP_Query($args2); 
   while ( $the_query2->have_posts() ) : 
   $the_query2->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><h4 class="col-xs-12 catedatfontsingelcat"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>

  <div class="item ">   
<ul>
  <?php 
$tags = wp_get_post_tags($thePostID);

$tag_ids = array();
foreach($tags as $individual_tag) $tag_ids[] = $individual_tag->term_id;
 
$args3=array(
'tag__in' => $tag_ids,
'offset'        => 6,
'post__not_in' => array($thePostID),
'showposts'=>2,  // Number of related posts that will be shown.

);
   $the_query1 = new WP_Query($args3); 
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>

<li class="col-xs-6 col-sm-6 ">
<div class="col-sm-12 thumbnailslider2"><?php the_post_thumbnail('circleimage');?></div>
<div class="col-sm-12">
 <div class="col-xs-12 recentpostheading text-center">
  <?php
the_category(' ' );
 ?> <span class="glyphicon glyphicon-triangle-right"></span>
 
 </div>
<div class="ajax-posts"><h4 class="col-xs-12 catedatfontsingelcat"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h4></div>
</div>
</li>
   



<?php 
   endwhile; 
   wp_reset_postdata();
  ?>
</ul>

</div>
  
  
  </div>

  <!-- Controls -->
 <div class="hiddencontroll">
  <a class="left carousel-control" href="#myCarouselSinglemobile" role="button" data-slide="prev">
    <span class="rgsleftarrow"  aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rightarrow.png"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="right carousel-control" href="#myCarouselSinglemobile" role="button" data-slide="next">
    <span class="rgsrightarrow" aria-hidden="true"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/leftarrow.png"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
</div>

</div>

<div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>

 <div class="row marginbottom">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
 <?php
endwhile;
?>
</div>
  </div>

<?php get_footer(); ?>