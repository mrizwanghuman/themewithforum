


<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 * 
 *
 * @package reallygoodstufftheme
 */

?>
</div>
</div>

<div >
  <div class="row rgsfooter">
<div class="row marginbottom no-pad rowpadding">
<div class=" hidden-xs col-xs-2 col-sm-2 col-md-2 col-lg-2 topnavmenu ">
  <div class="footerstarimage1"></div></div>
<div class="col-sm-2 col-md-2 col-lg-2 hidden-xs hidden-sm footersocialdiv">

<ul>

<li class="pinterest">
<a href="https://www.pinterest.com/reallygoodstuff" target="_blank"><i class="fa fa-pinterest-p "></i></a>
</li>
<li class="facebook">
<a href="https://www.facebook.com/ReallyGoodStuff/" target="_blank"><i class="fa fa-facebook"></i></a>
</li>
<li class="instagram">
<a href="https://www.instagram.com/reallygoodstuff/" target="_blank"><i class="fa fa-instagram "></i></a>
</li>
<li class="twitter">
<a href="https://twitter.com/reallygoodstuff" target="_blank"><i class="fa fa-twitter "></i></a>
</li>

</ul>

</div>
<!-- footer social nav -->
<div class=" rgsfooternav col-xs-12 col-sm-8 col-md-5 col-lg-5">
<?php /* Primary navigation */
wp_nav_menu( array(
  'menu' => 'Footer Menu',
  'depth' => 0,
  'container' => false,
  'menu_class' => ' topnavmenu'
 )
);
?>
</div>
<!-- footer navigation -->
<div class="col-sm-1 col-md-1 col-lg-1 hidden-xs hidden-sm footerstarimage topnavmenu"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/Kids_Bottom.png"></div>
<div class="hidden-xs col-xs-2 col-sm-2 col-md-2 col-lg-2 topnavmenu"><div class="footerstarimage1"></div></div>
</div>
<!-- starimage with kids -->
<div class="row">
  <div class="addfootercontainer visible-xs "></div>
<div class="row visible-xs visible-sm marginbottom">
<div class="col-xs-12 footersocialdiv marginbottom">
<ul>

<li class="pinterest">
<a href="https://www.pinterest.com/reallygoodstuff" target="_blank"><i class="fa fa-pinterest-p "></i></a>
</li>
<li class="facebook">
<a href="https://www.facebook.com/ReallyGoodStuff/" target="_blank"><i class="fa fa-facebook"></i></a>
</li>
<li class="instagram">
<a href="https://www.instagram.com/reallygoodstuff/" target="_blank"><i class="fa fa-instagram "></i></a>
</li>
<li class="twitter">
<a href="https://twitter.com/reallygoodstuff" target="_blank"><i class="fa fa-twitter "></i></a>
</li>

</ul>

</div>
<div class="col-xs-6 col-xs-offset-3">
<button class="shopbutton btn btn-lg"><a href="http://www.reallygoodstuff.com" target="_blank">Shop</a></button>
</div>

</div>
<div class="row footermarginbottom ">
<div class="col-sm-3 col-md-4 col-lg-4 col-xs-1 "></div>
 <ul class="col-xs-10 col-sm-6 logorow"><li class="footerlogoimg"><img src="<?php echo get_stylesheet_directory_uri(); ?>/images/LOGONEW.png"/></li><li class="footerlogotext">Weekly Recap</li></ul>

<div class="col-sm-3 col-md-3 col-lg-3 col-xs-1 hidden-sm"></div>
</div>
<!-- logo row -->
<div class="row ">
<div class="col-xs-2 col-sm-3 col-md-4 col-lg-4  "></div>
<div class="col-xs-8 col-sm-6 col-md-5 col-lg-5">




<form id="form_blog_digest_footer" name="blog_form_footer" method="post"  accept-charset="UTF-8" class="form-inline rgssubsform" onsubmit="return validate_blog_digest_email();" novalidate>
<input id="form_blog_digest_label" type="hidden" name="crvs" />


 <div class="row">
   <div class="form-group col-lg-7 col-md-7 col-sm-7 col-xs-12">
     



     <input type="text" id="email_address_blog_digest_footer" name="email"  class="modal-registration" placeholder="Email Address" />
      

   

       <br>
      <div style="" class="text-center"><span id="email_address_validation_footer" style="color: red;" ></span></div>

   </div>
  
   <input style="display: none;" type="checkbox" name="CheckBox.Marketing Emails.Promotional emails" /><input type="hidden" name="CheckBox.Marketing Emails.Promotional emails" value="off"/>
   <input style="display: none;" type="checkbox" name="CheckBox.Marketing Emails.Really Good Teachers Weekly Recap" checked /><input type="hidden" name="CheckBox.Marketing Emails.Really Good Teachers Weekly Recap" value="off"/>
   <button type="submit"  class="btn btn-default col-lg-3 col-lg-offset-0 col-md-3 col-md-offset-0 col-sm-4 col-xs-8 col-xs-offset-2 col-sm-offset-0">Sign Up</button>
 

   </div>
</form>

</div>
<div class="col-xs-2 col-sm-3 col-md-3 col-lg-3 "></div>
</div>
<div class="row ">

<div class="col-sm-12 col-sm-8 col-md-8 visible-xs visible-sm rgsfootercommunitylogo">
  <img class=" center-block" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rgscommunity.gif"/>
</div>
</div>
<div class="row rgsreservedrights">

<div class="col-sm-12 col-md-12 col-lg-12">
  <div class="center-block">
<p>&copy; <?php 
 
$currentYear = date('Y'); 
echo  ($currentYear. '');
?> Really Good Stuff, Inc. All Rights Reserved. <br/>
<a href="">Privacy Statement</a>  |  <a href="">Terms of Use</a></p>
  </div>
</div>

</div>
</div>
</div>
</div>
</div>

<?php get_template_part('ltk_email_digest_form'); ?>


</div>



<!-- footer fluid container -->
  <?php wp_footer(); ?> 
  </body>
</html>