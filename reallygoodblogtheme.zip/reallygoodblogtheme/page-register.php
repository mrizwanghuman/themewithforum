<?php 

/**
 * Template Name: Register
 * 
 */

get_header(); ?>
<label for="first_name"><?php _e( 'First Name', 'mydomain' ) ?><br />
                <input type="text" name="first_name" id="first_name" class="input" value="<?php echo esc_attr( wp_unslash( $first_name ) ); ?>" size="25" /></label>

<?php get_footer(); ?>