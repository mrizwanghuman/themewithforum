<?php get_header(); ?>
<div class="col-sm-12">
<section class="row rgssearchpagebordercalss marginbottom rgsmargintop">
    <div class="col-xs-12 col-sm-12 marginbottom catepagestarone"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_TopStar.png"></div>
<header class="col-sm-12 rgsSearchpageHeader marginbottom">
        <div class="rgssearchpageheading"><span>You searched for:</span><span class=" colorff6621"><?php printf( esc_html__( ' "%s"', 'reallygoodblogtheme' ), '<span>' . get_search_query() . '</span>' ); ?></span></div>
        
         
      
      </header>

      <div>

  <!-- Nav tabs -->
  <ul class="nav nav-tabs marginbottom rgssearchpagenavtabs" role="tablist">
    <li role="presentation" class="active"><a href="#rgsarticlessearch" aria-controls="rgsarticlessearch" role="tab" data-toggle="tab">Articles
      <div class="rgssearchcount color898989 text-center"> <?php $mySearch =& new WP_Query("s=$s & showposts=-1&post_type=post");
             $num = $mySearch->post_count;
             echo "$num" ?> Found</div></a>

    </li>
    <li role="presentation" ><a href="#rgsforumsearch" aria-controls="rgsforumsearch" role="tab" data-toggle="tab">Threads<div class="rgssearchcount color898989 text-center"> <?php $mySearch =& new WP_Query("s=$s & showposts=-1&post_type=topic");
             $num = $mySearch->post_count;
             echo "$num" ?> Found</div></a></li>
      
  </ul>

  <!-- Tab panes -->
  <div class="tab-content">
 



    <div role="tabpanel" class="tab-pane active" id="rgsarticlessearch">
<?php $s = isset($_GET["s"]) ? $_GET["s"] : "";

$posts = new WP_Query("s=$s&post_type=post&order=DESC&posts_per_page=10");
if ( $posts->have_posts() ) :
    while ( $posts->have_posts() ) : $posts->the_post();?>
<div class="col-xs-12 col-sm-12 lastqueryclass ">
<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">

<a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('homepagerecentpost');
} 
?></a>
</div>
<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 recenpostcatheading slidertextview">


  <div class="rgsposttitle slidertextview circleimage1"><a  href="<?php the_permalink(); ?>" ><?php the_title();?></a></div>
  <div class=" catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php the_time('F j, Y'); ?></div>
<p><?php echo substr(get_the_excerpt(), 0,170); ?><span class="rgsreadmore"> . . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></span></p>

</div>
</div>
<?php endwhile;
    wp_reset_postdata();?>
    <?php else : ?>
  <div class="col-sm-12"><?php _e( 'No results found.' ); ?></div>
<?php endif;
?>


<div class="col-sm-12 displaynon"> <?php $s = isset($_GET["s"]) ? $_GET["s"] : "";

$posts = new WP_Query("s=$s&post_type=post&order=DESC&offset=10");
if ( $posts->have_posts() ) :
    while ( $posts->have_posts() ) : $posts->the_post();?>
<div class="col-xs-12 col-sm-12 lastqueryclass ">
<div class="col-xs-12 col-sm-12 col-md-5 col-lg-5">

<a href="<?php the_permalink(); ?>">

  <?php 
if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
  the_post_thumbnail('homepagerecentpost');
} 
?></a>
</div>
<div class="col-xs-12 col-sm-12 col-md-7 col-lg-7 recenpostcatheading slidertextview">


  <div class="rgsposttitle slidertextview circleimage1"><a  href="<?php the_permalink(); ?>" ><?php the_title();?></a></div>
  <div class=" catedatfont"><?php
foreach((get_the_category()) as $childcat) {
  $parentcat = $childcat->category_parent;
  echo get_cat_name($parentcat);
}
?> | <?php the_time('F j, Y'); ?></div>
<p><?php echo substr(get_the_excerpt(), 0,170); ?><span class="rgsreadmore"> . . . <a  href="<?php the_permalink(); ?>">read more<span class="glyphicon glyphicon-triangle-right"></span><span class="glyphicon glyphicon-triangle-right"></span></a></span></p>

</div>
</div>
<?php endwhile;
    wp_reset_postdata();?>
    <?php else : ?>
  <div class="col-sm-12"><?php _e( 'No results found.' ); ?></div>
<?php endif;
?></div>
<div class="col-sm-12 marginbottom">
  <button id="showmorepostsbutton" class="center-block sellallartbtn btn">See All Articles<span class="glyphicon glyphicon-triangle-bottom"></span></button>
</div>
</div>


    <div role="tabpanel" class="tab-pane" id="rgsforumsearch">
  <?php $s = isset($_GET["s"]) ? $_GET["s"] : "";
$posts = new WP_Query("s=$s&post_type=topic");
if ( $posts->have_posts() ) : ?>


<div class="col-sm-12">

<div class=" col-sm-12 rgsfooter borderclass paddingtop2">    

  <div class="col-sm-6"><div class="forumMainPageh2">Threads Found</div></div>
  

<div class="col-sm-3">
<div class="forumMainPageh2 bdmfontfamily  text-center">Activity</div>
</div>

<div class="col-sm-2">
  <div class="forumMainPageh2 bdmfontfamily text-center">Last Post</div>
</div>

</div>
</div>
<?php
    while ( $posts->have_posts() ) : $posts->the_post(); ?>
  <div class="col-sm-12">


<ul id="bbp-topic-<?php bbp_topic_id(); ?>"  class="mainpageforumlist col-sm-12 ">

  <li class="bbp-topic-title col-sm-7">

    
    <?php do_action( 'bbp_theme_before_topic_title' ); ?>

    <div class="col-sm-10 rgsgreentitle paddingzero"><a class="bbp-topic-permalink" href="<?php bbp_topic_permalink(); ?>"><?php bbp_topic_title(); ?></a></div>

    <?php do_action( 'bbp_theme_after_topic_title' ); ?>

    <?php bbp_topic_pagination(); ?>

    <?php do_action( 'bbp_theme_before_topic_meta' ); ?>

    <p class="bbp-topic-meta">

      <?php do_action( 'bbp_theme_before_topic_started_by' ); ?>

      <div class="col-sm-12 ">Started by:
        <span class="rgsusernicename ">
        <?php 

 $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
    $user_data = get_userdata( $reply_author_id );
    $user_email = $user_data->user_email;
    $username =$user_data->user_login;
    echo $username  ?></span></div>

      <?php do_action( 'bbp_theme_after_topic_started_by' ); ?>

    <div><?php bbp_topic_excerpt(); ?></div>

    </p>

    <?php do_action( 'bbp_theme_after_topic_meta' ); ?>

    <?php bbp_topic_row_actions(); ?>

  </li>

  <li class="col-sm-2 e5ffc6background text-center color898989"><div class="col-sm-12">

Replies: <?php bbp_topic_reply_count($topic_id) ?>
  </div>
  <div class="col-sm-12 wpviews">Views: <?php echo wpb_get_post_views(get_the_ID()); ?></div></li>



  <li class=" col-sm-3">

    <?php do_action( 'bbp_theme_before_topic_freshness_link' ); ?>

    

    <?php do_action( 'bbp_theme_after_topic_freshness_link' ); ?>

    <div class="rgsusernicename col-sm-12">

      <?php do_action( 'bbp_theme_before_topic_freshness_author' ); ?>

      <span class="bbp-topic-freshness-author"><?php $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
    $user_data = get_userdata( $reply_author_id );
    $user_email = $user_data->user_email;
    $username =$user_data->user_login;
    echo $username ?></span>

      <?php do_action( 'bbp_theme_after_topic_freshness_author' ); ?>

    </div>
    <div class="col-sm-12 color898989">
    <?php bbp_topic_freshness_link(); ?>
  </div>
  </li>

</ul>

  </div>

<?php endwhile;
    wp_reset_postdata();?>
    <?php else : ?>
  <div class="col-sm-12"><?php _e( 'No results found.' ); ?></div>
<?php endif;
?>

</div>



</div>
   
 

</div>
<div class="col-xs-12 col-sm-12 marginbottom catepagestaronebottom rgsmarginbottom"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_BottomStar-1.png">
</div>

</section><!-- #primary -->
</div>
<?php get_footer(); ?>