<?php 
/**
 * Template Name: topic
 * 
 */

get_header(); ?>


<div class="row forumMainPage">
	<div class="col-xs-12 col-sm-12 welcomeforumClass">
<h1>Welcome to the NEW Teacher Forum</h1>

	</div>
</div>
<?php 
// the query
$args = array(
'post_type' => bbp_get_forum_post_type(),
'posts_per_page' => 1,

	);
$the_query = new WP_Query( $args ); ?>

<?php if ( $the_query->have_posts() ) : ?>

	<!-- pagination here -->

	<!-- the loop -->

<div class="row ">


	<div class="col-sm-12 rgsfooter ">
		<?php while ( $the_query->have_posts() ) : $the_query->the_post(); ?>
<div class="row borderclass paddingtop2">		

	<div class="col-sm-7"><h2 class="forumMainPageh2"><?php bbp_forum_title($forum_id = 12668); ?></h2></div>
	<?php endwhile; ?>
	<!-- end of the loop -->

	<!-- pagination here -->

	<?php wp_reset_postdata(); ?>

<?php endif; ?>

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  ">Activity</h2>
</div>

<div class="col-sm-3">
	<h2 class="forumMainPageh2 bdmfontfamily">Last Post</h2>
</div>

</div>

		</div>
		
	

<?php	
$argstopic = array(  
	'order' => 'DESC', 
	'post_parent' => 12668, 
	'post_type' => bbp_get_topic_post_type(),

	'posts_per_page' => 3 );
$topic_id    = bbp_get_topic_id( $widget_query->post->ID );
$anntopicthe_query = new WP_Query( $argstopic ); ?>

<?php if ( $anntopicthe_query->have_posts() ) : ?>



<?php while ( $anntopicthe_query->have_posts() ) : $anntopicthe_query->the_post(); ?>	
<div class="col-sm-12">
	<h3>
		<a class="bbp-forum-title" href="<?php bbp_topic_permalink( $topic_id ); ?>"><?php bbp_topic_title( $topic_id ); ?></a>
	</h3>
</div>
<?php endwhile; ?>
<?php wp_reset_postdata(); ?>
<?php endif; ?>
<div class="col-sm-1"></div>
<div class="col-sm-2"></div>
</div>


<?php 


get_footer( );

?>