<div class="modal" id="modal-blog-digest-footer" tabindex="-1" role="dialog" aria-labelledby="modal-register-label" aria-hidden="true"  >
        	<div class="modal-dialog modal-lg">
        		<div class="modal-content" id="modal-blog-digest-content-footer">
        			
        			 <div class="modal-header" id="modal_signup_header">
        				<!--<button type="button" class="close" data-dismiss="modal">
        					<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
        				</button> -->
                                      
        				<h2 class="text-center" id="modal-register-label" >Thank You For Signing Up For The Weekly Recap!</h2>
        				You will begin receiving your weekly emails soon. Would you also like to receive promotional emails from Really Good Stuff&reg; featuring their newest products and special offers?
        			 </div>
        			
        			 <div class="modal-body" id="modal_signup_body">
        				
       <form id="form_promotional_signup_footer" name="form_promotional_signup_footer" method="post"  accept-charset="UTF-8" class="registration-form" onsubmit="return validate_promotional_email();" >
        <input id="lbl_promotional_signup_footer" type="hidden" name="crvs"/>

			          <div class="form-group" >

   <div class="row">
   <div class="col-lg-9 col-lg-offset-1">
 <label for="email" id="lbl_email_blog_footer" style="display: none;"><b>Email Address:</b></label>                              
 <input type="text" id="email_address_promotional_footer"  name="email"  placeholder="Email Address" class="modal-registration-promotion" style="display: none;" />
 

 </div>
   </div>
<div class="row" style="padding-top: 5px;">
<div class="col-xs-12 col-sm-11 col-sm-offset-1 col-md-11 col-md-offset-1 col-lg-11 col-lg-offset-1">
    <span id="modal_form_validate_footer" style="color: red;"></span>

    <label  for="promotional_subscribe"> 
      <input id="promotional_subscribe" type="checkbox" name="promotional_subscribe" />
      <b>&nbsp;I want to receive Really Good Stuff&reg; promotional emails</b>
    </label>
    
   </div>
</div>
<div class="row">
  <div class="col-xs-12 col-sm-10 col-sm-offset-2 col-md-10 col-md-offset-2  col-lg-10 col-lg-offset-2">
    I'm interested in emails for:
  </div>
</div>
<div class="row" style="padding-top: 3px; padding-bottom: 5px;"> 
   <div class="col-xs-12 col-sm-9 col-sm-offset-3 col-md-9 col-md-offset-3 col-lg-9 col-lg-offset-3">
    <label for="role_1" class="modal-role" > 
      <input type="checkbox" name="CheckBox.Role2.Teacher" id="role_1" onclick="if (this.checked) document.getElementById('promotional_subscribe').checked = true;"/>
      &nbsp;Teachers
     </label>
     <input type="hidden" name="CheckBox.Role2.Teacher" value="off"/>
<br>
      
     <label for="role_2" class="modal-role">
      <input type="checkbox" name="CheckBox.Role2.School_Administrator" id="role_2" onclick="if (this.checked) document.getElementById('promotional_subscribe').checked = true;" />
      &nbsp;School Administrators
     </label>
     <input type="hidden" name="CheckBox.Role2.School_Administrator" value="off"/>
<br>

     <label for="role_3" class="modal-role">
      <input type="checkbox" name="CheckBox.Role2.Childcare_Preschool_Prof" id="role_3" onclick="if (this.checked) document.getElementById('promotional_subscribe').checked = true;"/>
       &nbsp;Childcare or Preschool Teachers/Directors                                         
     </label>
     <input type="hidden" name="CheckBox.Role2.Childcare_Preschool_Prof" value="off"/>
<br>

     <label for="role_4" class="modal-role">
     <input type="checkbox" name="CheckBox.Role2.Parent_Other" id="role_4" onclick="if (this.checked) document.getElementById('promotional_subscribe').checked = true;"/>
      &nbsp;Parent/Other
     </label>
     <input type="hidden" name="CheckBox.Role2.Parent_Other" value="off"/>
</div>
 </div>  
                              
                              
   <input hidden checked type="checkbox" name="CheckBox.Marketing Emails.Promotional emails"  /><input type="hidden" name="CheckBox.Marketing Emails.Promotional emails" value="off"/>
                
                                     
     <input hidden checked type="checkbox" name="CheckBox.Blog Sign Ups.Promotional Emails" /><input type="hidden" name="CheckBox.Blog Sign Ups.Promotional Emails" value="off"/>
</div>
<div class="row" style="padding-bottom: 5px;">
<div class="col-xs-12 col-sm-3 col-md-4 col-lg-4">
</div>
<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
   <div class="text-center">
    <button type="submit" id="submit" value="Sign Up" class="btn_promotion">Yes, I'm Interested.</button></div>
</div>
<div class="col-xs-12 col-sm-3 col-md-4 col-lg-4">
</div>
</div>
<div class="row" style="padding-top: 7px;">

<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">

     <div class="text-center"><a href="#" data-dismiss="modal">No, Thanks</a></div>
</div>
</div>
<div class="row" style="padding-top: 14px;">
 <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
  <span  class="modal-form-disclaimer"> By providing this information, you are opting to receive emails, from Really Good Stuff&reg;  with promotions and message tailored to your interests. 
You may unsubscribe at any time.</span>
 </div>
</div>
</form>

</div>



<div class="modal-header" style="display: none;" id="modal_signup_header_thank_you"> 
 <!--<button type="button" class="close" data-dismiss="modal">
<span aria-hidden="true">&times;</span><span class="sr-only">Close</span>
</button> -->

       <div style="height: 59px;"></div>
      <h1 class="text-center">Thank You for signing up!</h1>                                      
</div>

<div class="modal-body" style="display: none;" id="modal_signup_body_thank_you">


<div style="height: 59px;"></div>

</div>



</div>
</div>