<!DOCTYPE html>
<html >
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:image:width" content="450"/>
<meta property="og:image:height" content="298"/>
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
 <link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
     
   <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
     <?php wp_head(); ?> 
  </head>
  <body  <?php body_class('clearfix'); ?>>
    <div class="container-fluid ">
      <div class="row"> 
  <header>
    

<div class="row">
  <div class="specialannouncements">
  <?php
$args = array( 'post_type' => 'topmain_alert', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
  the_title();
 
endwhile;
?>
</div>
</div>

<div class="row">
  <div class="topbannerheader ">

</div>
</div>
 



 <!-- 990px container -->
<div class="container">
  <div class="col-sm-12 col-xs-12">
<div class="row">
  
<div class="col-xs-8 col-sm-8 col-md-10 ">
  <img class="hidden-xs hidden-sm"  src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/rgscommunity.gif" alt="Really Good Stuff community"/>
</div>

 <div class="col-xs-4 col-sm-4 col-md-2   ">
  <div class="rgsteacherlogincol ">
   
   <?php
  if ( is_user_logged_in() ) {
    global $current_user;
       get_currentuserinfo(); 
       ?>
  <div class="rgsteacherlogin2" id="rgsteacherlogin2"> 
    <ul id="welcomeuserli">
      <li>
        <a href="#notification" aria-controls="notification" role="tab" data-toggle="tab">
    <?php $notifiactioncount= bp_notifications_get_unread_notification_count( bp_loggedin_user_id() );
     if($notifiactioncount<=0){
      echo '';
     }else {echo '<div class="badge">'.$notifiactioncount.'</div>';}
     ?></a>
        <?php echo 'Welcome </br>'.$current_user->user_firstname.
        '<span class="glyphicon glyphicon-triangle-bottom"></span>' ?>
  
      </li>
   </ul> 
</div>
     <?php
              wp_nav_menu( array(
                  'menu'              => 'userloginmenu',
                  'theme_location'    => 'userloginmenu',
                  'depth'             => 1,
                  'container'         => 'div',
                  'container_class'    => 'hoverTeacherlogin'
                   
                  )
              );
              ?>
               
 <?php } else {?>
<div class="teacherloginmenu">
 <div class="rgsteacherlogin"> 
  <ul>
 
<li>     
        <a class="login_button" id="show_login" href="">Join or <br/>Log In <span class="glyphicon glyphicon-triangle-bottom"></span></a>
</li>
</ul>
 </div>
</div>
 <?php } ?>
      </div>
</div>
</div>
<div class="row">

<div class="col-sm-12"><?php get_template_part('ajax', 'auth'); ?></div>
</div>

<div class="row">
  <div class="col-sm-4 col-md-3 hidden-xs hidden-sm socialdiv">
<ul>

<li class="pinterest">
<a href="https://www.pinterest.com/reallygoodstuff" target="_blank"><i class="fa fa-pinterest-p "></i></a>
</li>
<li class="facebook">
<a href="https://www.facebook.com/ReallyGoodStuff/" target="_blank"><i class="fa fa-facebook"></i></a>
</li>
<li class="instagram">
<a href="https://www.instagram.com/reallygoodstuff/" target="_blank"><i class="fa fa-instagram "></i></a>
</li>
<li class="twitter">
<a href="https://twitter.com/reallygoodstuff" target="_blank"><i class="fa fa-twitter "></i></a>
</li>

</ul>
</div>
</div>

<div class="row no-pad">

<!-- RGS Social Icons -->

<div class="col-xs-1 col-sm-1 col-md-3 ">
</div>

  <div class=" col-xs-10 col-sm-10 col-md-6 logoimage "><a href="<?php echo esc_url( home_url( '/' ) ); ?>" >
    <img class="pull-right" src="<?php header_image(); ?>"  alt="Really Goodstuff Logo" /></a>
  
<div class="text-center col-xs-12 col-sm-12 col-md-12 logoline"><span class="logolinetext">Formerly</span> <span class="logoline2text">The Teachers' Lounge</span></div>

  </div>
 <div class="col-xs-1 col-sm-1 col-md-3 "></div>
</div>

<div class="row heightedrow">
  <div class="col-xs-2 col-sm-2 collaspedmenu">
<div class="navbar-header ">
      <button type="button" class="navbar-toggle rgsprimarymenu pull-left" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar center-block"></span>
        <span class="icon-bar center-block"></span>
        <span class="icon-bar center-block"></span>
        <div class=" center-block rgsmenu">MENU</div>
      </button>
     
    </div>
</div>
<div class="col-xs-10 col-sm-10  visible-xs visible-sm heightedrow">
<form role="search" method="get" class="search-form form-inline " action="<?php echo home_url( '/' ); ?>">
  
   <div class="row no-pad"> 
    <div class="col-sm-10 col-xs-10 form-group ">
       <input type="search" class="search-field  form-control"  value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( '', 'label' ) ?>" />
     
     </div>

    <div class="form-group col-xs-2 col-sm-2 "> <input type="submit" class="search-submit form-control" align="center" value="&#xf002;" />
         </div>
   </div>
</form>


</div>
</div>
<div class="row marginbottom  rgsmenurow">
  <div class="col-xs-12 col-sm-12 col-md-9 col-lg-9 paddingzero">
<nav class="navbar navbar-default" role="navigation">
  <div class="container-fluid">
  <div class="row">  
     
  
          <?php
              wp_nav_menu( array(
                  'menu'              => 'primary',
                  'theme_location'    => 'primary',
                  'depth'             => 2,
                  'container'         => 'div',
                  'container_class'   => 'collapse navbar-collapse',
          'container_id'      => 'bs-example-navbar-collapse-1',
                  'menu_class'        => 'nav nav-tabs  nav-justified',
                  'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                  'walker'            => new wp_bootstrap_navwalker())
              );
          ?></div>
    </div>
</nav>
</div>
<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 paddingzero hidden-sm hidden-xs">
<form role="search" method="get" class="search-form " action="<?php echo home_url( '/' ); ?>">
  
   <div class="row no-pad"> 
       <input type="search" class="search-field col-sm-10 col-md-10 col-xs-10 "  value="<?php echo get_search_query() ?>" name="s" title="<?php echo esc_attr_x( '', 'label' ) ?>" />
       <input type="hidden" name="post_type[]" value="post" />
<input type="hidden" name="post_type[]" value="topic" /> 
     
     <div class="col-sm-2 col-md-2 
     col-xs-2">
     <input type="submit" class="search-submit "  value="&#xf002;" />
     </div>
   </div>
</form>

</div>
</div>

</div>
</div>


   </header>
 
<div class="container">

  <div class="col-sm-12 marginbottom">



