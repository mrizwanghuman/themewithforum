<?php
/**
 * Initialize the custom theme options.
 */
add_action( 'init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 */
function custom_theme_options() {
  
  /* OptionTree is not loaded yet, or this is not an admin request */
  if ( ! function_exists( 'ot_settings_id' ) || ! is_admin() )
    return false;
    
  /**
   * Get a copy of the saved settings array. 
   */
  $saved_settings = get_option( ot_settings_id(), array() );
  
  /**
   * Custom settings array that will eventually be 
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array( 
    'contextual_help' => array( 
      'sidebar'       => ''
    ),
    'sections'        => array( 
      array(
        'id'          => 'general',
        'title'       => 'General'
      )
    ),
    'settings'        => array( 
      array(
        'id'          => 'rgs_feature_cat_homepage',
        'label'       => '1st Feature Category',
        
        'std'         => '',
        'type'        => 'category-select',
        'section'     => 'general',
        'rows'        => '1',
        'post_type'   => 'post',
        'taxonomy'    => '',
        'min_max_step'=> '0, 3',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rgs_feature_cat_homepageone2',
        'label'       => '2nd Feature Category',
       
        'std'         => '',
        'type'        => 'category-select',
        'section'     => 'general',
        'rows'        => '1',
        'post_type'   => 'post',
        'taxonomy'    => '',
        'min_max_step'=> '0, 3',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rgs_feature_cat_homepageone3',
        'label'       => '3rd Feature Category',
       
        'std'         => '',
        'type'        => 'category-select',
        'section'     => 'general',
        'rows'        => '1',
        'post_type'   => 'post',
        'taxonomy'    => '',
        'min_max_step'=> '0, 3',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'rgs_feature_cat_homepageone4',
        'label'       => '4th Feature Category',
       
        'std'         => '',
        'type'        => 'category-select',
        'section'     => 'general',
        'rows'        => '1',
        'post_type'   => 'post',
        'taxonomy'    => '',
        'min_max_step'=> '0, 3',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      

      array(
        'id'          => 'rgs_slides_homepage',
        'label'       => 'Number of slides to show 
                          on RGS Home Page',
        
        'std'         => '',
        'type'        => 'text',
        'section'     => 'general',
        'rows'        => '1',
        'post_type'   => 'post',
        'taxonomy'    => '',
        'min_max_step'=> '0, 3',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      )
    )
  );
  
  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );
  
  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings ); 
  }
  
  /* Lets OptionTree know the UI Builder is being overridden */
  global $ot_has_custom_theme_options;
  $ot_has_custom_theme_options = true;
  
}