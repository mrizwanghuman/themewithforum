
<div class="row rgsforumnavbar">
  <ul class="rgsforumnavclass nav nav-tabs nav-justified">
<!-- <li>
<a href="">Whats New</a>
</li> --><li>
<a href="">Rules And Regulations</a>
</li><li>
<a href="">FAQs</a>
</li><li>
     
   
   <?php
  if ( is_user_logged_in() ) {
    global $current_user;
       get_currentuserinfo(); 
       ?>
  
      <div class="text-center">
      
  <a href="<?php echo bp_loggedin_user_domain(); ?>">My Account</a>
      </div>

     
               
 <?php } else {?>
    
   <a class="login_button" id="show_login" href="">Join or Log In </a>

 <?php } ?>
     

<!-- <ul class="rgsforumlogin ">
<li > <?php // wp_register('', ' '); ?></li><li><a href="#">or</a></li><li ><?php wp_loginout(); ?></li>
</ul> -->
</li>
</ul>
</div>





