<?php
/**
 * BuddyPress - Members Register
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>
<div  class="row" >
	<?php

	/**
	 * Fires at the top of the BuddyPress member registration page template.
	 *
	 * @since 1.1.0
	 */
	do_action( 'bp_before_register_page' ); ?>
<div class="col-sm-1 "></div>
	<div class="col-sm-10 col-xs-12 rgs-registration-form">

     
              <form id="form_promotional_forum" name="form_promotional_forum" method="post" action="http://enews.reallygoodstuff.com/q/T8g9UagWpPgMZKdimkKw8MnNikUDKNLe-V" accept-charset="UTF-8" >
            <input type="hidden" name="crvs" value="qHKSyhTF6AX-XFl3ZCi-0Fd0W-aqpZj8JysOlXCLsfbtnghbPpAmIBc2wpBpV2NxHWbqN28oiYqbIFeTCbtzNQ" />

           <input type="text" id="email_address_promotional_forum" name="email" size="40" maxlength="100" value="<?php if(isset($_POST['signup_email'])){echo htmlentities($_POST['signup_email']); }?>" hidden />
	
	    <label hidden><input  type="checkbox" name="CheckBox.Role2.Teacher" id="ltk_role_forum_1" <?php if(isset($_POST['CheckBoxRole2Temp'])) echo "checked"; ?> hidden  />Teacher</label><input type="hidden" name="CheckBox.Role2.Teacher" value="off"/>
	
           <label hidden><input type="checkbox" name="CheckBox.Role2.School_Administrator"  id="ltk_role_forum_2" <?php if(isset($_POST['CheckBoxRole2SchoolAdministratorTemp'])) echo "checked"; ?> hidden />School_Administrator</label><input type="hidden" name="CheckBox.Role2.School_Administrator" value="off"/>
	
    
          <label hidden><input type="checkbox" name="CheckBox.Role2.Childcare_Preschool_Prof"  id="ltk_role_forum_3" <?php if(isset($_POST['CheckBoxRole2ChildcarePreschoolProfTemp'])) echo "checked"; ?> hidden  />Childcare_Preschool_Prof</label><input type="hidden" name="CheckBox.Role2.Childcare_Preschool_Prof" value="off"/>
	
          <label hidden><input type="checkbox" name="CheckBox.Role2.Parent_Other"  id="ltk_role_forum_4" <?php if(isset($_POST['CheckBoxRole2ParentOtherTemp'])) echo "checked"; ?> hidden />Parent_Other</label><input type="hidden" name="CheckBox.Role2.Parent_Other" value="off"/>
	
	   <label><input checked type="checkbox" name="CheckBox.Blog Sign Ups.Promotional Emails" hidden /></label><input type="hidden" name="CheckBox.Blog Sign Ups.Promotional Emails" value="off"/>
	
       <input type="submit" id="submit_the_forum_button" value="Sign Up" hidden />
	
      </form>
 
 
      <form id="form_blog_digest_forum" method="post" action="http://enews.reallygoodstuff.com/q/kGlhJlTbjoumBnEsnwSxijro_EJlKUIZKa" accept-charset="UTF-8" hidden>
            <input type="hidden" name="crvs" value="qHKSyhTF6AX-XFl3ZCi-0Fd0W-aqpZj8JysOlXCLsfbtnghbPpAmIBc2wpBpV2NxHWbqN28oiYqbIFeTCbtzNQ" />
             <input type="text"  id="email_address_blog_forum" name="email" size="40" maxlength="100" value="<?php if(isset($_POST['signup_email'])){echo htmlentities($_POST['signup_email']); }?>" hidden/>
	      <label><input type="checkbox" name="CheckBox.Blog.SignUp" style=" display: none;" checked />SignUp</label><input type="hidden" name="CheckBox.Blog.SignUp" value="off" /><input type="submit" id="submit_blog_forum_btn" value="Sign Up" hidden/>
       </form>




		<form action="" name="signup_form" id="signup_form" class=" form-horizontal" method="post" enctype="multipart/form-data" autocomplete="off">

		<?php if ( 'registration-disabled' == bp_get_current_signup_step() ) : ?>
			<?php

			/** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
			do_action( 'template_notices' ); ?>
			<?php

			/**
			 * Fires before the display of the registration disabled message.
			 *
			 * @since 1.5.0
			 */
			do_action( 'bp_before_registration_disabled' ); ?>

				<p><?php _e( 'User registration is currently not allowed.', 'buddypress' ); ?></p>

			<?php

			/**
			 * Fires after the display of the registration disabled message.
			 *
			 * @since 1.5.0
			 */
			do_action( 'bp_after_registration_disabled' ); ?>
		<?php endif; // registration-disabled signup step ?>

		<?php if ( 'request-details' == bp_get_current_signup_step() ) : ?>

			<?php

			/** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
			do_action( 'template_notices' ); ?>

			<div class="text-center rgsjoinusheading"><?php _e( 'Get ready to be a part of</br>a helpful and active teaching community!

', 'buddypress' ); ?></div>

			<?php

			/**
			 * Fires before the display of member registration account details fields.
			 *
			 * @since 1.1.0
			 */
			do_action( 'bp_before_account_details_fields' ); ?>

			<div class="form-group">
<label for="signup_username" generated="true" class="error"></label>
				<?php /***** Basic Account Details ******/ ?>
								
				<label for="signup_username" class="col-sm-4 control-label"><?php _e( 'Display Name', 'buddypress' ); ?> </label>
				<?php

				/**
				 * Fires and displays any member registration username errors.
				 *
				 * @since 1.1.0
				 */

				do_action( 'bp_signup_username_errors' ); ?>
				<div class="col-sm-4">
				<input type="text" class="form-control" name="signup_username" id="signup_username" value="<?php bp_signup_username_value(); ?>" <?php bp_form_field_attributes( 'username' ); ?>/>
						
</div>
<div class="col-sm-3">
<span>Cannot be changed once account is created</span>
</div>

</div>
<div class="form-group">

				<label for="signup_email" class="col-sm-4 control-label"><?php _e( 'Email Address', 'buddypress' ); ?> </label>

				<?php

				/**
				 * Fires and displays any member registration email errors.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_signup_email_errors' ); ?>
				<div class="col-sm-4">
				<input type="email" class="form-control" name="signup_email" id="signup_email" value="<?php bp_signup_email_value(); ?>" <?php bp_form_field_attributes( 'email' ); ?>/>
				</div>
				<div class="col-sm-4"></div>
</div>
<div class="form-group">
	
				<label for="signup_password" class="col-sm-4 control-label"><?php _e( 'Password', 'buddypress' ); ?> </label>
				<?php

				/**
				 * Fires and displays any member registration password errors.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_signup_password_errors' ); ?>
<div class="col-sm-4">
				<input type="password" name="signup_password" id="signup_password" value="" class="form-control" <?php bp_form_field_attributes( 'password' ); ?>/>
				</div>
				<div class="col-sm-3"><span>Minimum of 8 characters including 1 number.</span></div>
</div>
<div class="form-group">

				<label for="signup_password_confirm" class="col-sm-4 control-label"><?php _e( 'Confirm Password', 'buddypress' ); ?> </label>
				<?php

				/**
				 * Fires and displays any member registration password confirmation errors.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_signup_password_confirm_errors' ); ?>
				<div class="col-sm-4">
				<input type="password" name="signup_password_confirm" id="signup_password_confirm" value="" class="form-control" <?php bp_form_field_attributes( 'password' ); ?>/>
			</div>
</div>
				<?php

				/**
				 * Fires and displays any extra member registration details fields.
				 *
				 * @since 1.9.0
				 */
				do_action( 'bp_account_details_fields' ); ?>

			<!-- #basic-details-section -->

			<?php

			/**
			 * Fires after the display of member registration account details fields.
			 *
			 * @since 1.1.0
			 */
			do_action( 'bp_after_account_details_fields' ); ?>

			<?php /***** Extra Profile Details ******/ ?>

			<?php if ( bp_is_active( 'xprofile' ) ) : ?>

				<?php

				/**
				 * Fires before the display of member registration xprofile fields.
				 *
				 * @since 1.2.4
				 */
				do_action( 'bp_before_signup_profile_fields' ); ?>

				

				

					<?php /* Use the profile field loop to render input fields for the 'base' profile field group */ ?>
					<?php if ( bp_is_active( 'xprofile' ) ) : if ( bp_has_profile( array( 'profile_group_id' => 1, 'fetch_field_data' => false ) ) ) : while ( bp_profile_groups() ) : bp_the_profile_group(); ?>

		<?php while ( bp_profile_fields() ) : bp_the_profile_field(); ?>
<div class="form-group">

<?php if ( 'textbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" class="col-sm-4 control-label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<div class="col-sm-4">
	<input type="text" name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" value="<?php bp_the_profile_field_edit_value() ?>" class="form-control"/>
</div>
<div class="col-sm-3"><span>Will not be
publically displayed</span></div>
<?php endif; ?>

<?php if ( 'textarea' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" ><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<textarea rows="5" cols="40" name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>"><?php bp_the_profile_field_edit_value() ?></textarea>

<?php endif; ?>

<?php if ( 'selectbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" class="col-sm-4 control-label"><?php bp_the_profile_field_name() ?> </label>

	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<div class="col-sm-4">
	<select name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" class="form-control">
		<?php bp_the_profile_field_options() ?>
	</select>
</div>
<div class="col-sm-4"></div>
<?php endif; ?>

<?php if ( 'multiselectbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<select name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" multiple="multiple">
		<?php bp_the_profile_field_options() ?>
	</select>

<?php endif; ?>

<?php if ( 'radio' == bp_get_the_profile_field_type() ) : ?>

	<div class="radio">
		<span class="label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></span>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
		<?php bp_the_profile_field_options() ?>

		<?php if ( !bp_get_the_profile_field_is_required() ) : ?>
			<a class="clear-value" href="javascript:clear( '<?php bp_the_profile_field_input_name() ?>' );"><?php _e( 'Clear', 'buddypress' ) ?></a>
		<?php endif; ?>
	</div>

<?php endif; ?>


<?php if ( 'checkbox' == bp_get_the_profile_field_type() ) : ?>
	<div class="col-sm-3"></div>
  	<div class="checkbox termandcondition col-sm-9">
		<span class="label"><?php bp_the_profile_field_name() ?> </span>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
		<?php bp_the_profile_field_options() ?>
	</div>
   
<?php endif; ?>

<?php if ( 'datebox' == bp_get_the_profile_field_type() ) : ?>


		<label for="<?php bp_the_profile_field_input_name() ?>_day" class="col-sm-2 control-label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
<div class="col-sm-6">
		<select name="<?php bp_the_profile_field_input_name() ?>_year" id="<?php bp_the_profile_field_input_name() ?>_year" class="form-control">
			<?php bp_the_profile_field_options( 'type=year' ) ?>
		</select>
	
</div>
<div class="col-sm-4">Optional</div>
<?php endif; ?>

<?php do_action( 'bp_custom_profile_edit_fields' ) ?>

<span class="description nextotembox"><?php bp_the_profile_field_description() ?></span>

</div>

					<?php endwhile; ?>

					<input type="hidden" name="signup_profile_field_ids" id="signup_profile_field_ids" value="<?php bp_the_profile_field_ids(); ?>" />

					<?php endwhile; endif; endif; ?>

					<?php

					/**
					 * Fires and displays any extra member registration xprofile fields.
					 *
					 * @since 1.9.0
					 */
					do_action( 'bp_signup_profile_fields' ); ?>

				<!-- #profile-details-section -->

				<?php

				/**
				 * Fires after the display of member registration xprofile fields.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_after_signup_profile_fields' ); ?>

			<?php endif; ?>

			<?php if ( bp_get_blog_signup_allowed() ) : ?>

				<?php

				/**
				 * Fires before the display of member registration blog details fields.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_before_blog_details_fields' ); ?>

				<?php /***** Blog Creation Details ******/ ?>

				<div class="register-section" id="blog-details-section">

					<h4><?php _e( 'Blog Details', 'buddypress' ); ?></h4>

					<p><label for="signup_with_blog"><input type="checkbox" name="signup_with_blog" id="signup_with_blog" value="1"<?php if ( (int) bp_get_signup_with_blog_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'Yes, I\'d like to create a new site', 'buddypress' ); ?></label></p>

					<div id="blog-details"<?php if ( (int) bp_get_signup_with_blog_value() ) : ?>class="show"<?php endif; ?>>

						<label for="signup_blog_url"><?php _e( 'Blog URL', 'buddypress' ); ?> <?php _e( '(required)', 'buddypress' ); ?></label>
						<?php

						/**
						 * Fires and displays any member registration blog URL errors.
						 *
						 * @since 1.1.0
						 */
						do_action( 'bp_signup_blog_url_errors' ); ?>

						<?php if ( is_subdomain_install() ) : ?>
							http:// <input type="text" name="signup_blog_url" id="signup_blog_url" value="<?php bp_signup_blog_url_value(); ?>" /> .<?php bp_signup_subdomain_base(); ?>
						<?php else : ?>
							<?php echo home_url( '/' ); ?> <input type="text" name="signup_blog_url" id="signup_blog_url" value="<?php bp_signup_blog_url_value(); ?>" />
						<?php endif; ?>

						<label for="signup_blog_title"><?php _e( 'Site Title', 'buddypress' ); ?> <?php _e( '(required)', 'buddypress' ); ?></label>
						<?php

						/**
						 * Fires and displays any member registration blog title errors.
						 *
						 * @since 1.1.0
						 */
						do_action( 'bp_signup_blog_title_errors' ); ?>
						<input type="text" name="signup_blog_title" id="signup_blog_title" value="<?php bp_signup_blog_title_value(); ?>" />

						<span class="label"><?php _e( 'I would like my site to appear in search engines, and in public listings around this network.', 'buddypress' ); ?></span>
						<?php

						/**
						 * Fires and displays any member registration blog privacy errors.
						 *
						 * @since 1.1.0
						 */
						do_action( 'bp_signup_blog_privacy_errors' ); ?>

						<label for="signup_blog_privacy_public"><input type="radio" name="signup_blog_privacy" id="signup_blog_privacy_public" value="public"<?php if ( 'public' == bp_get_signup_blog_privacy_value() || !bp_get_signup_blog_privacy_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'Yes', 'buddypress' ); ?></label>
						<label for="signup_blog_privacy_private"><input type="radio" name="signup_blog_privacy" id="signup_blog_privacy_private" value="private"<?php if ( 'private' == bp_get_signup_blog_privacy_value() ) : ?> checked="checked"<?php endif; ?> /> <?php _e( 'No', 'buddypress' ); ?></label>

						<?php

						/**
						 * Fires and displays any extra member registration blog details fields.
						 *
						 * @since 1.9.0
						 */
						do_action( 'bp_blog_details_fields' ); ?>

					</div>

				</div><!-- #blog-details-section -->

				<?php

				/**
				 * Fires after the display of member registration blog details fields.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_after_blog_details_fields' ); ?>

			<?php endif; ?>

			<?php

			/**
			 * Fires before the display of the registration submit buttons.
			 *
			 * @since 1.1.0
			 */
			do_action( 'bp_before_registration_submit_buttons' ); ?>

                 
           
			

			<?php

			/**
			 * Fires after the display of the registration submit buttons.
			 *
			 * @since 1.1.0
			 */
			do_action( 'bp_after_registration_submit_buttons' ); ?>

			<?php wp_nonce_field( 'bp_new_signup' ); ?>
            
             
            

         <?php endif; // request-details signup step ?>
     
                           
             <div id="blog_promo_signup_box" style="border: 1px solid #fad556; padding: 25px; margin: 0px 0px 45px 0px; ">
               <div class="row">
                  <div class="col-xs-11 col-xs-offset-1 col-sm-11 col-sm-offset-1  col-md-10 col-md-offset-2 col-lg-10 col-lg-offset-2" >
                     <div style="padding: 0px 0px 5px 0px;"> 
                          
                      <label for="forum_blog_signup" class="control-label">
                             <input type="checkbox" name="forum_blog_signup_chkbox" id="forum_blog_signup_chkbox"  <?php if(isset($_POST['forum_blog_signup_chkbox'])) echo "checked"; ?> />  
                             &nbsp; I want to receive the Really Good Teacher&trade; Weekly Update Emails.
                            
                             </label>
                                           
                   		 <label for="forum_promotional_signup" class="control-label">
                  		 <input type="checkbox" name="forum_promotional_signup_chkbox" id="forum_promotional_signup_chkbox"  <?php if(isset($_POST['forum_promotional_signup_chkbox'])) echo "checked"; ?> />
                    		&nbsp; I want to receive Really Good Stuff&trade; Promotional Emails.
                   		</label>  
                            <div style="padding-bottom: 5px;">&nbsp;</div>                                 
                   		<table >
                      		<tr>
                       		 <td>		
                         		  <label ><input type="checkbox" name="CheckBoxRole2Temp" id="ltk_role_forum_temp_1" <?php if(isset($_POST['CheckBoxRole2Temp'])) echo "checked"; ?> />Teacher</label>
	                 		</td>
                      		</tr>
                      		<tr> 
                        		<td>
                        		  <label ><input type="checkbox" name="CheckBoxRole2SchoolAdministratorTemp"  id="ltk_role_forum_temp_2" <?php if(isset($_POST['CheckBoxRole2SchoolAdministratorTemp'])) echo "checked"; ?> />School Administrator</label>
                        		</td>
                     		</tr>
                    			 <tr>
                      		 <td>
	               		  <label ><input type="checkbox" name="CheckBoxRole2ChildcarePreschoolProfTemp"   id="ltk_role_forum_temp_3" <?php if(isset($_POST['CheckBoxRole2ChildcarePreschoolProfTemp'])) echo "checked"; ?> />Childcare Preschool Professional</label>
                      		</td>
                  		       </tr>
                 			 <tr>
                 			   <td>
	          			    <label ><input type="checkbox" name="CheckBoxRole2ParentOtherTemp"   id="ltk_role_forum_temp_4" <?php if(isset($_POST['CheckBoxRole2ParentOtherTemp'])) echo "checked"; ?> />Parent Other</label>
                 			  </td>
                			 </tr>
                		</table>   
                       </div>
                                     
                    </div> 
                 </div>
               </div> 
         

           




           
             

               <div class="col-sm-12 marginbottom">
				<input type="submit" name="signup_submit" id="signup_submit" class="sellallartbtn btn center-block" value="<?php esc_attr_e( 'Sign Up', 'buddypress' ); ?>" onClick="calculate_role_by_position_forum();" />
			</div>
            
            

		<?php if ( 'completed-confirmation' == bp_get_current_signup_step() ) : ?>
                   
                      <script type="text/javascript">
                        submit_listrak_registration_forum();

                      </script>
                   
			<?php

			/** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
			do_action( 'template_notices' ); ?>
			<?php

			/**
			 * Fires before the display of the registration confirmed messages.
			 *
			 * @since 1.5.0
			 */
			do_action( 'bp_before_registration_confirmed' ); ?>

			<?php if ( bp_registration_needs_activation() ) : ?>
			    <div class="row">
                           <div class="col-sm-10 col-sm-offset-1 col-md-8 col-md-offset-2 col-lg-8 col-lg-offset-2" style="padding: 25px 0px 250px 0px;">
                             
                              <p class="text-center" style="font-size: 19px; font-weight: bold;"><?php _e( 'Thank you for registering for Really Good Teachers&trade;! To complete your registration, please follow the link in your email.', 'buddypress' ); ?></p>
                             
                           </div>
                          
                         </div>
			 <?php else : ?>
				<p><?php _e( 'You have successfully created your account! Please log in using the username and password you have just created.', 'buddypress' ); ?></p>
			<?php endif; ?>

			<?php

			/**
			 * Fires after the display of the registration confirmed messages.
			 *
			 * @since 1.5.0
			 */
			do_action( 'bp_after_registration_confirmed' ); ?>

		<?php endif; // completed-confirmation signup step ?>

		<?php

		/**
		 * Fires and displays any custom signup steps.
		 *
		 * @since 1.1.0
		 */
		do_action( 'bp_custom_signup_steps' ); ?>

		</form>

	</div>
<div class="col-sm-1 "></div>
	<?php

	/**
	 * Fires at the bottom of the BuddyPress member registration page template.
	 *
	 * @since 1.1.0
	 */
	do_action( 'bp_after_register_page' ); ?>

</div><!-- #buddypress -->


