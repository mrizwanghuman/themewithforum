<?php
/**
 * BuddyPress - Users Settings
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>
<div class="row">

<?php 
do_action( 'bp_before_member_home_content' ); ?>


	<div class="col-sm-6 col-sm-offset-2 col-xs-12 " role="complementary">

		<?php
		/**
		 * If the cover image feature is enabled, use a specific header
		 */
		
			bp_get_template_part( 'members/single/member-header' );
		
		?>

	</div><!-- #item-header -->

	<!-- #item-nav -->

<div class="col-sm-12 col-xs-12 paddingzero">

 <!--  <div class="col-sm-1 col-xs-1 paddingzero">space</div> -->
  <ul class="nav nav-tabs marginbottom rgssearchpagenavtabs  rgsmembernav " role="tablist">
    <li role="presentation" ><a href="#notification" aria-controls="notification" role="tab" data-toggle="tab">
     Notification  <?php $notifiactioncount= bp_notifications_get_unread_notification_count( bp_loggedin_user_id() );
     if($notifiactioncount<=0){
      echo '';
     }else {echo '<span class="badge">'.$notifiactioncount.'</span>';}
     ?></a> </li>
    <li role="presentation"><a href="#profilefeed" aria-controls="profilefeed" role="tab" data-toggle="tab">Personal Feed</a></li>
    <li role="presentation"><a href="#favrt" aria-controls="favrt" role="tab" data-toggle="tab">Favorites</a></li>
    <li role="presentation" class="active"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab">Profile & Settings</a></li>
  </ul>
<!-- <div class="col-sm-1 col-xs-1 paddingzero rgspfborderbottom">space</div> -->
  <!-- Tab panes -->
  <div class="tab-content col-sm-12">
    <div role="tabpanel" class="tab-pane  row" id="notification">
    <?php bp_notifications_sort_order_form(); ?>	
  <?php
 if ( bp_has_notifications() ) : ?>
 <?php 

   while ( bp_the_notifications() ) : bp_the_notification(); ?>

 <div class="col-sm-12"> <?php bp_the_notification_description();  ?></div>

  <?php endwhile; wp_reset_postdata();?>
<?php endif; ?>

  </div>
    <div role="tabpanel" class="tab-pane col-sm-12" id="profilefeed">
    	

      <?php 
      global $current_user; 
      get_currentuserinfo(); 
      $uid = bbp_get_current_user_id(); ?>
<?php if ( bbp_get_user_topic_subscriptions( $uid ) ) : ?>
    <div class=" col-sm-12 rgsfooter borderclass paddingtop2">    

  <div class="col-sm-7"><h2 class="forumMainPageh2">Threads You Are Following</h2></div>
  

<div class="col-sm-2">
<h2 class="forumMainPageh2 bdmfontfamily  text-center">Activity</h2>
</div>

<div class="col-sm-3">
  <h2 class="forumMainPageh2 bdmfontfamily text-center">Last Post</h2>
</div>

</div>
<?php while ( bbp_topics() ) : bbp_the_topic(); ?>
    <ul id="bbp-topic-<?php bbp_topic_id(); ?>"  class="mainpageforumlist col-sm-12 ">

  <li class="bbp-topic-title col-sm-7">

    <?php if ( bbp_is_user_home() ) : ?>

      <?php if ( bbp_is_favorites() ) : ?>

        <span class="bbp-row-actions">

          <?php do_action( 'bbp_theme_before_topic_favorites_action' ); ?>

          <?php bbp_topic_favorite_link( array( 'before' => '', 'favorite' => '+', 'favorited' => '&times;' ) ); ?>

          <?php do_action( 'bbp_theme_after_topic_favorites_action' ); ?>

        </span>

      <?php elseif ( bbp_is_subscriptions() ) : ?>

        <span class="bbp-row-actions">

          <?php do_action( 'bbp_theme_before_topic_subscription_action' ); ?>

          <?php bbp_topic_subscription_link( array( 'before' => '', 'subscribe' => '+', 'unsubscribe' => '&times;' ) ); ?>

          <?php do_action( 'bbp_theme_after_topic_subscription_action' ); ?>

        </span>

      <?php endif; ?>

    <?php endif; ?>

    <?php do_action( 'bbp_theme_before_topic_title' ); ?>

    <div class="col-sm-10 rgsgreentitle paddingzero"><a class="bbp-topic-permalink" href="<?php bbp_topic_permalink(); ?>"><?php bbp_topic_title(); ?></a></div>

    <?php do_action( 'bbp_theme_after_topic_title' ); ?>

    <?php bbp_topic_pagination(); ?>

    <?php do_action( 'bbp_theme_before_topic_meta' ); ?>

    <p class="bbp-topic-meta">

      <?php do_action( 'bbp_theme_before_topic_started_by' ); ?>

      <div class="col-sm-12 ">Started by:
        <span class="rgsusernicename ">
        <?php 

 $reply_author_id = get_post_field( 'post_author', bbp_get_reply_id() );
    $user_data = get_userdata( $reply_author_id );
    $user_email = $user_data->user_email;
    $username =$user_data->user_login;
    echo $username  ?></span></div>

      <?php do_action( 'bbp_theme_after_topic_started_by' ); ?>

      <?php if ( !bbp_is_single_forum() || ( bbp_get_topic_forum_id() !== bbp_get_forum_id() ) ) : ?>

        <?php do_action( 'bbp_theme_before_topic_started_in' ); ?>

      

        <?php do_action( 'bbp_theme_after_topic_started_in' ); ?>

      <?php endif; ?>

    </p>

    <?php do_action( 'bbp_theme_after_topic_meta' ); ?>

    <?php bbp_topic_row_actions(); ?>

  </li>

  <li class="col-sm-2 e5ffc6background text-center color898989"><div class="col-sm-12">

Replies: <?php bbp_topic_reply_count($topic_id) ?>
  </div>
  <div class="col-sm-12 wpviews">Views: <?php echo wpb_get_post_views(get_the_ID()); ?></div></li>



  <li class=" col-sm-3">

    <?php do_action( 'bbp_theme_before_topic_freshness_link' ); ?>

    

    <?php do_action( 'bbp_theme_after_topic_freshness_link' ); ?>
  
    <div class="col-sm-12 color898989">
    <?php bbp_topic_freshness_link(); ?>
  </div>
 
  </li>
 <div class="pull-right pencilsubfavlinks"><span class="glyphicon glyphicon-pencil" id="rgspencillink"></span> 
   <div class="rgsublinkpf"><li><?php bbp_topic_favorite_link(); ?></li><li><?php bbp_topic_subscription_link(); ?></li></div>
    </div>
</ul>
    <?php endwhile; ?>
   
<?php else : ?>
    <p><?php _e( 'You are not currently subscribed to any topics.', 'bbpress' ); ?>

    </p>
<?php endif; ?>
    </div>
    
    <div role="tabpanel" class="tab-pane row" id="favrt">
<div class="col-sm-12">
<?php $curauth = (isset($_GET['author_name'])) ? get_user_by('slug', $author_name) : get_userdata(intval($author)); ?>

<?php $user_favs = wpfp_get_users_favorites($curauth->display_name); ?>
<ul classs="col-sm-12">
<?php foreach ($user_favs as $user_fav) :
echo "<li class='col-sm-3 rgsuserfavli'><a class='col-sm-12' href='".get_permalink($user_fav)."' title='". get_the_title($user_fav) ."'>" . get_the_post_thumbnail( $user_fav, array(210,210) ) . "</a>
<a class='col-sm-12 text-center' href='".get_permalink($user_fav)."' title='". get_the_title($user_fav) ."'>" . get_the_title( $user_fav ) . "</a>
</li>";
endforeach ; ?>

</div>

<div class="col-sm-12">
<div class="bbp-user-section">

      <?php if ( bbp_get_user_favorites() ) : ?>
<ul class=" col-sm-12 rgsfavttopiclists">
       <?php while ( bbp_topics() ) : bbp_the_topic(); ?>

  <li class=" text-center col-sm-4 ">
    <div class="col-sm-12 paddingzero  rgsfavttopiclistsborder">
    <?php do_action( 'bbp_theme_before_topic_title' ); ?>

    <div class="col-sm-12 rgsgreentitle paddingzero"><a class="bbp-topic-permalink" href="<?php bbp_topic_permalink(); ?>"><?php bbp_topic_title(); ?></a></div>
       <div >

<span>Replies: <?php bbp_topic_reply_count($topic_id) ?></span>
<span>Views: <?php echo wpb_get_post_views(get_the_ID()); ?></span>
  </div>

</div>
  </li>
  

    <?php endwhile; ?>

        </ul> 

      <?php else : ?>

        <p><?php bbp_is_user_home() ? _e( 'You currently have no favorite topics.', 'bbpress' ) : _e( 'This user has no favorite topics.', 'bbpress' ); ?></p>

      <?php endif; ?>

    </div>
</div>
</div>

    <div role="tabpanel" class="tab-pane col-sm-12 active" id="settings">
  <?php if(isset($_POST['submitted'])) {?>

  <div class="thanks">
    <h1>Thanks, <?=$name;?></h1>
    <p>Your email was successfully sent. I will be in touch soon.</p>
  </div>

<?php } else { ?>

<form action="<?php echo bp_displayed_user_domain() . bp_get_settings_slug() . '/general'; ?>" method="post" class="standard-form" id="settings-form">

  <?php if ( !is_super_admin() ) : ?>

    <label for="pwd"><?php _e( 'Current Password <span>(required to update email or change current password)</span>', 'buddypress' ); ?></label>
    <input type="password" name="pwd" id="pwd" size="16" value="" class="settings-input small" <?php bp_form_field_attributes( 'password' ); ?>/> &nbsp;<a href="<?php echo wp_lostpassword_url(); ?>" title="<?php esc_attr_e( 'Password Lost and Found', 'buddypress' ); ?>"><?php _e( 'Lost your password?', 'buddypress' ); ?></a>

  <?php endif; ?>

  <label for="email"><?php _e( 'Account Email', 'buddypress' ); ?></label>
  <input type="email" name="email" id="email" value="<?php echo bp_get_displayed_user_email(); ?>" class="settings-input" <?php bp_form_field_attributes( 'email' ); ?>/>

  <label for="pass1"><?php _e( 'Change Password <span>(leave blank for no change)</span>', 'buddypress' ); ?></label>
  <input type="password" name="pass1" id="pass1" size="16" value="" class="settings-input small password-entry" <?php bp_form_field_attributes( 'password' ); ?>/> &nbsp;<?php _e( 'New Password', 'buddypress' ); ?><br />
  <div id="pass-strength-result"></div>
  <label for="pass2" class="bp-screen-reader-text"><?php _e( 'Repeat New Password', 'buddypress' ); ?></label>
  <input type="password" name="pass2" id="pass2" size="16" value="" class="settings-input small password-entry-confirm" <?php bp_form_field_attributes( 'password' ); ?>/> &nbsp;<?php _e( 'Repeat New Password', 'buddypress' ); ?>

  <?php

  /**
   * Fires before the display of the submit button for user general settings saving.
   *
   * @since 1.5.0
   */
  do_action( 'bp_core_general_settings_before_submit' ); ?>

  <div class="submit">
    <input type="submit" name="submit" value="<?php esc_attr_e( 'Save Changes', 'buddypress' ); ?>" id="submit" class="auto" />
  </div>

  <?php

  /**
   * Fires after the display of the submit button for user general settings saving.
   *
   * @since 1.5.0
   */
  do_action( 'bp_core_general_settings_after_submit' ); ?>

  <?php wp_nonce_field( 'bp_settings_general' ); ?>

</form>
<?php  }?>

    
    I am working on it
      <ul>
  <a href="<?php echo bp_loggedin_user_domain() ?>profile/change-avatar/">Change Your Avatar!</a>
  </ul>

    </div>
  </div>

</div>

<!-- #item-body -->

	<?php

	/**
	 * Fires after the display of member home content.
	 *
	 * @since 1.2.0
	 */
	do_action( 'bp_after_member_home_content' ); ?>


</div>