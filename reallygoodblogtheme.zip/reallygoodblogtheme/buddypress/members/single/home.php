<?php
/**
 * BuddyPress - Members Home
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>

<div class="col-sm-12">
<section class="row rgssearchpagebordercalss marginbottom rgsmargintop">
    <div class="col-xs-12 col-sm-12 marginbottom catepagestarone"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_TopStar.png">
  <div class="item-list-tabs no-ajax rgsprofilenav" id="object-nav" role="navigation">
      <ul class="pull-right">
        <?php bp_get_displayed_user_nav(); ?>

        <?php

        /**
         * Fires after the display of member options navigation.
         *
         * @since 1.2.4
         */
        do_action( 'bp_member_options_nav' ); ?>

      </ul>
    </div>
    </div>
<div id="hidepublicpf">
    <div class="col-sm-12 marginbottom">
<div class="col-sm-5">
<div class="center-avatar">
  <?php global 
  $current_user;
      bp_loggedin_user_avatar( 'type=full&width=120&height=120' ); ?>
    </div> 
  </div>

   <div class="col-sm-7">
    <div class="rgsuserdisplayname col-sm-12"><?php bp_displayed_user_mentionname(); ?></div>
  <div class="color898989 col-sm-12">

    <div class="row">
      <div class="col-sm-5">Position/Role:</div>
      <div class="col-sm-7">
        <?php  $user_role = bp_profile_field_data( array('field' => 258, 'user_id' => bbp_get_reply_author_id() ) );
            echo $user_role; ?>
          </div>
      </div>
<div class="row">
  <div class="col-sm-5">Classroom Age/Grade:</div> 
<div class="col-sm-7">  <?php $user_grade = bp_profile_field_data( array('field' => 274, 'user_id' => bbp_get_reply_author_id() ) );
 ?></div>
</div>
<div class="row"><div class="col-sm-5">Teaching since: </div>
<div class="col-sm-7"><?php $user_year = bp_profile_field_data( array('field' => 288, 'user_id' => bbp_get_reply_author_id() ) );
 ?></div>
</div>
<div class="row">
 <div class="col-sm-5"> Where I am From: </div> 

<div class="col-sm-7"><?php  $rgsuser_location = bp_profile_field_data( array('field' => 146, 'user_id' => bbp_get_reply_author_id() ) );
     ?></div>

</div>
</div>
  </div>
</div>

 <div class="col-sm-6">
  <div class="col-sm-4"><?php printf( __( '<span class="rgsorangecolornumber col-sm-12 text-center">%s</span><span class="rgsuseractivitycount rgsafontweightbold col-sm-12 text-center">Thread</br>Started </span> ',  'bbpress' ), bbp_get_user_topic_count_raw() ); ?></div>
<div class="bbp-user-reply-count col-sm-4">
  <?php printf( __( '<span class="rgsorangecolornumber col-sm-12 text-center">%s</span><span class="rgsuseractivitycount rgsafontweightbold text-center col-sm-12">Thread</br>Replies</span>', 'bbpress' ), bbp_get_user_reply_count_raw() ); ?></div>
<div class="col-sm-4">
  <?php
global $wpdb;
global $current_user;
      get_currentuserinfo();
$user_id =  $current_user->ID ;  //change this if not in a std post loop
$where = 'WHERE comment_approved = 1 AND user_id = ' . $user_id ;
$comment_count = $wpdb->get_var(
    "SELECT COUNT( * ) AS total
    FROM {$wpdb->comments}
    {$where}
  ");
$user = get_userdata($user_id);
$post_count = get_usernumposts($user->ID);
echo '<div><span class="rgsorangecolornumber col-sm-12 text-center">' . $comment_count . '</span> <span class="rgsuseractivitycount rgsafontweightbold col-sm-12 text-center">Article comments</span> </div>';
?>
</div>
<div class="emailclassdiv col-sm-12">
<div class="col-sm-12  rgsuseractivitycount ">Contact Me: </div>
<div class="col-sm-12 rgsorangecolornumber"><?php global $bp;
echo $bp->displayed_user->userdata->user_email; ?></div>
</div>
  </div>

  <div class="col-sm-6">
<div class="col-sm-12 rgsorangecolornumber ">About Me: </div>
<div class="col-sm-12 borderclass"><?php $user_year = bp_profile_field_data( array('field' => 517, 'user_id' => bbp_get_reply_author_id() ) );
 ?></div>

 </div>
</div>
 <div  class="col-sm-12">

    <?php

      //     if ( bp_is_user_profile() ) :
      // bp_get_template_part( 'members/single/profile'  );
    if ( bp_is_user_notifications() ) :
      bp_get_template_part( 'members/single/notifications' );

    elseif ( bp_is_user_settings() ) :
      bp_get_template_part( 'members/single/settings' );
    elseif ( bp_is_user_profile() ) :
      bp_get_template_part( 'members/single/profile'  );
   
else :
      bp_get_template_part( 'members/single/plugins'  );
       endif;

   
    ?>

  </div>

<div class="col-xs-12 col-sm-12 marginbottom catepagestaronebottom rgsmarginbottom"><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/CategoryPage_BottomStar-1.png">
</div>

</section>
</div>
<div></div>