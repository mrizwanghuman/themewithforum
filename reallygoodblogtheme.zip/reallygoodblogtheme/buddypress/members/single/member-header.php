<?php
/**
 * BuddyPress - Users Header
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

?>

<?php

/**
 * Fires before the display of a member's header.
 *
 * @since 1.2.0
 */
do_action( 'bp_before_member_header' ); ?>

<!-- #item-header-avatar -->

<div id="item-header-content">

	
		<div class="rgsuserdisplayname">@<?php bp_displayed_user_mentionname(); ?></div>
	
<div class=""><?php printf( __( '<span class="rgsuseractivitycount rgsafontweightbold">Thread Started: </span> <span class="rgsorangecolornumber">%s</span>',  'bbpress' ), bbp_get_user_topic_count_raw() ); ?></div>
<div class="bbp-user-reply-count"><?php printf( __( '<span class="rgsuseractivitycount rgsafontweightbold">Thread Replies: </span><span class="rgsorangecolornumber">%s</span>', 'bbpress' ), bbp_get_user_reply_count_raw() ); ?></div>
	<?php
global $wpdb;
global $current_user;
      get_currentuserinfo();
$user_id =  $current_user->ID ;  //change this if not in a std post loop
$where = 'WHERE comment_approved = 1 AND user_id = ' . $user_id ;
$comment_count = $wpdb->get_var(
    "SELECT COUNT( * ) AS total
		FROM {$wpdb->comments}
		{$where}
	");
$user = get_userdata($user_id);
$post_count = get_usernumposts($user->ID);
echo '<div> <span class="rgsuseractivitycount rgsafontweightbold">Article comments:</span> <span class="rgsorangecolornumber">' . $comment_count . '</span></div>';
?>

	<?php

	/**
	 * Fires before the display of the member's header meta.
	 *
	 * @since 1.2.0
	 */
	do_action( 'bp_before_member_header_meta' ); ?>

	<div id="item-meta">

		

		<div id="item-buttons">

			<?php

			/**
			 * Fires in the member header actions section.
			 *
			 * @since 1.2.6
			 */
			do_action( 'bp_member_header_actions' ); ?>

		</div><!-- #item-buttons -->

		<?php

		 /**
		  * Fires after the group header actions section.
		  *
		  * If you'd like to show specific profile fields here use:
		  * bp_member_profile_data( 'field=About Me' ); -- Pass the name of the field
		  *
		  * @since 1.2.0
		  */
		 do_action( 'bp_profile_header_meta' );

		 ?>

	</div><!-- #item-meta -->

</div><!-- #item-header-content -->

<?php

/**
 * Fires after the display of a member's header.
 *
 * @since 1.2.0
 */
do_action( 'bp_after_member_header' ); ?>

<?php

/** This action is documented in bp-templates/bp-legacy/buddypress/activity/index.php */
do_action( 'template_notices' ); ?>
