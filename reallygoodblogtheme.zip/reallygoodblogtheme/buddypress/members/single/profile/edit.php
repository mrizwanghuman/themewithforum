<?php
/**
 * BuddyPress - Members Single Profile Edit
 *
 * @package BuddyPress
 * @subpackage bp-legacy
 */

/**
 * Fires after the display of member profile edit content.
 *
 * @since 1.1.0
 */
do_action( 'bp_before_profile_edit_content' );
$sqlStr = "SELECT *idFROMwp_bp_xprofile_groups";
$groups = $wpdb->get_results($sqlStr);
if ( bp_has_profile( 'profile_group_id=' . $groups[1] ) ) :
	while ( bp_profile_groups() ) : bp_the_profile_group(); ?>
<div class="rgs-registration-form marginbottom" >
<form action="<?php bp_the_profile_group_edit_form_action(); ?>" method="post" id="profile-edit-form" class="form-horizontal">

	<?php

		/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/profile/profile-wp.php */
		do_action( 'bp_before_profile_field_content' ); ?>

		<div class="rgsuserdisplayname"><?php printf( __( "Basic Information", "buddypress" ), bp_get_the_profile_group_name() ); ?></div>
		<div>* indicates required</div>

		<?php if ( bp_profile_has_multiple_groups() ) : ?>
		
		<?php endif ;?>

	

		<?php while ( bp_profile_fields() ) : bp_the_profile_field(); ?>

			<div>
<div class="form-group">

<?php if ( 'textbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" class="col-sm-2 control-label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<div class="col-sm-6">
	<input type="text" name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" value="<?php bp_the_profile_field_edit_value() ?>" class="form-control"/>
</div>
<div class="col-sm-4">Will not be
publically displayed</div>
<?php endif; ?>

<?php if ( 'textarea' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" ><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<textarea rows="5" cols="40" name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>"><?php bp_the_profile_field_edit_value() ?></textarea>

<?php endif; ?>

<?php if ( 'selectbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>" class="col-sm-2 control-label"><?php bp_the_profile_field_name() ?> </label>

	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<div class="col-sm-6">
	<select name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" class="form-control">
		<?php bp_the_profile_field_options() ?>
	</select>
</div>
<div class="col-sm-4"></div>
<?php endif; ?>

<?php if ( 'multiselectbox' == bp_get_the_profile_field_type() ) : ?>

	<label for="<?php bp_the_profile_field_input_name() ?>"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>
	<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
	<select name="<?php bp_the_profile_field_input_name() ?>" id="<?php bp_the_profile_field_input_name() ?>" multiple="multiple">
		<?php bp_the_profile_field_options() ?>
	</select>

<?php endif; ?>

<?php if ( 'radio' == bp_get_the_profile_field_type() ) : ?>

	<div class="radio">
		<span class="label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></span>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
		<?php bp_the_profile_field_options() ?>

		<?php if ( !bp_get_the_profile_field_is_required() ) : ?>
			<a class="clear-value" href="javascript:clear( '<?php bp_the_profile_field_input_name() ?>' );"><?php _e( 'Clear', 'buddypress' ) ?></a>
		<?php endif; ?>
	</div>

<?php endif; ?>


<?php if ( 'checkbox' == bp_get_the_profile_field_type() ) : ?>
  	<div class="checkbox termandcondition">
		<span class="label"><?php bp_the_profile_field_name() ?> </span>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
		<?php bp_the_profile_field_options() ?>
	</div>
   
<?php endif; ?>

<?php if ( 'datebox' == bp_get_the_profile_field_type() ) : ?>


		<label for="<?php bp_the_profile_field_input_name() ?>_day" class="col-sm-2 control-label"><?php bp_the_profile_field_name() ?> <?php if ( bp_get_the_profile_field_is_required() ) : ?><?php _e( '(required)', 'buddypress' ) ?><?php endif; ?></label>

		<?php do_action( 'bp_' . bp_get_the_profile_field_input_name() . '_errors' ) ?>
<div class="col-sm-6">
		<select name="<?php bp_the_profile_field_input_name() ?>_year" id="<?php bp_the_profile_field_input_name() ?>_year" class="form-control">
			<?php bp_the_profile_field_options( 'type=year' ) ?>
		</select>
	
</div>
<div class="col-sm-4">Optional</div>
<?php endif; ?>

<?php do_action( 'bp_custom_profile_edit_fields' ) ?>

<span class="description nextotembox"><?php bp_the_profile_field_description() ?></span>

</div>

				<?php if ( bp_current_user_can( 'bp_xprofile_change_field_visibility' ) ) : ?>
					<p class="field-visibility-settings-toggle" id="field-visibility-settings-toggle-<?php bp_the_profile_field_id() ?>">
						<?php
						printf(
							__( 'This field can be seen by: %s', 'buddypress' ),
							'<span class="current-visibility-level">' . bp_get_the_profile_field_visibility_level_label() . '</span>'
						);
						?>
						<a href="#" class="visibility-toggle-link"><?php _e( 'Change', 'buddypress' ); ?></a>
					</p>

					<div class="field-visibility-settings" id="field-visibility-settings-<?php bp_the_profile_field_id() ?>">
						<fieldset>
							<legend><?php _e( 'Who can see this field?', 'buddypress' ) ?></legend>

							<?php bp_profile_visibility_radio_buttons() ?>

						</fieldset>
						<a class="field-visibility-settings-close" href="#"><?php _e( 'Close', 'buddypress' ) ?></a>
					</div>
				<?php else : ?>
					<div class="field-visibility-settings-notoggle" id="field-visibility-settings-toggle-<?php bp_the_profile_field_id() ?>">
						<?php
						printf(
							__( 'This field can be seen by: %s', 'buddypress' ),
							'<span class="current-visibility-level">' . bp_get_the_profile_field_visibility_level_label() . '</span>'
						);
						?>
					</div>
				<?php endif ?>

				<?php

				/**
				 * Fires after the visibility options for a field.
				 *
				 * @since 1.1.0
				 */
				do_action( 'bp_custom_profile_edit_fields' ); ?>

				<p class="description"><?php bp_the_profile_field_description(); ?></p>
			</div>

		<?php endwhile; ?>

	<?php

	/** This action is documented in bp-templates/bp-legacy/buddypress/members/single/profile/profile-wp.php */
	do_action( 'bp_after_profile_field_content' ); ?>

	<div class="submit">
		<input type="submit" name="profile-group-edit-submit" id="profile-group-edit-submit" class="btn sellallartbtn center-block" value="<?php esc_attr_e( 'Save ', 'buddypress' ); ?> " />
	</div>

	<input type="hidden" name="field_ids" id="field_ids" value="<?php bp_the_profile_field_ids(); ?>" />

	<?php wp_nonce_field( 'bp_xprofile_edit' ); ?>

</form>
</div>
<?php endwhile; endif; ?>

<?php

/**
 * Fires after the display of member profile edit content.
 *
 * @since 1.1.0
 */
do_action( 'bp_after_profile_edit_content' ); ?>
