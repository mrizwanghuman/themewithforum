<form id="login" class="ajax-auth rgs-registration-form" action="login" method="post">
    <div class="loginformpadding">
    <div class="text-center col-sm-12 loginpageheading">Log In</div>
    <p class="status col-sm-12"></p>  
    <?php wp_nonce_field('ajax-login-nonce', 'security'); ?>  
    <div class="form-group">
    <label for="username" >Display Name</label>
    <input id="username" type="text" class="required form-control" name="username">
</div>
<div class="form-group">
    <label for="password">Password</label>
    <input id="password" type="password" class="required form-control" name="password">
    </div>
   <p class="text-center"> <a id="pop_forgot" class="text-link" href="<?php
echo wp_lostpassword_url(); ?>"><u>Forgot Your Display Name Or Password?</u>
</a></p>
    <input class="submit_button btn sellallartbtn center-block" type="submit" value="Log In">
	<a class="close" href="">X</a> 

</div>
    
    <div class="modal-footer rgsfooter ">
        <div class="col-ms-12 text-center notamemeber">Not A Member? <a  href="<?php echo site_url(); ?>/register"><u>Join Now</u></a></div>
<div class="col-sm-12 text-center"><a  href="<?php echo site_url(); ?>/why-join"><u>Why Join</u></a></div>
      </div>
</form>

<form id="forgot_password" class="ajax-auth rgs-registration-form" action="forgot_password" method="post"> 

    <div class="text-center forgotpassword">Reset Your Password
Or Request Display Name</div>
<div class="loginformpadding"> 
    <p class="status"></p>  
    <?php wp_nonce_field('ajax-forgot-nonce', 'forgotsecurity'); ?> 
    <div class="form-group"> 
    <label for="user_login" class="rgsforgotpasslabel">Enter your display name or email address associated with your account:</label>
    <input id="user_login" type="text" class="required form-control" name="user_login">
</div>
     <input class="submit_button sellallartbtn btn center-block" type="submit" value="Send Email">
	<a class="close" href="">X</a>   
    </div> 
</form>