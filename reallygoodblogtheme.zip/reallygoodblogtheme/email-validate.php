<?php 
/**
 * Template Name: email validate
 * 
 */


?>

<script>
	



function load_page()
{

//window.location.replace("http://rgsdevtest.staging.wpengine.com?reg_signup=1");
window.history.back();

 
}

</script>

<body onLoad="load_page()">
</body>