<?php 

/**
 * Template Name: Early Childhood
 * 
 */ get_header() ?>

<?php 
   $the_query1 = new WP_Query(array(
   
    'posts_per_page' => 1 ,
     
     'cat' => 1043,
    )); 
   ?>
   <?php 
$do_not_duplicate = array();
   if ( $the_query1->have_posts() ) : ?>
   <?php
   while ( $the_query1->have_posts() ) : 
   $the_query1->the_post();
 $do_not_duplicate[] = $post->ID;
  ?>
  
	<div class="row marginbottom rgsgatewaypagerow">

<div class="col-sm-12 col-xs-12 rgsgatewaypage">
<div class="row">
<div class="col-xs-4 col-sm-3 col-md-2 col-lg-2  gatewaykidheading">
	<img src="<?php echo get_template_directory_uri();?>/images/ECKids_Gateway.png " />
</div>
<div class="col-xs-8 col-sm-9 col-md-8 col-lg-8 mobilecenteralign">
<h1><?php echo get_cat_name(  1043) ?></h1>
</div>
</div>
</div>
</div>


<div class="row marginbottom">
	<div class="col-sm-12 borderclass getwaypageborderclass">



   
    <div class="row no-pad">
      <?php $postdatenew = get_the_time('F j, Y'); ?>
       <?php
 $d=strtotime("-3 Months");
$pasthethreemontdate = date("m-d-y", $d);

if ($postdatenew > $pasthethreemontdate){?>

 <div class="newimage "><img src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/02/newBadgeupdated.png"></div>
<?php }?>


      <div class=" col-xs-12 col-sm-12 col-md-8 getwaythumnailsize ">
        
   <a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail('homepagesize');?></a>
  
</div>

<div class="col-xs-12 col-sm-12 col-md-4  gatewayheadingclass">
<h2 class="col-xs-12"><a href="<?php the_permalink(); ?>" ><?php the_title();?></a></h2>
<div class="col-xs-12 catedatfont">
 
 <?php echo  $postdatenew ?>

</div>
 <div class="col-xs-12  "><?php the_excerpt(); ?></div>
 


</div>
   
</div>

   <!-- item active -->
 

	</div>

</div>

<div class="row no-pad marginbottom">
<div class="col-sm-12 rgstopicstoexplore">

  <div class="row marginbottom">
  <h2>
Topics To Explore:
</h2>
  </div>


</div>

<div class="listcategateway marginbottom">


<ul id="rgscategorieslist">
<?php wp_list_categories('orderby=name&child_of=1043&title_li='); ?>
</ul>


</div>
</div>

<div class="row marginbottom">
<div class="col-sm-12 starline">
<img class="hidden-xs hidden-sm" src="http://blog.reallygoodstuff.com/wp-content/uploads/2016/01/starwithline.png">
<img class="visible-sm visible-xs" src="<?php echo get_template_directory_uri();?>/images/starBarMobile.png">
</div>

  </div>





 <?php 
   endwhile;   wp_reset_postdata();?>



    <div class="row marginbottom panelareaforgateway">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 


  'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
<?php wp_reset_postdata(); ?>
 <?php
endwhile;
?>
<?php endif; ?>
</div>
  </div>
<div class="row ">

<?php

$news_cat_ID = get_cat_ID('Early Childhood'); 
$news_cats   = get_categories("parent=$news_cat_ID");
$news_query  = new WP_Query();

foreach ($news_cats as $news_cat):
?>
<div class="col-xs-12 col-sm-12 col-md-4">
  <div class="col-xs-12 categoryviewpanel  borderclass">
 


<?php 

$argss=array(
      'posts_per_page' => 1,
      'post__not_in' => $do_not_duplicate,
      'cat'         =>$news_cat->term_id,
      
      );

$news_query->query($argss); ?>
<?php if ($news_query->have_posts()): $news_query->the_post(); ?>
  
  <div class="rgsgatewaypage col-xs-12 col-sm-12">
  <h3 class="rgsgatewaypageh3">
<a href="<?php the_permalink(); ?>"><?php the_category(' '); ?><span class="glyphicon glyphicon-triangle-right"></span>  </a>
</h3>
</div>
<div class="col-xs-4 col-sm-4 col-md-12 gatewayCatThumbnail">
<?php the_post_thumbnail( 'gateway'); ?>
</div>
        <div class="col-xs-8 col-sm-8 col-md-12 gatewayCatThumbnail">
        <h3 class="col-xs-12 col-sm-12 padding5px">
          <a href="<?php the_permalink(); ?>">
            <?php the_title(); ?>
          </a>
            <!-- do whatever you else you want that you can do in a normal loop -->
        </h3> 
        <div class="col-xs-12 col-sm-12 catedatfont padding5px">
 
 <?php the_time( 'F j, Y'); ?>

</div>
<div class="col-xs-12 col-sm-12 hidden-xs hidden-sm padding5px"><?php the_excerpt(); ?></div>
</div>
    <div class="col-xs-12 col-sm-12 visible-xs visible-sm"><?php the_excerpt(); ?></div>  
    </div>
        </div> 

<?php endif; ?>

<?php endforeach; wp_reset_postdata();?>

</div>


   <div class="row marginbottom panelareaforgateway">
<div class="col-sm-12">
  <?php
$args = array( 'post_type' => 'rgs-homepage-adzon1', 'posts_per_page' => 1 );
$loop = new WP_Query( $args );
while ( $loop->have_posts() ) : $loop->the_post();
?>
<div class=" homepageadzone"> <?php the_content( ); ?></div>
<?php wp_reset_postdata(); ?>
 <?php
endwhile;
?>

</div>
  </div>

<?php get_footer() ?>
