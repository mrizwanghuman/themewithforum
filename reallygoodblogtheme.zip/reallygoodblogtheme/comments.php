<?php
/**
 * The template for displaying comments.
 *
 * This is the template that displays the area of the page that contains both the current comments
 * and the comment form.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package reallygoodstufftheme
 */

/*
 * If the current post is protected by a password and
 * the visitor has not yet entered the password we will
 * return early without loading the comments.
 */
if ( post_password_required() ) {
	return;
}
?>
<div class="row">
<?php if($comments) : 

?>
	<ul class="commentsList">
  	<?php $i = 0; foreach($comments as $comment) : ?>
  
		<li class="col-sm-12" id="comment-<?php comment_ID(); ?>">
			<?php if ($comment->comment_approved == '0') : ?>
				<p>Your comment is awaiting approval</p>
			<?php endif; ?>
			<div class="col-sm-2 rgscommentsavatar">
<?php echo get_avatar( $comment, 65 ); ?>
			</div>
			<div class="col-sm-10">
				<div class="row commentingrow">
<div class="col-sm-12 commentsUsername">
	<?php comment_author_link(); ?></div>
<div class="col-sm-12 commentsDateSingle"><?php comment_date(); ?></div>
<div class="col-sm-12 commentTextId" id="div-comment-<?php comment_ID() ?>">
	<?php comment_text(); ?>
				</div>
				<div class="col-sm-12 ">
				
<div class="replyclass pull-right" >Reply</div>
<div class="showcalss" id="comment_form_wrapper-<?php echo ++$i; ?>" style="display: none;">
    <?php 
$authorlink =  get_comment_author(  );
$id = get_comment(get_comment_ID())->user_id;
 $user_info= get_userdata( $id); 
$current_comment = get_comment_text();
$authorusername=  $user_info->user_login ;
    $comments_args = array(
        // change the title of send button 
        'label_submit'=>'Comment',
         'class_submit'      => 'btn sellallartbtn pull-right rgspadding2per',
        // change the title of the reply section
        'title_reply'=>' ',
        'logged_in_as' => ' ',
        // remove "Text or HTML to be displayed after the set of comment fields"
        'must_log_in' => '<a class="login_button replybuttonclass" id="show_login" href="">Join or Log In</a> to make a comment' ,
        'comment_notes_after' => '',
        // redefine your own textarea (the comment body)
        'comment_field' => '<textarea   class="form-control" id="comment" name="comment" aria-required="true"> @'
. $authorusername. " " .$current_comment. '</textarea>',
);

comment_form($comments_args); ?>
</div>


</div>

				</div>
				
			</div>
		
			
		</li>
	<?php endforeach; ?>
	</ul>
<?php else : ?>
	<p></p>
<?php endif; ?>

</div>